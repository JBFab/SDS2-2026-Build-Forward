"""
=============================================================================
 JBSimpleLadder  -  fixed ladder custom member for SDS2 2027
=============================================================================
 Structure follows the proven JBLintel pattern:

     class JBSimpleLadder(StateAccessor, MemberBase.MemberBase)

 SDS2 lifecycle:
     __init__()        SDS2 constructs the member (no args of our own)
     Add()             locate point(s), set left/right location, run dialog
     Edit()            re-run the dialog on existing member(s)
     CreateMaterial()  build ALL geometry - called on every reprocess
     ProcessFinal()    optional views

 Parameter storage is handled by StateAccessor via _arguments/_version.
 Every user-editable value MUST appear in _arguments or it will not
 survive Edit / copy / process.

 Install
 -------
   C:\\ProgramData\\SDS2_2027\\plugins\\Jason\\Members\\Steel\\JBSimpleLadder\\
       JBSimpleLadder.py    <- this file
       LadderState.py
       LadderPreview.py
       LadderDialog.py
       LadderBuild.py
       JBMaterialPicker.py
       PLUGIN
=============================================================================
"""

"""
=============================================================================
JBSimpleLadder
Copyright (c) 2026 Jason Bondioli

LICENSE AND TERMS OF USE:
Permission is hereby granted to use, copy, modify, and freely distribute 
this software, subject to the following conditions:

1. ATTRIBUTION: Any distribution of this software, whether in its original 
   or modified form, must clearly credit the original author, Jason Bondioli.

2. NO RESALE: This software and any of its derivatives may not be sold or 
   packaged for commercial gain by anyone other than the original author.

3. DISCLAIMER OF LIABILITY: THE SOFTWARE IS PROVIDED "AS IS", WITHOUT 
   WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. In no event shall the author 
   be held responsible for any mishaps, lost work, data loss, or other 
   damages arising from the use of this software or its derivatives. 
=============================================================================
"""

import os
import sys
import datetime

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

_MACRO = r"C:\ProgramData\SDS2_2027\macro\JBTools"
if os.path.isdir(_MACRO) and _MACRO not in sys.path:
    sys.path.append(_MACRO)

import MemberBase
from StateAccessor import StateAccessor
from Point3D import Point3D
from point import PointLocate
from member import Member
from job import Job
import param

from LadderState import (
    LadderState, LadderType, RailShape, RungShape,
    RungSpacingMode, BottomConnection, BcOSLSide, BcLegOrientation,
    IntermediateConnection, FlareConstruction,
    IntermediateSpacing, ReturnConnection, PickMode,
    HingeSide, IcToe, ElevDatum,
    HSSPunchMode,
)
import LadderBuild


def _trace(msg):
    """Append a call-sequence line so we can see how SDS2 drives us."""
    try:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "JBSimpleLadder_calls.log")
        with open(path, "a") as fh:
            fh.write("%s  %s\n" % (datetime.datetime.now().isoformat(), msg))
    except Exception:
        pass


MEMBERTYPEID = "JBSimpleLadder"
MARK_PREFIX = "LD"


class JBSimpleLadder(StateAccessor, MemberBase.MemberBase):
    """Fixed ladder: roof hatch, side step, or step through."""

    _version = 0
    _arguments = {}

    # Every persisted parameter, mirroring LadderState field-for-field.
    _arguments[0] = [
        ('ladder_desc', "LADDER"),
        ('mark_prefix', MARK_PREFIX),
        ('last_tab', 0),

        # Location
        ('pick_mode', PickMode.ONE_POINT_PLAN),
        ('ladder_rotation', 0.0),   # NOT 'rotation' - collides with MemberBase.rotation
        ('bottom_elev', 0.0),
        ('top_elev', 144.0),
        ('standoff', 7.0),

        # Type & top
        ('ladder_type', LadderType.SIDE_STEP),
        ('rungs_above_top', 0),
        ('hatch_rail_extension', 0.0),
        ('rail_setback_bottom', 0.0),
        ('ext_height', 42.0),

        # Flare
        ('flare_enabled', True),
        ('flare_to_bend', 6.0),
        ('flare_angle', 45.0),
        ('flare_width', 24.0),
        ('flare_construction', FlareConstruction.CUT_WELDED),
        ('flare_radius', 6.0),

        # Return
        ('return_enabled', False),
        ('return_width', 8.0),
        ('return_setback', 4.0),
        ('return_conn', ReturnConnection.WELDED),
        ('ret_conn_bp_thick', 0.375),
        ('ret_conn_bp_length', 2.5),
        ('ret_conn_bp_center_offset', 0.0),
        ('ret_conn_bp_width_in', 3.0),
        ('ret_conn_bp_width_out', 3.0),
        ('ret_conn_bp_edge_in', 1.25),
        ('ret_conn_bp_edge_out', 1.25),
        ('ret_conn_bp_hole_dia', 0.8125),
        ('ret_conn_bp_hole_in_enabled', True),
        ('ret_conn_bp_hole_out_enabled', True),

        # Rails
        ('rail_shape', RailShape.FLAT_BAR),
        ('rail_section', ""),
        ('rail_fb_width', 2.5),
        ('rail_fb_thick', 0.375),
        ('inside_width', 18.0),
        ('rail_grade', ""),
        ('round_top', False),
        ('round_top_radius', 0.0),
        ('cap_ends', False),
        ('cap_thick', 0.375),
        ('cap_top', True),
        ('cap_bottom', True),
        ('cap_overhang', 0.0),

        # Rungs
        ('rung_shape', RungShape.ROUND_BAR),
        ('rung_size', 0.75),
        ('rung_spacing_mode', RungSpacingMode.ODD_FIRST),
        ('rung_spacing', 12.0),
        ('first_rung_odd', 3.0),
        ('rung_setback', 0.0),
        ('hss_punch_mode', HSSPunchMode.INNER_ONLY),     # <-- ADD THIS LINE
        ('hss_outer_hole_dia', 0.8125),                  # <-- ADD THIS LINE
        ('hss_setback', 0.0625),                         # <-- ADD THIS LINE
        ('hole_clearance', 0.0625),
        ('hole_dia_override', 0.0),
        ('pr_width', 3.0),
        ('pr_height', 1.25),
        ('pr_thick', 0.1875),
        ('pr_radius', 0.25),
        ('pr_description', ""),

        # Connections
        ('bottom_conn', BottomConnection.NONE),
        ('bc_ang_size', "L4x4x3/8"),
        ('bc_ang_length', 6.0),
        ('bc_osl_side', BcOSLSide.INSIDE),
        ('bc_leg_orientation', BcLegOrientation.LLV),
        ('bc_bolt_dia', 0.75),
        ('bc_bolt_qty', 1),
        ('bc_weld_size', 0.25),
        ('bp_thick', 0.375),
        ('bp_length', 2.5),
        ('bp_center_offset', 0.0),
        ('bp_width_in', 3.0),
        ('bp_width_out', 3.0),
        ('bp_hole_dia', 0.8125),
        ('bp_edge_in', 1.25),
        ('bp_edge_out', 1.25),
        ('bp_hole_in_enabled', True),
        ('bp_hole_out_enabled', True),
        ('ic_count', 0),
        ('ic_spacing_mode', IntermediateSpacing.EVEN),
        ('ic_elev_datum', ElevDatum.ABSOLUTE),
        ('ic_elev_csv', ""),          # elevations serialized as text
        ('ic_type', IntermediateConnection.BENT_BOLT_WELD),
        ('ic_plate_width', 3.0),
        ('ic_plate_thick', 0.375),
        ('ic_leg', 4.0),
        ('ic_osl', 4.0),
        ('ic_bend_radius', 0.375),
        ('ic_bend_angle', 90.0),
        ('ic_toe', IcToe.OUT),
        ('ic_bolt_dia', 0.75),
        ('ic_gage', 2.5),

        # Gate
        ('gate_enabled', False),
        ('gate_bottom_elev', 0.0),
        ('gate_top_elev', 42.0),
        ('gate_elev_datum', ElevDatum.FROM_BOTTOM),
        ('gate_hinge_side', HingeSide.LEFT),
        ('gate_width', 24.0),
        ('gate_depth', 1.5),
        ('gate_thick', 0.1196),      # 11 ga
        ('gate_radius', 0.1875),     # 3/16
        ('gate_hinge_qty', 3),
        ('gate_hinge_offset', 6.0),
        ('gate_hinge_width', 3.0),
        ('gate_hinge_height', 4.0),
        ('gate_hinge_thick', 0.375),
        ('gate_hinge_description', ""),
        ('gate_hasp', True),
        ('gate_hasp_w_gate', 1.0),
        ('gate_hasp_w_rail', 2.5),
        ('gate_hasp_edge_dist', 0.5),
        ('gate_hasp_height', 4.0),
        ('gate_hasp_thick', 0.375),
        ('gate_hasp_hole_dia', 0.5),
        ('gate_hasp_offset', 0.0),

        # Geometry points
        ('point1', Point3D(0, 0, 0)),
        ('point2', Point3D(0, 0, 0)),
    ]

    # -----------------------------------------------------------------
    def __init__(self, *args, **kw):
        StateAccessor.__init__(self, *args, **kw)
        MemberBase.MemberBase.__init__(self)
        self.SetMemberType(MEMBERTYPEID)
        param.Units("feet")
        # NOTE: the job's saved defaults are deliberately NOT applied
        # here. __init__ runs for every member SDS2 touches, including
        # whatever it constructs behind the plugin-defaults screen, and
        # reaching into Storage from inside it was one of two suspects
        # for that screen breaking (see the registration note at the
        # bottom of this file). Defaults are applied in Add() instead -
        # the one moment a genuinely new ladder is created, which is
        # also the only moment they should apply.
        try:
            self.SetPiecemarkPrefix(self.mark_prefix)
        except Exception:
            pass

    # -----------------------------------------------------------------
    # State <-> LadderState bridge
    # -----------------------------------------------------------------
    def to_state(self):
        """Build a LadderState from the persisted member attributes."""
        st = LadderState()
        for name, _default in self._arguments[0]:
            if name in ("point1", "point2", "ic_elev_csv",
                        "ladder_desc", "mark_prefix", "ladder_rotation"):
                continue
            if hasattr(st, name):
                try:
                    setattr(st, name, getattr(self, name))
                except Exception:
                    pass
        st.rotation = getattr(self, "ladder_rotation", 0.0)
        # ic_type is persisted as a raw string; members saved before the
        # bent-plate types were renamed still carry "Bolted-Welded" /
        # "Welded-Welded", which are no longer in the dropdown's list.
        st.ic_type = IntermediateConnection.normalize(st.ic_type)
        # elevations come across as text
        from LadderState import parse_len
        vals = []
        for part in str(getattr(self, "ic_elev_csv", "")).replace(
                ";", ",").split(","):
            part = part.strip()
            if part:
                vals.append(parse_len(part, 0.0))
        st.ic_elevations = vals
        st.description = getattr(self, "ladder_desc", "LADDER")
        return st

    def from_state(self, st):
        """Push a LadderState back onto the member for persistence."""
        from LadderState import fmt_len
        for name, _default in self._arguments[0]:
            if name in ("point1", "point2", "ic_elev_csv",
                        "ladder_desc", "mark_prefix", "ladder_rotation"):
                continue
            if hasattr(st, name):
                try:
                    setattr(self, name, getattr(st, name))
                except Exception:
                    pass
        try:
            self.ladder_rotation = st.rotation
        except Exception:
            pass
        try:
            self.ic_elev_csv = ", ".join(fmt_len(v)
                                         for v in st.ic_elevations)
        except Exception:
            pass

    # -----------------------------------------------------------------
    # SDS2 lifecycle
    # -----------------------------------------------------------------
    def Add(self):
        _trace("Add() enter")
        param.Units("feet")

        # Overlay the job's saved defaults. Here rather than in
        # __init__ because this is the one call that means "the user is
        # creating a brand new ladder" - an existing member being
        # loaded, edited or reprocessed never reaches it, so the
        # defaults cannot trample values that are already set.
        try:
            from LadderDefaults import apply_defaults
            apply_defaults(self)
        except Exception:
            pass

        pt1 = PointLocate("Locate ladder at floor  (centre of ladder)")
        if pt1 is None:
            return False

        # Always OFFER a second point. Right-click > OK returns None,
        # which means "working in plan" - keep the typed elevations.
        pt2 = PointLocate(
            "Locate TOP of ladder, or right-click > OK for plan mode", pt1)

        if pt2 is not None:
            self.bottom_elev = min(pt1.z, pt2.z)
            self.top_elev = max(pt1.z, pt2.z)
            self.pick_mode = PickMode.TWO_POINT_ELEV
        else:
            self.bottom_elev = pt1.z
            self.pick_mode = PickMode.ONE_POINT_PLAN

        self.point1 = Point3D(pt1)
        self.point2 = Point3D(pt2) if pt2 is not None else Point3D(pt1)

        # A ladder is a vertical member: left = bottom, right = top.
        top_z = self.top_elev + (self.ext_height
                                 if self.ladder_type != LadderType.ROOF_HATCH
                                 else self.hatch_rail_extension)
        self.SetLeftLocation(Point3D(pt1.x, pt1.y,
                                     self.bottom_elev + self.rail_setback_bottom))
        self.SetRightLocation(Point3D(pt1.x, pt1.y, top_z))

        try:
            self.SetDescription(self.ladder_desc)
        except Exception:
            pass
        _trace("Add() return True")
        return True

    def Edit(self):
        try:
            return self._Edit([self])
        except Exception as exc:
            param.Warning("JBSimpleLadder.Edit: %s" % exc)
        return False

    def _Edit(self, modelList):
        param.Units("feet")
        for m in modelList:
            if not m._run_dialog():
                return False
            try:
                m.SetDescription(m.ladder_desc)
                m.SetPiecemarkPrefix(m.mark_prefix)
            except Exception:
                pass
            top_z = m.top_elev + (m.ext_height
                                  if m.ladder_type != LadderType.ROOF_HATCH
                                  else m.hatch_rail_extension)
            base = m.GetLeftLocation()
            m.SetLeftLocation(Point3D(base.x, base.y,
                                      m.bottom_elev + m.rail_setback_bottom))
            m.SetRightLocation(Point3D(base.x, base.y, top_z))
        return True

    def _run_dialog(self):
        """Open the PySide6 dialog and store the result."""
        try:
            from LadderDialog import run_dialog
        except Exception as exc:
            param.Warning("JBSimpleLadder: dialog unavailable: %s" % exc)
            return False

        st = self.to_state()
        result = run_dialog(st, member_number=self.GetMemberNumber())
        if result is None:
            return False
        self.from_state(result)
        return True

    def CreateMaterial(self):
        _trace("CreateMaterial() enter")
        try:
            return self._CreateMaterial()
        except Exception as exc:
            param.Warning("JBSimpleLadder.CreateMaterial: %s" % exc)
        return False

    def _CreateMaterial(self):
        param.Units("feet")

        self.mem = Member(self.GetMemberNumber())
        try:
            self.SetPiecemarkPrefix(self.mark_prefix)
            self.SetRotation(0.0)
        except Exception:
            pass

        st = self.to_state()
        engine = LadderBuild.LadderGeometry(self, st)
        ok = engine.generate()

        # Always dump the FULL log to disk - no truncation - so a whole
        # run can be reviewed at once instead of a capped alert box.
        path = engine.log.write_file()

        distinct = engine.log.summary()
        if distinct:
            msg = ["JBSimpleLadder: %d warning(s), %d distinct - "
                   "see build log for details:"
                   % (len(engine.log.warnings), len(distinct))]
            msg.append(path or "(could not write build log)")
            param.Warning("\n".join(msg))
        return ok


# ---------------------------------------------------------------------------
# Register with SDS2
# ---------------------------------------------------------------------------
try:
    MemberBase.RegisterMemberType(JBSimpleLadder, "JB Simple Ladder")
except Exception as exc:                              # pragma: no cover
    try:
        param.Warning("JBSimpleLadder registration failed: %s" % exc)
    except Exception:
        pass

# ---------------------------------------------------------------------------
# Plugin defaults setup screen
# ---------------------------------------------------------------------------
# WHY THIS IS A NATIVE Tk DIALOG AND LIVES IN THIS FILE
#
# The first attempt (2026-09-22) put the setup class in LadderDefaults.py
# and had it open the plugin's PySide6 editor. Registering that broke
# SDS2's plugin-defaults screen for EVERY member plugin in the job with
# "cannot pickle 'module' object" - the whole menu, not just our entry.
# PluginSetupTools is compiled into sds2.exe, so what it pickles cannot
# be read to find out precisely why.
#
# What the two plugins that DO work here have in common was the way
# back. JBLintel.py and JBLintelPYQT.py both:
#   * define their setup class in the SAME module as the member class,
#   * build a NATIVE SDS2 Dialog for it, bound through dlg.model, and
#   * register at the bottom of that same module.
# Notably JBLintelPYQT edits its member in PySide6 and still uses a
# native dialog for SETUP, so Qt is fine for a member editor and wrong
# for this. Both of those properties are matched below.
#
# Only the fields that are meaningful as a JOB default are offered. The
# full field set stays in the PySide6 editor, reachable from the
# LadderDefaultsSetup.py macro - a native dialog listing all ~130 would
# be unusable, and duplicating every field in a second UI is exactly the
# maintenance trap this design avoids.
# ---------------------------------------------------------------------------

# (key, widget kind, label, options) per group. Keys are LadderState
# field names - the setup dialog edits a LadderState like everything
# else does, so nothing here needs its own storage or defaults table.
_SETUP_GROUPS = [
    ("General", [
        ("description", "str", "Description:", None),
        ("ladder_type", "combo", "Ladder type:", LadderType.ALL),
        ("standoff", "dim", "Standoff to rung CL:", None),
    ]),
    ("Rails", [
        ("rail_shape", "combo", "Shape:", RailShape.ALL),
        ("rail_section", "mtrl", "Section:", ("Channel", "Angle",
                                              "Tube", "Pipe")),
        ("rail_fb_width", "dim", "Flat bar width:", None),
        ("rail_fb_thick", "dim", "Flat bar thickness:", None),
        ("inside_width", "dim", "Inside width:", None),
    ]),
    ("Rungs", [
        ("rung_shape", "combo", "Shape:", RungShape.ALL),
        ("rung_size", "dim", "Size:", None),
        ("rung_spacing_mode", "combo", "Spacing mode:", RungSpacingMode.ALL),
        ("rung_spacing", "dim", "Spacing:", None),
        ("rung_setback", "dim", "Setback:", None),
        ("hole_clearance", "dim", "Hole clearance:", None),
    ]),
    ("Top, Flare & Return", [
        ("ext_height", "dim", "Extension height:", None),
        ("flare_enabled", "check", "Flare the rails", None),
        ("flare_width", "dim", "Flare width (inside):", None),
        ("flare_angle", "int", "Flare bend angle (deg):", None),
        ("return_enabled", "check", "Return down", None),
        ("return_width", "dim", "Return width:", None),
        ("return_setback", "dim", "Return floor setback:", None),
        ("return_conn", "combo", "Landing connection:", ReturnConnection.ALL),
    ]),
    ("Bottom Connection", [
        ("bottom_conn", "combo", "Type:", BottomConnection.ALL),
        ("bc_ang_size", "mtrl", "Clip angle size:", ("Angle",)),
        ("bc_bolt_dia", "dim", "Bolt diameter:", None),
        ("bp_thick", "dim", "Base plate thickness:", None),
        ("bp_length", "dim", "Base plate length:", None),
        ("bp_width_in", "dim", "Base plate width inside:", None),
        ("bp_width_out", "dim", "Base plate width outside:", None),
    ]),
    ("Intermediate & Gate", [
        ("ic_count", "int", "Intermediate qty:", None),
        ("ic_type", "combo", "Intermediate type:", IntermediateConnection.ALL),
        ("ic_plate_width", "dim", "Standoff plate width:", None),
        ("ic_plate_thick", "dim", "Standoff plate thickness:", None),
        ("ic_toe", "combo", "Standoff toe:", IcToe.ALL),
        ("gate_enabled", "check", "Add security gate", None),
        ("gate_thick", "dim", "Gate thickness:", None),
        ("gate_radius", "dim", "Gate bend radius:", None),
        ("gate_depth", "dim", "Gate projection:", None),
    ]),
]


def _setup_keys():
    """Every LadderState key the setup dialog exposes, flattened."""
    return [k for _title, rows in _SETUP_GROUPS for (k, _w, _l, _o) in rows]


class JBSimpleLadderSetup(object):
    """
    The "JB Simple Ladder Defaults" entry under Job Setup > Plugins.

    Loads the job's saved defaults, shows the curated fields in a native
    SDS2 dialog, and writes back whatever the user accepts. Everything
    it edits is a LadderState field, so the stored blob stays exactly
    what the rest of the plugin already reads.
    """

    def __init__(self):
        param.Units("feet")
        self._build_dialog()

    def _build_dialog(self):
        # Imported here rather than at module scope so loading the
        # plugin does not pull in Tk for every member that gets built -
        # this dialog is the only thing in the file that needs it.
        from dialog import Dialog
        from dialog.frame import Frame, Column
        from dialog.entry import StrEntry, IntEntry
        from dialog.combobox import Combobox
        from dialog.dimension import DimensionEntry
        from dialog.checkbox import Checkbox
        from dialog.choose_file import ChooseMtrl
        from LadderDefaults import load_defaults, save_defaults

        # Each widget class has its own argument shape - label is a
        # keyword for the entries and positional for Combobox/Checkbox -
        # so each kind gets a small placer rather than one generic call.
        self._placers = {
            "dim": lambda c, k, l, o: DimensionEntry(c, k, "dim", label=l),
            "str": lambda c, k, l, o: StrEntry(c, k, label=l),
            "int": lambda c, k, l, o: IntEntry(c, k, label=l),
            "combo": lambda c, k, l, o: Combobox(c, k, list(o), l),
            "check": lambda c, k, l, o: Checkbox(c, k, l),
            "mtrl": lambda c, k, l, o: ChooseMtrl(c, k, tuple(o), label=l),
        }

        state = load_defaults()
        keys = _setup_keys()

        # Same binding shape JBLintel uses: a plain object carrying the
        # current values as attributes, handed to the dialog as its
        # single model row. The widgets read and write it by field name.
        values = {k: getattr(state, k) for k in keys if hasattr(state, k)}
        model_obj = type("LadderDefaults", (), values)()

        dlg = Dialog("JB Simple Ladder - Job Defaults")
        try:
            dlg.window.minsize(width=760, height=620)
        except Exception:
            pass
        dlg.model = [model_obj]

        main = Frame(dlg)
        try:
            main.Pack(fill="both", expand=True)
        except Exception:
            pass

        for title, rows in _SETUP_GROUPS:
            frame = Frame(main, title)
            try:
                frame.widget.config(relief="ridge", bd=3)
            except Exception:
                pass
            row = Frame(frame)
            # Two columns per group, split evenly, so a long group does
            # not run off the bottom of the dialog.
            half = (len(rows) + 1) // 2
            cols = [Column(row), Column(row)]
            for i, (key, kind, label, opts) in enumerate(rows):
                if key not in values:
                    continue
                col = cols[0 if i < half else 1]
                self._place(col, key, kind, label, opts)

        if dlg.Run():
            for k in keys:
                if not hasattr(state, k):
                    continue
                try:
                    setattr(state, k, getattr(model_obj, k))
                except Exception:
                    pass
            save_defaults(state)

    def _place(self, col, key, kind, label, opts):
        """Place one control bound to `key`. Guarded per widget so an
        unsupported one costs its own row rather than the whole
        screen."""
        placer = self._placers.get(kind)
        if placer is None:
            return
        try:
            placer(col, key, label, opts)
        except Exception as exc:
            _trace("setup widget %s (%s) failed: %s" % (key, kind, exc))


# Adds the entry to Job Setup > Plugins. Guarded because
# PluginSetupTools is not present on every install, and because a
# failure here must not stop the member type itself from registering.
try:
    import PluginSetupTools
    PluginSetupTools.RegisterPluginSetup(
        JBSimpleLadder,
        JBSimpleLadderSetup,
        label="JB Simple Ladder Defaults",
        description="Starting values for new JB Simple Ladder members "
                    "in this job")
except Exception as exc:                              # pragma: no cover
    _trace("plugin setup registration skipped: %s" % exc)
