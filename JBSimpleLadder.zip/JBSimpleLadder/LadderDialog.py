"""
=============================================================================
JBSimpleLadder
Copyright (c) 2026 Jason Bondioli

LICENSE AND TERMS OF USE:
Permission is hereby granted to use, copy, modify, and freely distribute 
this software, subject to the following conditions:

1. ATTRIBUTION: Any distribution of this software, whether in its original 
   or modified form, must clearly credit the original author, Jason Bondioli.

2. NO RESALE: This software and any of its derivatives may not be sold or 
   packaged for commercial gain by anyone other than the original author.

3. DISCLAIMER OF LIABILITY: THE SOFTWARE IS PROVIDED "AS IS", WITHOUT 
   WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. In no event shall the author 
   be held responsible for any mishaps, lost work, data loss, or other 
   damages arising from the use of this software or its derivatives. 
=============================================================================
"""

"""
=============================================================================
 JBSimpleLadder - LadderDialog
=============================================================================
 PySide6 dialog. Left = icon tab strip, centre = paged inputs,
 right = docked live preview that never scrolls away.

 Every input widget registers itself with a LadderState key. Focus on a
 widget -> preview highlights the matching dimension and, when the field
 has a blow-up, swaps to that detail automatically.
=============================================================================
"""

import os
import sys

from PySide6 import QtCore, QtGui, QtWidgets

from LadderState import (
    LadderState, LadderType, RailShape, RungShape,
    RungSpacingMode, BottomConnection, BcOSLSide, BcLegOrientation,
    IntermediateConnection, FlareConstruction,
    IntermediateSpacing, ReturnConnection, PickMode,
    HingeSide, IcToe, ElevDatum,
    HSSPunchMode, FIELD_PAGES, fmt_len, parse_len,
)
from LadderPreview import LadderPreview



STYLE = """
QDialog, QWidget#Page { background: #1e2128; color: #d4dae4; font-size: 12px; }
QLabel { color: #aab4c4; }
QLabel#H { color: #e8eef7; font-size: 13px; font-weight: 600; }
QLabel#Sub { color: #6f7a8a; font-size: 12px; }
QGroupBox {
    border: 1px solid #2f3540; border-radius: 6px;
    margin-top: 12px; padding-top: 8px; font-weight: 600; color: #c3ccd9;
    font-size: 12px;
}
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit {
    background: #262a33; border: 1px solid #363c48; border-radius: 4px;
    padding: 3px 6px; color: #e3e9f2; selection-background-color: #ffb648;
    selection-color: #1e2128; font-size: 12px;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QPlainTextEdit:focus {
    border: 1px solid #ffb648; background: #2b303a;
}
QLineEdit[bad="true"] { border: 1px solid #ef5350; }
QComboBox::drop-down { border: none; width: 18px; }
QComboBox QAbstractItemView {
    background: #262a33; border: 1px solid #3a4150;
    selection-background-color: #ffb648; selection-color: #1e2128;
}
QCheckBox, QRadioButton { color: #c3ccd9; spacing: 7px; font-size: 12px; }
QCheckBox::indicator, QRadioButton::indicator { width: 15px; height: 15px; }
QCheckBox::indicator:unchecked, QRadioButton::indicator:unchecked {
    border: 1px solid #4a5261; background: #262a33; border-radius: 3px;
}
QCheckBox::indicator:checked, QRadioButton::indicator:checked {
    border: 1px solid #ffb648; background: #ffb648; border-radius: 3px;
}
QPushButton {
    background: #2d323d; border: 1px solid #3c4351; border-radius: 5px;
    padding: 5px 13px; color: #dbe2ec; font-size: 12px;
}
QPushButton:hover { background: #363d4a; border-color: #4d5666; }
QPushButton#Primary {
    background: #ffb648; color: #1e2128; border: none; font-weight: 600;
}
QPushButton#Primary:hover { background: #ffc46a; }
QListWidget#Nav {
    background: #191c22; border: none; border-right: 1px solid #2b303a;
    outline: 0;
}
QListWidget#Nav::item {
    padding: 8px 12px; color: #8891a1; border-left: 3px solid transparent;
    font-size: 12px;
}
QListWidget#Nav::item:selected {
    background: #232830; color: #ffb648; border-left: 3px solid #ffb648;
}
QListWidget#Nav::item:hover:!selected { background: #1f242b; color: #b9c3d1; }
QScrollArea { border: none; background: transparent; }
QLabel#Issue { color: #ef9a9a; font-size: 12px; }
QLabel#Ok { color: #81c784; font-size: 12px; }
QFrame#Card {
    border: 1px solid #333a46; border-radius: 6px; background: #232831;
}
QFrame#Card[picked="true"] { border: 2px solid #ffb648; background: #2b2f38; }
QPushButton#ValRed {
    background: #ef5350; color: #000000; font-weight: 700; border: none;
}
QPushButton#ValRed:hover { background: #f4726e; }
QPushButton#ValGreen {
    background: #81c784; color: #000000; font-weight: 700; border: none;
}
QPushButton#ValGreen:hover { background: #96d199; }
QPushButton#ValUnknown {
    background: #3a4150; color: #8891a1; font-weight: 600; border: none;
}
"""


class NumpadSubstituteFilter(QtCore.QObject):
    """
    Installable event filter giving a plain QLineEdit the SDS2 numpad
    convention:  +  types a space,  *  types an x.

    LenEdit implements this itself (it needs the same keyPressEvent
    override anyway for its live-parse echo). This filter is for the
    other free-text fields that still want the substitution - section
    size entry, elevation lists - without becoming full dimension
    fields.
    """

    def eventFilter(self, obj, e):
        if e.type() == QtCore.QEvent.Type.KeyPress:
            t = e.text()
            if t == "+":
                obj.insert(" ")
                return True
            if t == "*":
                obj.insert("x")
                return True
        return super().eventFilter(obj, e)


class LenEdit(QtWidgets.QLineEdit):
    """
    SDS2-style dimension entry.

    Accepts   18 | 18.5 | 3/4 | 6 1/2 | 1-6 | 110-2 9/16 | 5\'-6" | 2\'
    Numpad    +  types a space,  *  types an x   (SDS2 convention)

    While the field has focus the raw text is left alone so you can keep
    typing; on commit it is parsed and re-displayed in canonical form.
    A live echo of the parsed value is shown as placeholder-style text
    to the right so there is never any doubt what SDS2 understood.
    """

    def __init__(self, key, dlg, parent=None):
        super().__init__(parent)
        self.key = key
        self.dlg = dlg
        self.setMinimumWidth(90)
        self.editingFinished.connect(self._commit)
        self.textEdited.connect(self._on_edited)
        self._echo = ""

    # -- numpad substitution -------------------------------------------
    def keyPressEvent(self, e):
        t = e.text()
        if t == "+":
            self.insert(" ")
            return
        if t == "*":
            self.insert("x")
            return
        super().keyPressEvent(e)

    def _on_edited(self, txt):
        """Live parse echo, without disturbing what the user is typing."""
        try:
            val = parse_len(txt, None)
        except Exception:
            val = None
        if val is None or not txt.strip():
            self._echo = ""
        else:
            canon = fmt_len(val)
            self._echo = "" if canon == txt.strip() else canon
        self.update()

    def paintEvent(self, e):
        super().paintEvent(e)
        if not self._echo or not self.hasFocus():
            return
        p = QtGui.QPainter(self)
        p.setPen(QtGui.QPen(QtGui.QColor("#6f7a8a")))
        f = self.font()
        f.setPointSize(max(7, f.pointSize() - 1))
        p.setFont(f)
        r = self.rect().adjusted(0, 0, -7, 0)
        p.drawText(r, QtCore.Qt.AlignmentFlag.AlignRight |
                   QtCore.Qt.AlignmentFlag.AlignVCenter, self._echo)
        p.end()

    # -- value binding --------------------------------------------------
    def load(self, value):
        self.blockSignals(True)
        self.setText(fmt_len(value))
        self._echo = ""
        self.blockSignals(False)

    def _commit(self):
        val = parse_len(self.text(), None)
        if val is None:
            val = getattr(self.dlg.state, self.key, 0.0)
        setattr(self.dlg.state, self.key, val)
        self.setText(fmt_len(val))
        self._echo = ""
        self.dlg.refresh()


class NumEdit(QtWidgets.QLineEdit):
    """Plain decimal (angles, counts) bound to a LadderState attribute."""

    def __init__(self, key, dlg, decimals=1, parent=None):
        super().__init__(parent)
        self.key = key
        self.dlg = dlg
        self.decimals = decimals
        self.setMinimumWidth(62)
        self.editingFinished.connect(self._commit)

    def load(self, value):
        self.blockSignals(True)
        self.setText(("%%.%df" % self.decimals) % float(value))
        self.blockSignals(False)

    def _commit(self):
        try:
            val = float(self.text())
        except ValueError:
            val = getattr(self.dlg.state, self.key)
        setattr(self.dlg.state, self.key, val)
        self.load(val)
        self.dlg.refresh()

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.dlg.focus_field(self.key)


class IntSpin(QtWidgets.QSpinBox):
    def __init__(self, key, dlg, lo=0, hi=99, parent=None):
        super().__init__(parent)
        self.key = key
        self.dlg = dlg
        self.setRange(lo, hi)
        self.valueChanged.connect(self._commit)

    def load(self, value):
        self.blockSignals(True)
        self.setValue(int(value))
        self.blockSignals(False)

    def _commit(self, v):
        setattr(self.dlg.state, self.key, int(v))
        self.dlg.rebuild_visibility()
        self.dlg.refresh()

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.dlg.focus_field(self.key)


class Choice(QtWidgets.QComboBox):
    def __init__(self, key, dlg, items, parent=None):
        super().__init__(parent)
        self.key = key
        self.dlg = dlg
        self.addItems(list(items))
        self.currentTextChanged.connect(self._commit)

    def load(self, value):
        self.blockSignals(True)
        i = self.findText(str(value))
        if i >= 0:
            self.setCurrentIndex(i)
        self.blockSignals(False)

    def _commit(self, text):
        setattr(self.dlg.state, self.key, text)
        self.dlg.rebuild_visibility()
        self.dlg.refresh()

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.dlg.focus_field(self.key)


class Check(QtWidgets.QCheckBox):
    def __init__(self, key, dlg, text="", parent=None):
        super().__init__(text, parent)
        self.key = key
        self.dlg = dlg
        self.toggled.connect(self._commit)

    def load(self, value):
        self.blockSignals(True)
        self.setChecked(bool(value))
        self.blockSignals(False)

    def _commit(self, on):
        setattr(self.dlg.state, self.key, bool(on))
        self.dlg.rebuild_visibility()
        self.dlg.refresh()

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.dlg.focus_field(self.key)


class TextEdit(QtWidgets.QLineEdit):
    def __init__(self, key, dlg, parent=None):
        super().__init__(parent)
        self.key = key
        self.dlg = dlg
        self.editingFinished.connect(self._commit)

    def load(self, value):
        self.blockSignals(True)
        self.setText(str(value or ""))
        self.blockSignals(False)

    def _commit(self):
        setattr(self.dlg.state, self.key, self.text())
        self.dlg.refresh()

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.dlg.focus_field(self.key)


class SectionPick(QtWidgets.QWidget):
    """Field + button that opens JBMaterialPicker."""

    def __init__(self, key, dlg, categories=None, parent=None):
        super().__init__(parent)
        self.key = key
        self.dlg = dlg
        self.categories = categories
        lay = QtWidgets.QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        
        self.edit = QtWidgets.QLineEdit()
        self.edit.setPlaceholderText("(no section selected)")
        self.edit.editingFinished.connect(self._commit_text)
        self._numpad_filter = NumpadSubstituteFilter(self)
        self.edit.installEventFilter(self._numpad_filter)

        btn = QtWidgets.QPushButton("Select...")
        btn.setFixedWidth(86)
        btn.clicked.connect(self._pick)
        
        lay.addWidget(self.edit, 1)
        lay.addWidget(btn)

    def load(self, value):
        self.edit.blockSignals(True)
        self.edit.setText(str(value or ""))
        self.edit.blockSignals(False)

    def _commit_text(self):
        """Save the manually typed value back to the ladder state."""
        setattr(self.dlg.state, self.key, self.edit.text().strip())
        self.dlg.rebuild_visibility()
        self.dlg.refresh()

    def _pick(self):
        cur = getattr(self.dlg.state, self.key) or None
        
        try:
            import JBMaterialPicker as _jbm
            import os
            import job
            
            # 1. Grab the repository path and job name directly from the API
            try:
                repo_dir = job.RepositoryPath()
                active_job = job.JobName()
                exact_mtrl_path = os.path.join(repo_dir, active_job, "main", "job_mtrl")
            except Exception as e:
                exact_mtrl_path = None
                print(f"Warning: Could not get Job path from API: {e}")
            
            # 2. Pass the exact path directly to the picker
            name = _jbm.pick_material(
                categories=self.categories, 
                current=cur,
                mtrl_path=exact_mtrl_path, 
                title="Select Rail Section", 
                parent=self.dlg
            )
                
            # 3. Handle the result
            if name:
                setattr(self.dlg.state, self.key, name)
                self.load(name)
                self.dlg.rebuild_visibility()
                self.dlg.refresh()
            else:
                QtWidgets.QMessageBox.warning(
                    self, 
                    "Picker Debug",
                    f"The picker failed to open.\n\n"
                    f"Path attempted: {exact_mtrl_path}\n\n"
                    f"Check if this path exists on your system."
                )
                
        except Exception as exc:
            QtWidgets.QMessageBox.warning(
                self, "Material Picker Error",
                "Could not open picker:\n%s" % exc
            )


class JBSimpleLadderDialog(QtWidgets.QDialog):

    def __init__(self, state=None, parent=None, member_number=None,
                 title="JB Simple Ladder", accept_text="Build Ladder"):
        super().__init__(parent)
        self.state = state or LadderState()
        self.member_number = member_number
        # title/accept_text let the SAME editor serve as the job's
        # defaults screen (LadderDefaults.edit_defaults), where "Build
        # Ladder" would be a lie - nothing is built there, the state is
        # just saved.
        self.accept_text = accept_text
        self.widgets = {}          # key -> widget (for load/refresh)
        self.rows = {}             # key -> (labelwidget, fieldwidget)
        self.groups = {}           # name -> QGroupBox
        # Seeded from the state as loaded, BEFORE the first
        # rebuild_visibility() below, so opening a member that already
        # has its gate on is not treated as switching it on and does
        # not overwrite a width the user set - see _seed_gate_width.
        self._gate_was_enabled = bool(self.state.gate_enabled)
        self.setWindowTitle(title)
        self.setStyleSheet(STYLE)
        # Stay on top of SDS2's own main window even if the user clicks
        # off the dialog - ApplicationModal (set in run_dialog) only
        # blocks OTHER widgets inside this same local QApplication, not
        # SDS2's native windows, so without this the dialog could drop
        # behind SDS2 on an accidental outside click, per a live report.
        self.setWindowFlags(self.windowFlags()
                            | QtCore.Qt.WindowType.WindowStaysOnTopHint)
        self.resize(1120, 760)
        self._build()
        self.load_all()
        self.rebuild_visibility()
        self.refresh()
        self._refresh_status_panel()

    # -----------------------------------------------------------------
    def _build(self):
        root = QtWidgets.QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ---- nav strip, plus the member-status panel docked below it.
        # The nav list is only 6 short rows in a 760px-tall dialog, so
        # there is plenty of room left in this column for it.
        nav_col = QtWidgets.QVBoxLayout()
        nav_col.setContentsMargins(0, 0, 0, 0)
        nav_col.setSpacing(0)
        self.nav = QtWidgets.QListWidget()
        self.nav.setObjectName("Nav")
        for name in FIELD_PAGES:
            QtWidgets.QListWidgetItem(name, self.nav)
        self.nav.currentRowChanged.connect(self._page_changed)
        nav_col.addWidget(self.nav, 1)
        nav_col.addWidget(self._build_status_panel())

        nav_wrap = QtWidgets.QWidget()
        nav_wrap.setFixedWidth(148)
        nav_wrap.setLayout(nav_col)
        root.addWidget(nav_wrap)

        # ---- pages
        centre = QtWidgets.QVBoxLayout()
        centre.setContentsMargins(18, 16, 14, 12)
        centre.setSpacing(10)

        self.title = QtWidgets.QLabel("Location")
        self.title.setObjectName("H")
        centre.addWidget(self.title)

        self.stack = QtWidgets.QStackedWidget()
        self.stack.addWidget(self._page_location())
        self.stack.addWidget(self._page_type())
        self.stack.addWidget(self._page_rails())
        self.stack.addWidget(self._page_rungs())
        self.stack.addWidget(self._page_conns())
        self.stack.addWidget(self._page_gate())
        centre.addWidget(self.stack, 1)

        self.issues = QtWidgets.QLabel("")
        self.issues.setObjectName("Ok")
        self.issues.setWordWrap(True)
        centre.addWidget(self.issues)

        btns = QtWidgets.QHBoxLayout()
        status_btn = QtWidgets.QPushButton("Status...")
        status_btn.clicked.connect(self._status_edit)
        status_btn.setEnabled(self.member_number is not None)
        props_btn = QtWidgets.QPushButton("Properties...")
        props_btn.clicked.connect(self._properties_edit)
        props_btn.setEnabled(self.member_number is not None)
        btns.addWidget(status_btn)
        btns.addWidget(props_btn)
        btns.addStretch(1)
        cancel = QtWidgets.QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        ok = QtWidgets.QPushButton(self.accept_text)
        ok.setObjectName("Primary")
        ok.pressed.connect(self._accept)
        btns.addWidget(cancel)
        btns.addWidget(ok)
        centre.addLayout(btns)

        wrap = QtWidgets.QWidget()
        wrap.setLayout(centre)
        wrap.setMinimumWidth(500)
        root.addWidget(wrap, 1)

        # ---- preview dock
        right = QtWidgets.QVBoxLayout()
        right.setContentsMargins(0, 12, 12, 12)
        right.setSpacing(8)
        bar = QtWidgets.QHBoxLayout()
        self.btn_elev = QtWidgets.QPushButton("Elevation")
        self.btn_side = QtWidgets.QPushButton("Side")
        self.btn_elev.setCheckable(True)
        self.btn_side.setCheckable(True)
        self.btn_elev.setChecked(True)
        self.btn_elev.clicked.connect(lambda: self._manual_view("elevation"))
        self.btn_side.clicked.connect(lambda: self._manual_view("side"))
        bar.addWidget(self.btn_elev)
        bar.addWidget(self.btn_side)
        bar.addStretch(1)
        # Same green/on, red/off treatment the member-status buttons
        # use (ValGreen/ValRed) - the axis gizmo is drawn over the
        # model, so this is the way out when it still lands on the
        # drawing at a given pane size.
        self.btn_ucs = QtWidgets.QPushButton("UCS")
        self.btn_ucs.clicked.connect(self._toggle_ucs)
        bar.addWidget(self.btn_ucs)
        right.addLayout(bar)

        self.preview = LadderPreview(self.state)
        self._paint_ucs_button()
        right.addWidget(self.preview, 1)

        hint = QtWidgets.QLabel(
            "Click any field to highlight its dimension. "
            "Fields with a detail open a blow-up automatically.")
        hint.setObjectName("Sub")
        hint.setWordWrap(True)
        right.addWidget(hint)

        rw = QtWidgets.QWidget()
        rw.setLayout(right)
        rw.setMinimumWidth(400)
        root.addWidget(rw)

        start_row = self.state.last_tab
        if not (0 <= start_row < len(FIELD_PAGES)):
            start_row = 0
        self.nav.setCurrentRow(start_row)

    # -- page construction helpers -------------------------------------
    def _page(self):
        w = QtWidgets.QWidget()
        w.setObjectName("Page")
        v = QtWidgets.QVBoxLayout(w)
        v.setContentsMargins(0, 0, 6, 0)
        v.setSpacing(10)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QtWidgets.QWidget()
        inner.setObjectName("Page")
        form = QtWidgets.QVBoxLayout(inner)
        form.setContentsMargins(2, 2, 10, 2)
        form.setSpacing(9)
        scroll.setWidget(inner)
        v.addWidget(scroll)
        return w, form

    def _group(self, title, parent_layout, name=None):
        box = QtWidgets.QGroupBox(title)
        grid = QtWidgets.QFormLayout(box)
        grid.setContentsMargins(10, 5, 10, 7)
        grid.setSpacing(5)
        grid.setLabelAlignment(QtCore.Qt.AlignmentFlag.AlignRight)
        # Default field growth policy stretches every field to fill the
        # whole column, even a short int spinner or a 4-character length
        # field - the main cause of fields (and the Rungs page as a
        # whole, which has this form's longest labels) being wider than
        # they need to be. Fields now size to their own natural
        # sizeHint instead; each widget's own minimumWidth (LenEdit,
        # NumEdit) still keeps them from getting too cramped.
        grid.setFieldGrowthPolicy(
            QtWidgets.QFormLayout.FieldGrowthPolicy.FieldsStayAtSizeHint)
        parent_layout.addWidget(box)
        if name:
            self.groups[name] = box
        return grid

    def _row(self, grid, label, widget, key=None):
        lab = QtWidgets.QLabel(label)
        grid.addRow(lab, widget)
        if key:
            self.widgets[key] = widget
            self.rows[key] = (lab, widget)
        return widget

    def _build_status_panel(self):
        """
        Bottom-left member-status readout, docked below the nav list:

            Main Mtrl:
            [SYSTEM]/[USER]        (graphic_altered - click to toggle)
            Marked for Detailing:
            [No]/[Yes]             (needs_detail - click to toggle)
            Marked for Processing:
            [No]/[Yes]             (create_3d - click to toggle)
            Model Complete:
            <editable text field>  (model_complete)

        The three boolean readouts are buttons: clicking one flips that
        attribute on the member record directly (see _toggle_bool_attr)
        and repaints from whatever was actually written. Values are
        read straight off model.member(member_number) in
        _read_member_props() - only meaningful for an already-placed
        member; shows "-" throughout otherwise.
        """
        panel = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(panel)
        v.setContentsMargins(10, 8, 8, 10)
        v.setSpacing(2)

        def _hdr(text):
            lab = QtWidgets.QLabel(text)
            lab.setObjectName("Sub")
            v.addWidget(lab)

        def _val_btn(attr_name):
            btn = QtWidgets.QPushButton("-")
            btn.setObjectName("ValUnknown")
            btn.setEnabled(False)
            btn.clicked.connect(
                lambda: self._toggle_bool_attr(attr_name))
            v.addWidget(btn)
            return btn

        _hdr("Main Mtrl:")
        self.status_mtrl_val = _val_btn("graphic_altered")

        v.addSpacing(6)
        _hdr("Marked for Detailing:")
        self.status_detail_val = _val_btn("needs_detail")

        v.addSpacing(6)
        _hdr("Marked for Processing:")
        self.status_process_val = _val_btn("create_3d")

        v.addSpacing(6)
        _hdr("Model Complete:")
        self.status_complete_edit = QtWidgets.QLineEdit()
        self.status_complete_edit.setEnabled(self.member_number is not None)
        self.status_complete_edit.editingFinished.connect(
            self._commit_model_complete)
        v.addWidget(self.status_complete_edit)

        v.addStretch(1)
        return panel

    # -- pages ---------------------------------------------------------
    def _page_location(self):
        page, form = self._page()
        g = self._group("Placement", form)
        pm = Choice("pick_mode", self, PickMode.ALL)
        pm.setEnabled(False)          # set by what you picked, not typed
        pm.setToolTip("Determined when the member is placed: pick one "
                      "point for plan mode, or two for elevation mode.")
        self._row(g, "Pick mode", pm, "pick_mode")
        self._row(g, "Rotation (deg)", NumEdit("rotation", self), "rotation")
        g2 = self._group("Elevations", form)
        self._row(g2, "Bottom (floor)", LenEdit("bottom_elev", self),
                  "bottom_elev")
        self._row(g2, "Top (top of top rung)", LenEdit("top_elev", self),
                  "top_elev")
        self._row(g2, "Standoff to rung CL", LenEdit("standoff", self),
                  "standoff")
        form.addStretch(1)
        return page

    def _page_type(self):
        page, form = self._page()
        g = self._group("Ladder Type", form)
        self._row(g, "Type", Choice("ladder_type", self, LadderType.ALL),
                  "ladder_type")
        self._row(g, "Rungs above top elev",
                  IntSpin("rungs_above_top", self, 0, 12), "rungs_above_top")
        self._row(g, "Rail stub above top",
                  LenEdit("hatch_rail_extension", self),
                  "hatch_rail_extension")
        self._row(g, "Rail setback from bottom",
                  LenEdit("rail_setback_bottom", self),
                  "rail_setback_bottom")

        gs = self._group("Extension", form, name="ext_style")
        self._row(gs, "Extension height", LenEdit("ext_height", self),
                  "ext_height")

        gf = self._group("Flare", form, name="flare")
        self._row(gf, "", Check("flare_enabled", self, "Flare the rails"),
                  "flare_enabled")
        self._row(gf, "Top elev to bend", LenEdit("flare_to_bend", self),
                  "flare_to_bend")
        self._row(gf, "Bend angle",
                  NumEdit("flare_angle", self), "flare_angle")
        self._row(gf, "Flare width (inside)", LenEdit("flare_width", self),
                  "flare_width")
        self._row(gf, "Construction",
                  Choice("flare_construction", self, FlareConstruction.ALL),
                  "flare_construction")
        self._row(gf, "Bend radius (formed only)",
                  LenEdit("flare_radius", self), "flare_radius")

        gr = self._group("Return to Top Level", form, name="ret")
        self._row(gr, "", Check("return_enabled", self, "Return down"),
                  "return_enabled")
        self._row(gr, "Return width", LenEdit("return_width", self),
                  "return_width")
        self._row(gr, "Floor setback", LenEdit("return_setback", self),
                  "return_setback")
        self._row(gr, "Landing connection",
                  Choice("return_conn", self, ReturnConnection.ALL),
                  "return_conn")
        self._row(gr, "Plate thickness", LenEdit("ret_conn_bp_thick", self),
                  "ret_conn_bp_thick")
        self._row(gr, "Plate length (front-back)",
                  LenEdit("ret_conn_bp_length", self), "ret_conn_bp_length")
        self._row(gr, "Center offset",
                  LenEdit("ret_conn_bp_center_offset", self),
                  "ret_conn_bp_center_offset")
        self._row(gr, "Width inside", LenEdit("ret_conn_bp_width_in", self),
                  "ret_conn_bp_width_in")
        self._row(gr, "Width outside",
                  LenEdit("ret_conn_bp_width_out", self),
                  "ret_conn_bp_width_out")
        self._row(gr, "Edge distance inside",
                  LenEdit("ret_conn_bp_edge_in", self),
                  "ret_conn_bp_edge_in")
        self._row(gr, "Edge distance outside",
                  LenEdit("ret_conn_bp_edge_out", self),
                  "ret_conn_bp_edge_out")
        self._row(gr, "Hole dia", LenEdit("ret_conn_bp_hole_dia", self),
                  "ret_conn_bp_hole_dia")
        self._row(gr, "", Check("ret_conn_bp_hole_in_enabled", self,
                                "Inside hole"), "ret_conn_bp_hole_in_enabled")
        self._row(gr, "", Check("ret_conn_bp_hole_out_enabled", self,
                                "Outside hole"),
                  "ret_conn_bp_hole_out_enabled")
        form.addStretch(1)
        return page

    def _page_rails(self):
        page, form = self._page()
        g = self._group("Rail Material", form)
        self._row(g, "Shape", Choice("rail_shape", self, RailShape.ALL),
                  "rail_shape")
        self._row(g, "Section", SectionPick("rail_section", self), "rail_section")

        # OSL side and long-leg orientation are NOT user controls: angle
        # rails are always built OSL Near Side, Long Leg to Rung - see
        # LadderBuild._section_rail/_section_roll (Far Side was never
        # verified working, and ran out of time to pursue it further).
        self._row(g, "Flat bar width", LenEdit("rail_fb_width", self), "rail_fb_width")
        self._row(g, "Flat bar thickness", LenEdit("rail_fb_thick", self), "rail_fb_thick")
        self._row(g, "Inside width", LenEdit("inside_width", self), "inside_width")

        # HSS/Pipe sections only - see rebuild_visibility.
        gc = self._group("End Caps", form, name="caps")
        self._row(gc, "", Check("cap_ends", self, "Cap rail ends"),
                  "cap_ends")
        self._row(gc, "Cap thickness", LenEdit("cap_thick", self),
                  "cap_thick")
        self._row(gc, "Overhang", LenEdit("cap_overhang", self),
                  "cap_overhang")
        self._row(gc, "", Check("cap_top", self, "Cap top"), "cap_top")
        self._row(gc, "", Check("cap_bottom", self, "Cap bottom"),
                  "cap_bottom")
        form.addStretch(1)
        return page

    def _page_rungs(self):
        page, form = self._page()
        g = self._group("Rung Material", form)
        self._row(g, "Shape", Choice("rung_shape", self, RungShape.ALL),
                  "rung_shape")
        self._row(g, "Size (dia / flats)", LenEdit("rung_size", self),
                  "rung_size")

        gp = self._group("Purchased Rung Section", form, name="purch")
        self._row(gp, "Overall width", LenEdit("pr_width", self), "pr_width")
        self._row(gp, "Leg height", LenEdit("pr_height", self), "pr_height")
        self._row(gp, "Thickness", LenEdit("pr_thick", self), "pr_thick")
        self._row(gp, "Inside bend radius", LenEdit("pr_radius", self),
                  "pr_radius")
        self._row(gp, "Description override",
                  TextEdit("pr_description", self), "pr_description")

        gs = self._group("Spacing", form)
        self._row(gs, "Mode",
                  Choice("rung_spacing_mode", self, RungSpacingMode.ALL),
                  "rung_spacing_mode")
        self._row(gs, "Spacing", LenEdit("rung_spacing", self),
                  "rung_spacing")
        self._row(gs, "First rung (min)", LenEdit("first_rung_odd", self),
                  "first_rung_odd")

        gh = self._group("Holes in Rails", form)
        self._row(gh, "Standard Setback", LenEdit("rung_setback", self), "rung_setback")
        
        # NEW: HSS/Pipe Specific Inputs
        self._row(gh, "HSS/Pipe Setback", LenEdit("hss_setback", self), "hss_setback")
        self._row(gh, "HSS Punch Mode", Choice("hss_punch_mode", self, HSSPunchMode.ALL), "hss_punch_mode")
        self._row(gh, "Plug Weld Hole Dia", LenEdit("hss_outer_hole_dia", self), "hss_outer_hole_dia")
        
        self._row(gh, "Hole clearance", LenEdit("hole_clearance", self), "hole_clearance")
        self._row(gh, "Hole dia override", LenEdit("hole_dia_override", self), "hole_dia_override")
        self.lbl_punch = QtWidgets.QLabel("")
        self.lbl_punch.setObjectName("Sub")
        gh.addRow("", self.lbl_punch)
        form.addStretch(1)
        return page

    def _page_conns(self):
        page, form = self._page()
        g = self._group("Bottom Connection", form)
        self._row(g, "Type",
                  Choice("bottom_conn", self, BottomConnection.ALL),
                  "bottom_conn")
        self._row(g, "Angle size", SectionPick("bc_ang_size", self),
                  "bc_ang_size")
        self._row(g, "Angle length", LenEdit("bc_ang_length", self),
                  "bc_ang_length")
        self._row(g, "OSL side",
                  Choice("bc_osl_side", self, BcOSLSide.ALL), "bc_osl_side")
        self._row(g, "Leg orientation",
                  Choice("bc_leg_orientation", self, BcLegOrientation.ALL),
                  "bc_leg_orientation")
        self._row(g, "Bolt dia", LenEdit("bc_bolt_dia", self), "bc_bolt_dia")
        self._row(g, "Bolt qty", IntSpin("bc_bolt_qty", self, 1, 12),
                  "bc_bolt_qty")
        self._row(g, "Weld size", LenEdit("bc_weld_size", self),
                  "bc_weld_size")
        self._row(g, "Plate thickness", LenEdit("bp_thick", self),
                  "bp_thick")
        self._row(g, "Plate length (front-back)", LenEdit("bp_length", self),
                  "bp_length")
        self._row(g, "Center offset", LenEdit("bp_center_offset", self),
                  "bp_center_offset")
        self._row(g, "Width inside", LenEdit("bp_width_in", self),
                  "bp_width_in")
        self._row(g, "Width outside", LenEdit("bp_width_out", self),
                  "bp_width_out")
        self._row(g, "Hole dia", LenEdit("bp_hole_dia", self), "bp_hole_dia")
        self._row(g, "Edge distance inside", LenEdit("bp_edge_in", self),
                  "bp_edge_in")
        self._row(g, "Edge distance outside", LenEdit("bp_edge_out", self),
                  "bp_edge_out")
        self._row(g, "", Check("bp_hole_in_enabled", self, "Inside hole"),
                  "bp_hole_in_enabled")
        self._row(g, "", Check("bp_hole_out_enabled", self, "Outside hole"),
                  "bp_hole_out_enabled")

        gi = self._group("Intermediate Connections", form)
        self._row(gi, "Quantity", IntSpin("ic_count", self, 0, 24),
                  "ic_count")
        self._row(gi, "Spacing",
                  Choice("ic_spacing_mode", self, IntermediateSpacing.ALL),
                  "ic_spacing_mode")
        self.ic_elev_edit = QtWidgets.QLineEdit()
        self.ic_elev_edit.setPlaceholderText("e.g. 4'-0, 8'-0, 12'-0")
        self.ic_elev_edit.editingFinished.connect(self._commit_ic_elevs)
        self._ic_elev_numpad_filter = NumpadSubstituteFilter(self)
        self.ic_elev_edit.installEventFilter(self._ic_elev_numpad_filter)
        self._row(gi, "Elevations", self.ic_elev_edit, "ic_elevations")
        self._row(gi, "Elevations measured from",
                  Choice("ic_elev_datum", self, ElevDatum.ALL),
                  "ic_elev_datum")
        self._row(gi, "Type",
                  Choice("ic_type", self, IntermediateConnection.ALL),
                  "ic_type")
        self._row(gi, "Plate width", LenEdit("ic_plate_width", self),
                  "ic_plate_width")
        self._row(gi, "Plate thickness", LenEdit("ic_plate_thick", self),
                  "ic_plate_thick")
        self._row(gi, "Leg (against rail)", LenEdit("ic_leg", self),
                  "ic_leg")
        self._row(gi, "OSL length (at support)", LenEdit("ic_osl", self),
                  "ic_osl")
        self._row(gi, "Bend radius", LenEdit("ic_bend_radius", self),
                  "ic_bend_radius")
        self._row(gi, "Bend angle (deg)", NumEdit("ic_bend_angle", self),
                  "ic_bend_angle")
        self._row(gi, "Toe direction", Choice("ic_toe", self, IcToe.ALL),
                  "ic_toe")
        self._row(gi, "Bolt dia", LenEdit("ic_bolt_dia", self), "ic_bolt_dia")
        self._row(gi, "Gage (heel to bolt)", LenEdit("ic_gage", self),
                  "ic_gage")

        form.addStretch(1)
        return page

    def _page_gate(self):
        page, form = self._page()
        g = self._group("Security Gate", form)
        self._row(g, "", Check("gate_enabled", self, "Add security gate"),
                  "gate_enabled")
        self._row(g, "Elevations measured from",
                  Choice("gate_elev_datum", self, ElevDatum.ALL),
                  "gate_elev_datum")
        self._row(g, "Bottom elevation",
                  LenEdit("gate_bottom_elev", self), "gate_bottom_elev")
        self._row(g, "Top elevation",
                  LenEdit("gate_top_elev", self), "gate_top_elev")
        self._row(g, "Hinge side",
                  Choice("gate_hinge_side", self, HingeSide.ALL),
                  "gate_hinge_side")
        self._row(g, "Outside width", LenEdit("gate_width", self),
                  "gate_width")
        self._row(g, "Depth (climb-side projection)",
                  LenEdit("gate_depth", self), "gate_depth")
        self._row(g, "Plate thickness", LenEdit("gate_thick", self),
                  "gate_thick")
        self._row(g, "Bend radius", LenEdit("gate_radius", self),
                  "gate_radius")

        gh = self._group("Hinges", form, name="gate_hinges")
        self._row(gh, "Quantity", IntSpin("gate_hinge_qty", self, 1, 12),
                  "gate_hinge_qty")
        self._row(gh, "Offset from each end",
                  LenEdit("gate_hinge_offset", self), "gate_hinge_offset")
        self._row(gh, "Plate width", LenEdit("gate_hinge_width", self),
                  "gate_hinge_width")
        self._row(gh, "Plate height", LenEdit("gate_hinge_height", self),
                  "gate_hinge_height")
        self._row(gh, "Plate thickness", LenEdit("gate_hinge_thick", self),
                  "gate_hinge_thick")
        self._row(gh, "Description override",
                  TextEdit("gate_hinge_description", self),
                  "gate_hinge_description")

        gp = self._group("Hasp", form, name="gate_hasp_grp")
        self._row(gp, "", Check("gate_hasp", self, "Lockable hasp"),
                  "gate_hasp")
        self._row(gp, "Plate width - gate side",
                  LenEdit("gate_hasp_w_gate", self), "gate_hasp_w_gate")
        self._row(gp, "Plate width - rail side",
                  LenEdit("gate_hasp_w_rail", self), "gate_hasp_w_rail")
        self._row(gp, "Edge distance to hole",
                  LenEdit("gate_hasp_edge_dist", self),
                  "gate_hasp_edge_dist")
        self._row(gp, "Plate height", LenEdit("gate_hasp_height", self),
                  "gate_hasp_height")
        self._row(gp, "Plate thickness", LenEdit("gate_hasp_thick", self),
                  "gate_hasp_thick")
        self._row(gp, "Padlock hole dia",
                  LenEdit("gate_hasp_hole_dia", self), "gate_hasp_hole_dia")
        self._row(gp, "Elevation offset (from gate center)",
                  LenEdit("gate_hasp_offset", self), "gate_hasp_offset")
        form.addStretch(1)
        return page

    # -- behaviour ------------------------------------------------------
    def _page_changed(self, row):
        if 0 <= row < self.stack.count():
            self.stack.setCurrentIndex(row)
            self.title.setText(FIELD_PAGES[row])
            self.state.last_tab = row

    def _rail_across_estimate(self):
        """
        Across-the-ladder extent of ONE rail. Resolved through the
        build's own _rail_across so the seeded gate width matches what
        actually gets built rather than a second approximation of it -
        LadderBuild imports fine without SDS2 (see its HAVE_SDS2
        guard), and the live Shape lookup inside _rail_across succeeds
        whenever the dialog is running inside SDS2, which is the case
        that matters here.

        Falls back to LadderState's own rough reach when that lookup
        cannot resolve (no live job), since _rail_across returns 0 for
        an unresolvable section and a 0 here would seed a gate exactly
        as wide as the ladder is inside.
        """
        try:
            from LadderBuild import LadderGeometry
            across = LadderGeometry(None, self.state)._rail_across()
        except Exception:
            across = 0.0
        if across > 0:
            return across
        return self.state.rail_outside_reach

    def _seed_gate_width(self):
        """Gate just switched on: start it at the rails' own outside-to-
        outside dimension (inside width plus one rail across each side),
        which is what it has to close against. Only ever fires on that
        off->on transition, so a width the user has since typed is never
        overwritten."""
        s = self.state
        s.gate_width = s.inside_width + 2.0 * self._rail_across_estimate()
        w = self.widgets.get("gate_width")
        if w is not None:
            w.load(s.gate_width)

    def _toggle_ucs(self):
        self.preview.set_ucs_visible(not self.preview.show_ucs)
        self._paint_ucs_button()

    def _paint_ucs_button(self):
        on = self.preview.show_ucs
        self.btn_ucs.setText("UCS On" if on else "UCS Off")
        self.btn_ucs.setObjectName("ValGreen" if on else "ValRed")
        self.btn_ucs.style().unpolish(self.btn_ucs)
        self.btn_ucs.style().polish(self.btn_ucs)

    def _manual_view(self, name):
        self.btn_elev.setChecked(name == "elevation")
        self.btn_side.setChecked(name == "side")
        self.preview.set_focus_key(None)
        self.preview.set_view(name)

    def focus_field(self, key):
        self.preview.set_focus_key(key)
        v = self.preview.view
        self.btn_elev.setChecked(v == "elevation")
        self.btn_side.setChecked(v == "side")

    def _commit_ic_elevs(self):
        txt = self.ic_elev_edit.text()
        vals = []
        for part in txt.replace(";", ",").split(","):
            part = part.strip()
            if part:
                vals.append(parse_len(part, 0.0))
        self.state.ic_elevations = vals
        self.refresh()

    def load_all(self):
        for key, w in self.widgets.items():
            if hasattr(w, "load"):
                try:
                    w.load(getattr(self.state, key))
                except Exception:
                    pass
        self.ic_elev_edit.setText(
            ", ".join(fmt_len(v) for v in self.state.ic_elevations))

    def _show_row(self, key, on):
        pair = self.rows.get(key)
        if not pair:
            return
        lab, w = pair
        lab.setVisible(on)
        w.setVisible(on)

    def rebuild_visibility(self):
        s = self.state
        # Runs on every Check/Choice/IntSpin commit, so it is where the
        # gate being switched ON gets noticed - see _seed_gate_width.
        if s.gate_enabled and not self._gate_was_enabled:
            self._seed_gate_width()
        self._gate_was_enabled = bool(s.gate_enabled)

        is_fb = s.rail_shape == RailShape.FLAT_BAR
        section = (s.rail_section or "").upper()
        
        self._show_row("rail_section", not is_fb)
        self._show_row("rail_fb_width", is_fb)
        self._show_row("rail_fb_thick", is_fb)
        
        # No orientation control is shown at all now: OSL side and
        # long-leg orientation are hardcoded for angle rails, and
        # channel/round tube/pipe get no orientation control now that
        # toe in/out has been removed as a user choice too.

        # HSS/Pipe Hole Logic
        is_hss_pipe = section.startswith("HSS") or section.startswith("PIPE")
        self._show_row("rung_setback", not is_hss_pipe)
        self._show_row("hss_setback", is_hss_pipe)
        self._show_row("hss_punch_mode", is_hss_pipe)
        self._show_row("hss_outer_hole_dia", is_hss_pipe and s.hss_punch_mode == HSSPunchMode.PLUG_WELD)

        # End caps: HSS/Pipe sections only. If the shape was just
        # changed away from HSS/Pipe while cap_ends was left on from a
        # prior section, force it off (and uncheck the box) instead of
        # leaving a stale True behind a hidden control.
        if not is_hss_pipe and s.cap_ends:
            s.cap_ends = False
            if "cap_ends" in self.widgets:
                self.widgets["cap_ends"].load(False)

        self._show_row("cap_thick", s.cap_ends)
        self._show_row("cap_overhang", s.cap_ends)
        self._show_row("cap_top", s.cap_ends)
        self._show_row("cap_bottom", s.cap_ends)
        if "caps" in self.groups:
            self.groups["caps"].setVisible(is_hss_pipe)

        # Purchased/buyout rungs weld to a flat inside face - a round
        # rail has none, so that option is pulled from the combo (not
        # just hidden once picked) whenever the rail is round, and any
        # rung_shape left on Purchased from before the rail was changed
        # is bumped back to Round Bar instead of silently building
        # against a round rail it can't actually attach to.
        rung_combo = self.widgets.get("rung_shape")
        if rung_combo is not None:
            if s.rail_is_round and s.rung_shape == RungShape.PURCHASED:
                s.rung_shape = RungShape.ROUND_BAR
            wanted = [v for v in RungShape.ALL
                     if v != RungShape.PURCHASED or not s.rail_is_round]
            have = [rung_combo.itemText(i)
                   for i in range(rung_combo.count())]
            if have != wanted:
                rung_combo.blockSignals(True)
                rung_combo.clear()
                rung_combo.addItems(wanted)
                rung_combo.blockSignals(False)
            rung_combo.load(s.rung_shape)

        purch = s.rung_shape == RungShape.PURCHASED
        if "purch" in self.groups:
            self.groups["purch"].setVisible(purch)
        self._show_row("rung_size", not purch)
        # Buyout rungs weld to the inside face: no setback, no holes.
        for k in ("rung_setback", "hole_clearance", "hole_dia_override"):
            self._show_row(k, not purch)

        self._show_row("first_rung_odd",
                       s.rung_spacing_mode == RungSpacingMode.ODD_FIRST)

        st = s.ladder_type
        self._show_row("rungs_above_top", st == LadderType.SIDE_STEP)
        self._show_row("hatch_rail_extension",
                       st in (LadderType.ROOF_HATCH, LadderType.SIDE_STEP))
        if "ext_style" in self.groups:
            self.groups["ext_style"].setVisible(st == LadderType.STEP_THROUGH)
        if "flare" in self.groups:
            self.groups["flare"].setVisible(st == LadderType.STEP_THROUGH)
        flare_shown = st == LadderType.STEP_THROUGH and s.flare_enabled
        for k in ("flare_to_bend", "flare_angle", "flare_width"):
            self._show_row(k, flare_shown)

        # Bent (formed) flare/rail is only built for flat bar rails - see
        # LadderBuild.build_flare. If the rail shape is switched away from
        # flat bar while a bent construction was selected, fall back to
        # Cut & Welded instead of leaving a stale, now-inapplicable choice
        # behind a hidden control (same pattern cap_ends already uses for
        # HSS/Pipe).
        is_bent_flare = s.flare_construction in (
            FlareConstruction.BEND_FLARE, FlareConstruction.BEND_FULL_RAIL)
        if not is_fb and is_bent_flare:
            s.flare_construction = FlareConstruction.CUT_WELDED
            is_bent_flare = False
            if "flare_construction" in self.widgets:
                self.widgets["flare_construction"].load(
                    FlareConstruction.CUT_WELDED)
        self._show_row("flare_construction", flare_shown and is_fb)
        self._show_row("flare_radius",
                       flare_shown and is_fb and is_bent_flare)
        if "ret" in self.groups:
            self.groups["ret"].setVisible(st == LadderType.STEP_THROUGH)
        for k in ("return_width", "return_setback", "return_conn"):
            self._show_row(k, st == LadderType.STEP_THROUGH
                           and s.return_enabled)

        bc = s.bottom_conn
        clip = bc in (BottomConnection.BOLT_BOLT_ANGLE,
                      BottomConnection.BOLT_WELD_ANGLE)
        for k in ("bc_ang_size", "bc_ang_length", "bc_osl_side",
                  "bc_leg_orientation", "bc_bolt_dia", "bc_bolt_qty"):
            self._show_row(k, clip)
        self._show_row("bc_weld_size",
                       bc == BottomConnection.BOLT_WELD_ANGLE)
        base_plate = bc == BottomConnection.BASE_PLATE
        for k in ("bp_thick", "bp_length", "bp_center_offset",
                  "bp_width_in", "bp_width_out", "bp_hole_dia",
                  "bp_edge_in", "bp_edge_out", "bp_hole_in_enabled",
                  "bp_hole_out_enabled"):
            self._show_row(k, base_plate)

        has_ic = s.ic_count > 0
        for k in ("ic_spacing_mode", "ic_type", "ic_plate_width",
                  "ic_plate_thick"):
            self._show_row(k, has_ic)
        at_elevs = (has_ic
                    and s.ic_spacing_mode == IntermediateSpacing.AT_ELEVATIONS)
        self._show_row("ic_elevations", at_elevs)
        self._show_row("ic_elev_datum", at_elevs)
        # Leg/bend fields only mean anything for a bent standoff - the
        # explicit Flat Plate type has no bend to configure.
        is_bent = has_ic and s.ic_is_bent
        for k in ("ic_osl", "ic_bend_radius", "ic_bend_angle", "ic_toe"):
            self._show_row(k, is_bent)
        # Hidden, not deleted. The bent standoff's rail leg has to span
        # exactly "Standoff to rung CL" on the Geometry page to reach the
        # support, and the Flat Plate type spans the same distance, so
        # ic_leg drives nothing in either branch - leaving the box live
        # would just invite typing a number that gets ignored. The state
        # field is kept so existing members still load.
        self._show_row("ic_leg", False)
        # Bolt fields only matter when the OSL is actually bolted - the
        # rail leg is always welded now (BENT_BOLT_BOLT was removed).
        has_bolts = has_ic and s.ic_osl_bolted
        for k in ("ic_bolt_dia", "ic_gage"):
            self._show_row(k, has_bolts)

        ret_has = s.has_return
        ret_base_plate = (ret_has
                          and s.return_conn == ReturnConnection.BASE_PLATE)
        for k in ("ret_conn_bp_thick", "ret_conn_bp_length",
                  "ret_conn_bp_center_offset", "ret_conn_bp_width_in",
                  "ret_conn_bp_width_out", "ret_conn_bp_edge_in",
                  "ret_conn_bp_edge_out", "ret_conn_bp_hole_dia",
                  "ret_conn_bp_hole_in_enabled",
                  "ret_conn_bp_hole_out_enabled"):
            self._show_row(k, ret_base_plate)

        gate = s.gate_enabled
        for k in ("gate_elev_datum", "gate_bottom_elev", "gate_top_elev",
                  "gate_hinge_side", "gate_width", "gate_depth",
                  "gate_thick", "gate_radius"):
            self._show_row(k, gate)
        for k in ("gate_hinge_qty", "gate_hinge_offset", "gate_hinge_width",
                  "gate_hinge_height", "gate_hinge_thick",
                  "gate_hinge_description"):
            self._show_row(k, gate)
        if "gate_hinges" in self.groups:
            self.groups["gate_hinges"].setVisible(gate)

        self._show_row("gate_hasp", gate)
        hasp_shown = gate and s.gate_hasp
        for k in ("gate_hasp_w_gate", "gate_hasp_w_rail",
                  "gate_hasp_edge_dist", "gate_hasp_height",
                  "gate_hasp_thick", "gate_hasp_hole_dia",
                  "gate_hasp_offset"):
            self._show_row(k, hasp_shown)
        if "gate_hasp_grp" in self.groups:
            self.groups["gate_hasp_grp"].setVisible(gate)

    def _bc_channel_fit_issue(self):
        """
        Channel rail + OSL Outside clip: the clip either nests inside
        the channel against the web (bc_ang_length <= T, the clear
        flat width between fillets, T = Depth - 2*k1), or is long
        enough to reach past the flanges and rest against their toes
        instead (bc_ang_length >= the channel's full Depth). Anything
        strictly between those two collides with the fillet - not a
        buildable geometry - flagged here so the user sees it before
        generating material, per the user's explicit request.

        SDS2-dependent (Shape()), so this lives here rather than in
        LadderState.validate() (kept SDS2-free so it stays standalone
        testable) - same reasoning bc_ang_size's SectionPick already
        relies on SDS2 being live to run this dialog at all.

        k1 is NOT a confirmed Shape() attribute name - tried across a
        few plausible candidates, falling back to FlangeThickness (a
        real approximation, ignoring the fillet radius) if none exist.
        """
        s = self.state
        if s.bottom_conn not in (BottomConnection.BOLT_BOLT_ANGLE,
                                 BottomConnection.BOLT_WELD_ANGLE):
            return None
        if s.bc_osl_side != BcOSLSide.OUTSIDE:
            return None
        sec = (s.rail_section or "").upper()
        if s.rail_shape != RailShape.SECTION or not sec.startswith(("C", "MC")):
            return None
        try:
            from shape import Shape
            shp = Shape(s.rail_section)
            depth = float(shp.Depth)
            k1 = 0.0
            for attr in ("K1", "K_1", "Kdim1", "K"):
                if hasattr(shp, attr):
                    try:
                        v = float(getattr(shp, attr))
                    except Exception:
                        continue
                    if v > 0:
                        k1 = v
                        break
            if k1 <= 0:
                k1 = float(shp.FlangeThickness)
        except Exception:
            return None
        t = depth - 2.0 * k1
        L = s.bc_ang_length
        if L <= t + 1e-6 or L >= depth - 1e-6:
            return None
        return ("warn", "bc_ang_length",
               "Clip angle will not fit between k of channel (fits up to "
               "%s, or needs %s+ to reach the flange toes)."
               % (fmt_len(t), fmt_len(depth)))

    def refresh(self):
        self.load_all()
        self.preview.set_state(self.state)
        self.preview.update()

        if hasattr(self, "lbl_punch"):
            s = self.state
            if s.rung_shape == RungShape.PURCHASED:
                self.lbl_punch.setText(
                    "Buyout rung: welded to the inside face of each rail. "
                    "No holes, no setback.")
            elif s.is_closed_shape:
                self.lbl_punch.setText(
                    "Closed shape: holes punched on the INSIDE face only. "
                    "Rung ends %s from outside of rail."
                    % fmt_len(s.rung_setback))
            else:
                self.lbl_punch.setText(
                    "Flat bar: holes punched through. Rung ends %s back "
                    "from the outside of each rail (0 = flush)."
                    % fmt_len(s.rung_setback))

        issues = self.state.validate()
        extra = self._bc_channel_fit_issue()
        if extra:
            issues = issues + [extra]
        if not issues:
            self.issues.setObjectName("Ok")
            n = len(self.state.rung_elevations())
            self.issues.setText("Ready  ~  %d rungs, climb %s, inside %s"
                                % (n, fmt_len(self.state.climb_height),
                                   fmt_len(self.state.inside_width)))
        else:
            self.issues.setObjectName("Issue")
            self.issues.setText("  |  ".join(m for _, _, m in issues[:3]))
        self.issues.style().unpolish(self.issues)
        self.issues.style().polish(self.issues)

        invalid_keys = {key for _, key, _ in issues if key}
        for key, w in self.widgets.items():
            w.setStyleSheet(
                "border: 1px solid #ef5350;" if key in invalid_keys else "")

    def _status_edit(self):
        """Same SDS2 member-status dialog JBLintel's Status button opens
        (Status.EditMemberStatus), for this member alone."""
        if self.member_number is None:
            return
        try:
            from Status import EditMemberStatus
            EditMemberStatus([self.member_number])
        except Exception as exc:
            QtWidgets.QMessageBox.warning(
                self, "Status", "Could not open member status:\n%s" % exc)
        # EditMemberStatus is modal (same as SDS2's own toolbar Status
        # button) - re-read afterward so the panel reflects whatever the
        # user just changed there.
        self._refresh_status_panel()

    def _read_member_props(self):
        """
        Read the SDS2 member-record fields the status panel shows,
        straight off model.member() - graphic_altered, needs_detail,
        create_3d and model_complete are confirmed attribute names on
        this object (unlike the old detailing/graphical strip this
        replaced, which had to guess at candidate names). Returns a
        dict; any field that can't be read (missing member_number, a
        transient model access failure, or an older member record
        without the attribute) comes back None rather than guessed at.
        """
        empty = {"graphic_altered": None, "needs_detail": None,
                 "create_3d": None, "model_complete": None}
        if self.member_number is None:
            return empty
        try:
            import model
            m = model.member(self.member_number)
        except Exception:
            return empty

        def _get(name):
            try:
                return getattr(m, name)
            except Exception:
                return None

        return {
            "graphic_altered": _get("graphic_altered"),
            "needs_detail": _get("needs_detail"),
            "create_3d": _get("create_3d"),
            "model_complete": _get("model_complete"),
        }

    def _refresh_status_panel(self):
        """Repaint the Main Mtrl / Marked for Detailing / Marked for
        Processing readouts and (re)load the Model Complete field from
        _read_member_props(). Safe to call any time, including before
        member_number is known (shows "-" throughout)."""
        props = self._read_member_props()

        def _paint(btn, value, red_text, green_text):
            btn.setEnabled(self.member_number is not None
                           and value is not None)
            if value is None:
                btn.setText("-")
                btn.setObjectName("ValUnknown")
            else:
                on = bool(value)
                btn.setText(red_text if on else green_text)
                btn.setObjectName("ValRed" if on else "ValGreen")
            btn.style().unpolish(btn)
            btn.style().polish(btn)

        _paint(self.status_mtrl_val, props["graphic_altered"],
               "USER", "SYSTEM")
        _paint(self.status_detail_val, props["needs_detail"], "Yes", "No")
        _paint(self.status_process_val, props["create_3d"], "Yes", "No")

        if not self.status_complete_edit.hasFocus():
            self._load_model_complete_display(props["model_complete"])

    def _toggle_bool_attr(self, attr_name):
        """Flip a boolean member attribute (graphic_altered, needs_detail
        or create_3d) and write it straight back, same WriteOnlyThis
        pattern as _commit_model_complete."""
        if self.member_number is None:
            return
        try:
            import model
            m = model.member(self.member_number)
            setattr(m, attr_name, not bool(getattr(m, attr_name)))
            model.WriteOnlyThis(m)
        except Exception as exc:
            QtWidgets.QMessageBox.warning(
                self, "Member Status",
                "Could not update %s:\n%s" % (attr_name, exc))
        self._refresh_status_panel()

    def _load_model_complete_display(self, value):
        self.status_complete_edit.blockSignals(True)
        if not value or str(value).strip() == "0":
            self.status_complete_edit.setText("**NOT SET**")
        else:
            self.status_complete_edit.setText(str(value))
        self.status_complete_edit.blockSignals(False)

    def _commit_model_complete(self):
        """Write the Model Complete field back to the member record.
        Typing 0 (or clearing the field) is treated as un-setting it -
        displayed as **NOT SET** - rather than as the literal text 0.

        Writes ONLY when the value actually changed. editingFinished
        fires on every focus-out, not just on an edit, so an
        unconditional write here meant merely tabbing through the
        dialog wrote the member record back - which is what was
        flagging the main material as USER (graphic_altered) just for
        opening and adjusting unrelated fields. No change, no write."""
        if self.member_number is None:
            return
        txt = self.status_complete_edit.text().strip()
        if txt in ("", "0", "**NOT SET**"):
            self.status_complete_edit.setText("**NOT SET**")
            new_val = 0
        else:
            new_val = txt

        current = self._read_member_props().get("model_complete")
        current_norm = 0 if (not current or str(current).strip() == "0") \
            else str(current)
        new_norm = 0 if new_val == 0 else str(new_val)
        if new_norm == current_norm:
            return

        try:
            import model
            m = model.member(self.member_number)
            m.model_complete = new_val
            model.WriteOnlyThis(m)
        except Exception as exc:
            QtWidgets.QMessageBox.warning(
                self, "Model Complete",
                "Could not update model_complete:\n%s" % exc)
        self._refresh_status_panel()

    def _properties_edit(self):
        """Same SDS2 member-properties dialog JBLintel's Properties
        button opens (CustomProperties.EditMemberProperties)."""
        if self.member_number is None:
            return
        try:
            from CustomProperties import EditMemberProperties
            EditMemberProperties([self.member_number])
        except Exception as exc:
            QtWidgets.QMessageBox.warning(
                self, "Properties",
                "Could not open member properties:\n%s" % exc)

    def _accept(self):
        errs = [m for sev, _, m in self.state.validate() if sev == "error"]
        if errs:
            QtWidgets.QMessageBox.warning(
                self, "Cannot build", "\n".join(errs))
            return
        self.accept()


# ---------------------------------------------------------------------------
# Dialog driver
#
# Two separate problems make a naive exec() require pressing the button
# twice inside SDS2:
#
#   1. Calling app.quit() after the first run leaves a dead QApplication
#      behind, so later calls never show a window.
#   2. SDS2 may ALREADY own a Qt event loop (it ships PySide6 itself).
#      Calling exec() re-entrantly inside a running loop can return
#      immediately with a false result the first time.
#
# The fix is to keep the application alive for the whole session AND to
# spin our own local event loop rather than relying on exec().
# ---------------------------------------------------------------------------
_QAPP = None


def _ensure_app():
    """Get or create the QApplication, keeping it alive for the session."""
    global _QAPP
    app = QtWidgets.QApplication.instance()
    if app is None:
        app = QtWidgets.QApplication(sys.argv if sys.argv else [""])
        _QAPP = app
    return app


def run_dialog(state=None, parent=None, member_number=None,
               title="JB Simple Ladder", accept_text="Build Ladder"):
    """
    Show the ladder dialog modally and return the edited LadderState,
    or None if the user cancelled.

    Safe to call repeatedly within one SDS2 session, and safe to call
    from inside an event loop SDS2 already started.

    member_number, when given, enables the Status/Properties buttons
    (JBLintel's own Status/Properties pattern - Status.EditMemberStatus/
    CustomProperties.EditMemberProperties - applied to this one member).

    title/accept_text are for the job-defaults screen, which runs this
    same editor over the saved defaults instead of a real member - see
    LadderDefaults.edit_defaults.
    """
    app = _ensure_app()

    dlg = JBSimpleLadderDialog(state, parent, member_number=member_number,
                               title=title, accept_text=accept_text)
    dlg.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
    dlg.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, False)

    # Drive our own loop so we do not depend on exec() behaving well
    # when SDS2 already has one running.
    loop = QtCore.QEventLoop()
    outcome = {"code": None}

    def _finished(code):
        outcome["code"] = code
        loop.quit()

    dlg.finished.connect(_finished)

    dlg.show()
    dlg.raise_()
    dlg.activateWindow()
    app.processEvents()

    # Guard against the window never appearing (which is what produced
    # the "press it twice" symptom): if it is not visible after the first
    # event pass, force it again before entering the loop.
    if not dlg.isVisible():
        dlg.show()
        app.processEvents()

    loop.exec()

    code = outcome["code"]
    if code is None:
        code = dlg.result()
    result = dlg.state if code == QtWidgets.QDialog.DialogCode.Accepted \
        else None

    dlg.deleteLater()
    app.processEvents()
    return result


if __name__ == "__main__":
    st = run_dialog()
    print("accepted:", bool(st))
    if st:
        print(st.to_json()[:400])
