"""
=============================================================================
 JBSimpleLadder - LadderBuild
=============================================================================
 Geometry engine, written against the ACTUAL SDS2 2027 material API as
 verified in a known-working custom member (JBLintel).

 API conventions that matter (they are NOT consistent between classes):

   RolledSection  -> PascalCase:  .Member .Point1 .Point2 .SectionSize
                                  .MaterialType .MaterialGrade .Add()
   RectPlate      -> snake_case:  .member .pt1 .pt2 .width .thick .add()
   RndBar/SqrBar/FlatBar/BntPlate -> snake_case, same family as RectPlate
   Hole           -> .mtrl .pt1 .face .hole_type .bolt_dia .hole_dia
                     .create()
 SINGLE-FACE PUNCHING
 --------------------
 Hole.face takes a face string ('NS Face', 'FS Face', 'Top Face',
 'Bottom Face'). Punching ONE named face is exactly the "hole on the
 inside face only" behaviour a closed shape needs - no special flag
 required, just do not punch the opposite face.

 Every material is positioned by building a Transform3D from the member
 xform and applying it after .Add()/.add(), same as JBLintel.
=============================================================================
"""

import math
import os

from LadderState import (
    LadderType, RailShape, RungShape,
    BottomConnection, BcOSLSide, BcLegOrientation,
    IntermediateConnection, ReturnConnection, fmt_len,
    HSSPunchMode, FlareConstruction, HingeSide, IcToe, parse_angle_legs
)

try:
    import param
    import Transform3D
    from Point3D import Point3D
    from point import Point, PointLocate
    from member import Member
    from rolled_section import RolledSection
    from rect_plate import RectPlate
    from rnd_bar import RndBar
    from sqr_bar import SqrBar
    from flat_bar import FlatBar
    from hole_add import Hole
    from job import Job
    from shape import Shape
    HAVE_SDS2 = True
except ImportError:                                   # pragma: no cover
    HAVE_SDS2 = False
    Point3D = None

# Bent-plate material access - kept as SEPARATE, independently-optional
# imports (not folded into the HAVE_SDS2 block above) so a plugin that is
# missing/renamed on this SDS2 install cannot take the whole member down
# with it. Which of these actually resolves on-station is UNCONFIRMED -
# see probe_bentplate_with_member() at the bottom of this file, and
# _bent_plate_layout_piece()/_bent_plate_standoff(), which try every
# available candidate in turn and log which one worked.
try:
    import plate_layout as _plate_layout_mod
except ImportError:                                   # pragma: no cover
    _plate_layout_mod = None
try:
    import Designable.Proxies as DP
except ImportError:                                   # pragma: no cover
    DP = None

# Legacy Layout3D - same schema REFERENCE/BentRodMtrl.py uses for a bent
# round bar/pipe (add_node(point, radius) + set_depth_vectors(explicit
# normal, twist_flag)), used here for the return leg's formed corner.
# Kept as its own optional import for the same reason as plate_layout/
# Designable.Proxies above - this is unconfirmed on this install.
try:
    from Layout3D import Layout3D
except ImportError:                                   # pragma: no cover
    Layout3D = None

FACE_NS = "NS Face"
FACE_FS = "FS Face"
FACE_TOP = "Top Face"
FACE_BOTTOM = "Bottom Face"
# "NS Face"/"FS Face" is the RectPlate convention (flat bar rails use it
# below unchanged). RolledSection shapes with a distinct web sub-feature
# (angle/channel) use a compound name instead - confirmed via Beam_Clips.py
# and Kicker Angle.py (BV Detailing macros), which punch angle/channel webs
# with exactly this string, never "NS Face"/"FS Face"/"Web Face".
FACE_WEB_NS = "Web NS"
FACE_WEB_FS = "Web FS"
# Master switch for the native-toe rewrite. Set False to fall back to the
# old manual-roll behaviour (kept intact below) if the native path misbehaves.
USE_NATIVE_TOE = True


class BuildLog(object):
    """
    Collects everything that happens during a build.

    Nothing is truncated. Call write_file() to dump the whole log next to
    the plugin so a full run can be reviewed in one pass instead of
    reading a capped alert box.
    """

    LOG_NAME = "JBSimpleLadder_last_build.log"

    def __init__(self):
        self.lines = []
        self.warnings = []
        self.path = None

    def warn(self, msg):
        text = "WARNING: %s" % msg
        self.lines.append(text)
        self.warnings.append(str(msg))

    def info(self, msg):
        self.lines.append(str(msg))

    def section(self, title):
        self.lines.append("")
        self.lines.append("--- %s " % title + "-" * max(0, 60 - len(title)))

    def __str__(self):
        return "\n".join(self.lines)

    # -----------------------------------------------------------------
    def summary(self):
        """Distinct warnings with counts, so 16 identical lines read as 1."""
        seen = []
        counts = {}
        for w in self.warnings:
            if w not in counts:
                counts[w] = 0
                seen.append(w)
            counts[w] += 1
        out = []
        for w in seen:
            n = counts[w]
            out.append("%s%s" % (w, ("  (x%d)" % n) if n > 1 else ""))
        return out

    def write_file(self, folder=None):
        """Write the full log to disk. Returns the path, or None."""
        import datetime
        if folder is None:
            folder = os.path.dirname(os.path.abspath(__file__))
        candidates = [folder, os.path.expanduser("~"),
                      os.environ.get("TEMP", "")]
        for base in candidates:
            if not base:
                continue
            try:
                path = os.path.join(base, self.LOG_NAME)
                with open(path, "w") as fh:
                    fh.write("JBSimpleLadder build log\n")
                    fh.write("%s\n" % datetime.datetime.now().isoformat())
                    fh.write("=" * 70 + "\n\n")
                    fh.write(str(self))
                    fh.write("\n\n" + "=" * 70 + "\n")
                    fh.write("%d warning(s), %d distinct\n"
                             % (len(self.warnings), len(self.summary())))
                    for w in self.summary():
                        fh.write("  %s\n" % w)
                self.path = path
                return path
            except Exception:
                continue
        return None


class LadderGeometry(object):
    """
    Builds all ladder material for one member.

    `member_obj` is the JBSimpleLadder instance (pass `self` from
    CreateMaterial). `state` carries the user input.
    """

    # Overall polarity for _miter_pair's WebCutLeftEnd/FlangeCutLeftEnd
    # degree values (see build_flare/_section_rail) - the RELATIVE signs
    # between the 4 bevel values at the two flare joints are geometrically
    # derived and should be correct, but which absolute direction SDS2
    # rotates the cut plane for a positive WebCutLeftEnd is an unverified
    # first guess (no live SDS2 access to confirm). If the bevel opens a
    # gap instead of closing it, flip this to -1.0 - every miter cut in
    # the model shares this one constant, so that's the only line that
    # should need to change.
    _MITER_SIGN = 1.0

    # Single flip point for which way the bent-plate standoff's
    # outstanding leg turns at the support (see _bend_leg_direction) -
    # outboard, away from the ladder centerline (+, intended) or inboard
    # toward it (-, if this needs flipping after a live test).
    _BENT_STANDOFF_SIGN = 1.0

    # Single flip point for which way the bent-plate standoff's RAIL leg
    # runs from the rung centerline (see _bent_intermediate) - toward
    # the support/wall (intended) or toward the rung/climber side.
    # -1.0 (toward -y, matching ptt's "y away from support" comment) was
    # the original value and confirmed WRONG via a live 2026-09-11 field
    # test: the whole standoff (both legs, since the OSL hangs off the
    # rail leg's far end) built on the rung/climber side of the rail
    # instead of bracing back to the support, so this now runs +1.0.
    _BENT_STANDOFF_Y_SIGN = 1.0

    def __init__(self, member_obj, state, log=None):
        self.model = member_obj
        self.state = state
        self.log = log or BuildLog()
        self.mem = None
        self.ox = 0.0
        self.oy = 0.0
        # JB brand colors, same RGB tuples REFERENCE/JBLintel/JBLintel.py
        # uses (its color_main/color_added) - assigned directly to
        # MaterialColor3d/.color as a plain (r,g,b) tuple, confirmed
        # working there. Per the user's exact spec (2026-09-19): the
        # rails themselves are blue, and everything that CONNECTS TO
        # the rails - rungs included, not just hardware/connections -
        # is orange.
        self.color_rail = (0, 128, 192)     # JB Brand Blue
        self.color_rung = (255, 128, 0)     # JB Brand Orange
        self.color_conn = (255, 128, 0)     # JB Brand Orange

    # -----------------------------------------------------------------
    def _safe_grade(self, requested, shape_type):
        try:
            grades = list(Job().steel_grades(shape_type).keys())
        except Exception:
            return requested
        if requested and requested in grades:
            return requested
        return grades[0] if grades else requested

    def _finish_id(self):
        try:
            return Job().surface_finish
        except Exception:
            return 0

    def _axes_across(self):
        """
        Axis triad for a rung: length across the ladder, horizontal.

        x = across the ladder (the rung's length direction)
        y = away from the support
        z = global up

        Returned as Point3D unit vectors, which is what Transform3D wants.
        """
        a = math.radians(self.state.rotation)
        c, sn = math.cos(a), math.sin(a)
        xa = Point3D(c, sn, 0.0)          # across
        ya = Point3D(-sn, c, 0.0)         # out from support
        za = Point3D(0.0, 0.0, 1.0)       # up
        return xa, ya, za

    def _axes_rail(self, side=-1.0):
        """
        Axis triad for a side rail. Always right-handed:
        za is derived as xa x ya (never hand-flipped on its own), so the
        Transform3D built from this triad is always a proper rotation.
        A single-axis sign flip is a reflection (det = -1) and produces
        an inverted/self-intersecting solid in SDS2 - that was the cause
        of channels rendering transparent and Surface picking the wrong
        face.

        Toe-in/toe-out and left/right are handled as a genuine 180-deg
        roll about the "up" axis (xa): negate BOTH ya and za together,
        which keeps the determinant positive.

        NOTE: if `roll` fires here, _section_rail's dy sign must track
        it too (see the matching `roll` check added there), or the
        section will be depth-centered on the wrong side of the
        workpoint.
        """
        a = math.radians(self.state.rotation)
        c, sn = math.cos(a), math.sin(a)

        xa = Point3D(0.0, 0.0, 1.0)          # up - fixed for both rails
        ya = Point3D(-sn, c, 0.0)            # out from support - fixed for both rails
        za = Point3D(xa.y * ya.z - xa.z * ya.y,
                     xa.z * ya.x - xa.x * ya.z,
                     xa.x * ya.y - xa.y * ya.x)   # xa x ya -> guaranteed right-handed

        if self.state.rail_shape == RailShape.SECTION:
            roll = self._section_roll(side)
        else:
            # Flat bar is a plain symmetric rectangle - there's no
            # toe-in/toe-out concept for it, so it never rolls. The old
            # `roll = (side > 0)` here mirrored the right rail for no
            # real reason and was the cause of the right flat-bar rail
            # sitting half its width off from where it should be.
            roll = False

        if roll:
            ya = Point3D(-ya.x, -ya.y, -ya.z)
            za = Point3D(-za.x, -za.y, -za.z)

        # Angle only, right rail only: confirmed by direct visual check -
        # the left rail (roll above) is correct as-is. The right rail
        # does NOT get `roll` above (_section_roll is side-based for
        # angle - left only); instead it gets ONLY this separate 180-deg
        # rotation about za (the long-leg / across-the-ladder axis,
        # since the angle's long leg is built horizontal - see
        # IsLongLegVerticalMaterial "HZ." in _section_rail) to become a
        # true mirror of the left. (An earlier version of this also
        # rolled the right rail like the left, then added this flip on
        # top, then one more roll on request - three flips that reduce
        # to exactly this one, so the roll and one of the two xa-turns
        # were dropped rather than left in as dead rotations.) A 180-deg
        # turn about za negates the other two axes (xa, ya) and leaves
        # za itself fixed - same right-handed, proper-rotation pattern
        # as `roll` above, just about the other axis.
        sec = (self.state.rail_section or "").upper()
        if (self.state.rail_shape == RailShape.SECTION and side > 0
                and sec.startswith(("L", "ML"))):
            xa = Point3D(-xa.x, -xa.y, -xa.z)
            ya = Point3D(-ya.x, -ya.y, -ya.z)

        return xa, ya, za

    def _axes_plate_flat(self):
        """
        Axis triad for a horizontal plate (base plate): length axis
        (must match the real pt1->pt2 direction, same rule as every
        other custom_axes use in this file) runs front-to-back/depth,
        width axis runs across the ladder, thickness axis is vertical.

        Built the same way as _axes_rail/_axes_across - from the
        ladder's own rotated local frame (self.state.rotation), with
        the thickness axis derived as xa x ya so the transform is
        always a proper (non-reflected) rotation, per the same
        right-handedness rule documented on _axes_rail. Unlike
        orient="plate" elsewhere in this file (which uses the raw
        member xform and does NOT account for self.state.rotation),
        this matches self.pt()/self.ptt() exactly, which is what pt1/
        pt2 are built from.
        """
        a = math.radians(self.state.rotation)
        c, sn = math.cos(a), math.sin(a)
        xa = Point3D(-sn, c, 0.0)   # length: front-to-back
        ya = Point3D(c, sn, 0.0)    # width: across the ladder
        za = Point3D(xa.y * ya.z - xa.z * ya.y,
                     xa.z * ya.x - xa.x * ya.z,
                     xa.x * ya.y - xa.y * ya.x)   # thickness, xa x ya
        return xa, ya, za

    def _axes_bc_clip(self, side, mirror=False):
        """
        Axis triad for the bottom-connection clip angle. Calibrated
        ONLY for LLV (long leg vertical, against the rail) + OSL
        Outside (horizontal leg toward the outside of the ladder) -
        the one combination confirmed against a live build. Other
        bc_leg_orientation combinations are UNVERIFIED and may need
        different math - same caveat _section_roll/_axes_rail already
        carry for the rails, which ended up hardcoded to their one
        confirmed-working configuration after exactly this kind of
        empirical correction.

        ax (extrusion, must match the real Point1->Point2 direction)
        runs front-to-back toward the support - unchanged from the
        piece's original geometry. ay/az are "up"/"across" in the
        UNROLLED base frame.

        Point1/Point2 run through the angle's own HEEL (Reference
        PointOffset is (0,0,0) - see _section_rail's docstring on
        where that puts a RolledSection's origin), so a "180 about the
        heel" is a roll about ax itself: negate ay and az together,
        same right-handed pattern _axes_rail's `roll` uses.

        The right side needs that SAME heel roll plus an additional
        180 about the long leg's own centerline (parallel to ay, the
        vertical axis, for LLV) - two 180s about perpendicular axes
        compose into a single 180 about the third, so the right side's
        net triad is a roll about az instead of ax. Same "left rolls
        one axis, right rolls the other" structure _axes_rail already
        uses for the rails.

        mirror=True is OSL Inside: per the user's exact instruction,
        "both angles need to be as generated with the OSL Outside
        option, except mirrored about their respective rails" - i.e.
        OSL Inside is not a separately-calibrated configuration, it's
        a literal mirror of the confirmed OSL-Outside piece about the
        plane containing the rail. A true mirror is a reflection
        (det = -1); the equivalent PROPER rotation is a 180 about the
        "up" axis instead - negate ax and az together, leave ay alone.
        Negating ax means Point1/Point2 must be swapped to match (see
        build_bottom_connection), same rule every custom_axes use in
        this file follows.
        """
        a = math.radians(self.state.rotation)
        c, sn = math.cos(a), math.sin(a)
        ax = Point3D(sn, -c, 0.0)   # extrusion: toward support
        ay = Point3D(0.0, 0.0, 1.0)  # up (unrolled)
        az = Point3D(ax.y * ay.z - ax.z * ay.y,
                     ax.z * ay.x - ax.x * ay.z,
                     ax.x * ay.y - ax.y * ay.x)   # across (unrolled), ax x ay

        if side < 0:
            # Heel roll only.
            A, B, C = ax, Point3D(-ay.x, -ay.y, -ay.z), Point3D(-az.x, -az.y, -az.z)
        else:
            # Heel roll + long-leg roll = net roll about az instead.
            A, B, C = Point3D(-ax.x, -ax.y, -ax.z), Point3D(-ay.x, -ay.y, -ay.z), az

        if mirror:
            A, C = Point3D(-A.x, -A.y, -A.z), Point3D(-C.x, -C.y, -C.z)
        return A, B, C

    def _axes_from_points(self, p1, p2, side):
        """
        Axis triad for a straight segment whose real direction (p1 ->
        p2) is NOT purely vertical - e.g. the flare's diagonal segment
        (build_flare), unlike every other rail piece which runs
        straight up. Keeps the cross-section twist consistent with the
        vertical shaft's own _axes_rail(side) - which already encodes
        every section-specific roll/mirror adjustment (angle's swapped
        Point1/Point2 included) - by using its ya as a twist reference
        and only tilting the long axis (xa) to match the segment's real
        direction, instead of re-deriving the roll/mirror logic
        independently and risking it drifting out of sync.

        p1/p2 must be whatever this piece's Point1/Point2 actually end
        up being (i.e. called AFTER any angle end-swap in _section_rail,
        using those same, possibly-swapped values) - not the pre-swap
        arguments - so the resulting xa always matches the real
        Point1->Point2 direction, the same invariant every other rail
        piece in this file relies on.
        """
        p1v, p2v = Point3D(p1), Point3D(p2)
        dx = p2v.x - p1v.x
        dy = p2v.y - p1v.y
        dz = p2v.z - p1v.z
        length = math.sqrt(dx * dx + dy * dy + dz * dz)
        if length < 1e-9:
            return self._axes_rail(side)
        xa = Point3D(dx / length, dy / length, dz / length)

        _, ya_ref, _ = self._axes_rail(side)
        za = Point3D(xa.y * ya_ref.z - xa.z * ya_ref.y,
                     xa.z * ya_ref.x - xa.x * ya_ref.z,
                     xa.x * ya_ref.y - xa.y * ya_ref.x)
        zlen = math.sqrt(za.x * za.x + za.y * za.y + za.z * za.z)
        if zlen < 1e-9:
            return self._axes_rail(side)
        za = Point3D(za.x / zlen, za.y / zlen, za.z / zlen)
        ya = Point3D(za.y * xa.z - za.z * xa.y,
                     za.z * xa.x - za.x * xa.z,
                     za.x * xa.y - za.y * xa.x)
        return xa, ya, za

    def _is_channel_or_angle_section(self, section):
        """True for channel/angle-like section prefixes that use toe logic."""
        sec = (section or "").upper()
        return sec.startswith(("C", "L")) or sec.startswith(("MC", "ML", "MT"))

    def _is_hss_round(self, section):
        """
        True for round HSS. No dedicated round/rect flag was found on
        Shape, so the call-out string is the only reliable signal: round
        HSS is HSS<dia>x<wall> (one 'X' after the "HSS" prefix), while
        rectangular/square HSS is HSS<long>x<short>x<wall> (two 'X's).
        The old `not sec.endswith("RND")` check assumed a "...RND" suffix
        that this callout format never has, so it misclassified every
        round HSS as rectangular.
        """
        sec = (section or "").upper()
        if not sec.startswith("HSS"):
            return False
        return sec[3:].count("X") == 1

    def _section_roll(self, side):
        """
        True when this side's section rail gets the 180-deg roll about
        the up axis (see _axes_rail). Shared by _axes_rail, _section_rail,
        and build_rungs' hole-face selection, so the roll predicate can
        never drift out of sync between them.

        Side-based and IDENTICAL for channel and angle: both need their
        outstanding leg pointing away from the ladder centerline on
        BOTH rails, which is only achievable if left and right are true
        mirror images of each other (roll differs by side), never
        uniform. Confirmed by pixel-measuring two live top-view
        screenshots: the two rails the user identified as already
        correct (left under OSL NS, right under OSL FS) both have their
        leg pointing outward, and outward-on-both-sides is only
        possible with a side-based mirror - an OSL-uniform roll (tried
        and rejected - see git history) put both legs on the SAME
        absolute side, which is outward for one rail and inward for
        the other.

        Angle (L/ML) does NOT use this roll on the right rail - only on
        the left, same as channel. A live SDS2 attribute diff between a
        correct and an incorrect angle placement (see build log history)
        proved that setting toe_io/flip/osl directly has zero effect -
        they are readouts of the resulting transform, not inputs to it -
        and the fix instead lives entirely in the second, DIFFERENT
        180-deg flip _axes_rail applies to the right angle rail alone
        (about za, the long-leg axis, not this roll's xa/long axis).
        Per direct visual confirmation, this roll PLUS that second flip
        together on the right rail was one 180-deg turn too many about
        this same axis (roll here, cancelled by one more xa-turn on
        request) - which works out to be mathematically identical to
        never rolling the right rail here in the first place and relying
        solely on the second flip. So: left still rolls (confirmed
        correct, unchanged); right does not roll here at all - see
        _axes_rail's second flip for what actually mirrors it.
        """
        s = self.state
        sec = (s.rail_section or "").upper()
        # Toe in/out was removed as a user control for channels - they
        # are always toe-in now (the only configuration that was ever
        # tested/confirmed working).
        if sec.startswith(("C", "MC")):
            return side < 0
        if sec.startswith(("L", "ML")):
            return side < 0
        return False

    def _flat_bar_bend_setback(self):
        """
        Cut & Welded flat bar only (RectPlate has no bevel-cut end prep,
        unlike RolledSection's FlangeCut mechanism used for sections):
        how far to pull each piece's square-cut end back from the
        theoretical bend PI along its OWN axis, so the two pieces just
        touch on the inside (concave) corner and open into a weld-prep
        gap on the outside (convex) corner, instead of the square-cut
        faces interfering with each other past the PI. Applied by
        moving the actual pt1/pt2 endpoint with _pull_back() -
        RectPlate.setback_left/right had no visible effect and is left
        at 0.0 in _flat_bar_rail.

        Derived from plane geometry, not measured: model the joint in
        the 2D bend plane with the bend's total turn angle beta and the
        flat bar's cross-section half-dimension h that lies IN that
        plane (rail_fb_thick/2 - see _rail_xy, which already treats
        thickness as the across-ladder/in-bend-plane dimension for flat
        bar, same as an HSS's flange width). Placing both square-cut
        faces through the shared PI point leaves an overlap on the
        inside edge and a gap on the outside edge; solving for the
        setback L (along each piece's axis) that shrinks the inside
        overlap to a single touching point gives:

            L = h * tan(beta / 2)

        (same half-angle relationship as a picture-frame miter, without
        actually beveling the cut). Both joints in the flare's S-curve
        use the same |beta| = flare_angle, so one setback serves all
        four ends that meet at a joint (shaft-top, flare-bottom,
        flare-top, extension-bottom).
        """
        s = self.state
        h = s.rail_fb_thick / 2.0
        beta = min(max(s.flare_angle, 0.0), 179.0)
        return h * math.tan(math.radians(beta) / 2.0)

    def _pull_back(self, p_end, p_other, dist):
        """
        Move point `p_end` toward `p_other` by `dist` along the line
        between them - i.e. shorten a piece from p_end's end without
        touching p_other. Used instead of RectPlate.setback_left/right,
        which had no visible effect on the built flat bar. Tuple in,
        tuple out (matches .ptt()/.pt1/.pt2, not Point3D).
        """
        if dist <= 0.0:
            return p_end
        ex, ey, ez = p_end
        ox, oy, oz = p_other
        dx, dy, dz = ox - ex, oy - ey, oz - ez
        length = math.sqrt(dx * dx + dy * dy + dz * dz)
        if length < 1e-9:
            return p_end
        t = dist / length
        return (ex + dx * t, ey + dy * t, ez + dz * t)

    def _miter_pair(self, deg):
        """
        (lower_end_bevel, upper_end_bevel) signed degrees for a single
        mitered joint where direction changes by `deg` (signed) going
        from the lower segment into the upper one - e.g. +flare_angle
        at the shaft/flare joint, -flare_angle at the flare/extension
        joint (an S-curve: the flare turns AWAY from vertical then back
        TOWARD it, so the two joints turn in opposite senses even
        though both use the same flare_angle magnitude).

        Standard picture-frame miter math: each face gets half the
        total turn, with the two mating faces cut in OPPOSITE
        rotational senses so they sit flush against each other -
        that's the `+half, -half` split below, independent of
        _MITER_SIGN (which only controls the overall polarity, i.e.
        which physical direction a positive number rotates the cut
        plane in SDS2 - see the class docstring comment above
        _MITER_SIGN).
        """
        half = (deg / 2.0) * self._MITER_SIGN
        return half, -half

    def _section_y_shift(self, side, rt):
        """
        Depth-centering offset for a SECTION rail (not flat bar/HSS/
        pipe - those have their own formulas in build_rails). Tied to
        the SAME roll state _axes_rail actually applied (see
        _section_roll's docstring), plus the confirmed right-angle-only
        climber-side shift, both fixed empirically against live top-view
        screenshots. Pulled out of build_rails so build_flare's diagonal
        and extension segments land at the exact same depth as the
        shaft they're welded to, instead of duplicating (and risking
        drifting from) this formula.
        """
        s = self.state
        mirror = side if self._section_roll(side) else 1.0
        y_shift = mirror * (rt / 2.0)
        if side > 0 and (s.rail_section or "").upper().startswith(
                ("L", "ML")):
            y_shift -= rt
        return y_shift

    def _rail_xy(self, side, half):
        """
        (x, y_shift) for a rail's cross-section reference point at a
        given side and a given half-width, for whatever rail_shape/
        section is configured. `half` is a distance from the ladder
        centerline - inside_width/2 for the shaft, flare_width/2 for
        the flare's wide end (build_flare) - so the SAME material-
        specific outward push (centroid vs edge for HSS/pipe, half
        thickness for flat bar) applies consistently wherever this is
        called from, instead of the flare drifting out of alignment
        with the shaft it's welded to by duplicating this logic with a
        different `half`.
        """
        s = self.state
        if s.rail_shape == RailShape.FLAT_BAR:
            x = side * (half + s.rail_fb_thick / 2.0)
            # The RectPlate default frame applies a constant (not
            # side-dependent) offset of one full width in the +y
            # direction. A side-dependent correction was doubling it on
            # one side instead of cancelling it. Constant negative
            # offset cancels it for both rails equally. If BOTH rails
            # are now shifted by a full width, flip this sign to
            # positive.
            y_shift = -(s.rail_fb_width / -2.0)
            return x, y_shift

        rt = 0.0
        is_hss_rect = False
        is_round_tube = False
        hss_bf = 0.0
        try:
            shp = Shape(s.rail_section)
            rt = shp.Depth
            sec = (s.rail_section or "").upper()
            is_hss_rect = sec.startswith("HSS") and not self._is_hss_round(sec)
            is_round_tube = sec.startswith("PIPE") or self._is_hss_round(sec)
            if is_hss_rect:
                hss_bf = shp.FlangeWidth
        except Exception:
            pass

        x = side * half
        if is_hss_rect:
            # The tube's own reference point sits at its centroid, so
            # x=side*half alone puts the CENTROID on the inside_width
            # boundary rather than the inside face - same problem flat
            # bar's `x` already solves by pushing outward by half its
            # own thickness. Confirmed against a top-view screenshot:
            # needs the same outward push, sized to half the
            # across-ladder dimension.
            x = side * (half + hss_bf / 2.0)
        elif is_round_tube:
            # Pipe/round HSS: same centroid-vs-edge problem as
            # rectangular HSS above, fixed the same way - push outward
            # by half the tube's own across-ladder dimension, which for
            # a round tube is just its diameter (rt = shp.Depth doubles
            # as diameter for round shapes).
            x = side * (half + rt / 2.0)
        # Angle: no x adjustment - same as channel.
        y_shift = self._section_y_shift(side, rt)
        return x, y_shift

    def _rail_bottom_elev(self):
        """
        The rail's own bottom endpoint - NOT necessarily bottom_elev
        (the floor). rail_setback_bottom raises it for a wall-mounted
        ladder whose rails don't reach the floor. A base plate
        (bottom_conn) sits ON the floor/support and the rail rests on
        TOP of it, so it raises the rail's bottom by the plate's own
        thickness on top of that. Used everywhere the rail's physical
        bottom matters (build_rails, the bottom cap, the bolted angle
        clip, and the base plate's own top-of-plate reference) so they
        all move together instead of drifting apart.
        """
        s = self.state
        z = s.bottom_elev + s.rail_setback_bottom
        if s.bottom_conn == BottomConnection.BASE_PLATE:
            z += s.bp_thick
        return z

    def _set_any(self, obj, names, value):
        """
        Try each attribute name in order; keep the first that accepts the
        value. Same dual/multi-try idiom already used throughout this file
        for attribute names that differ between SDS2 API generations or
        are not yet confirmed on this install (toe_io/ToeInOrOut,
        llv/IsLongLegVerticalMaterial, K1/K_1/Kdim1/K). Returns the name
        that worked, or None.
        """
        for name in names:
            if not hasattr(obj, name):
                continue
            try:
                setattr(obj, name, value)
                return name
            except Exception:
                continue
        return None

    def _apply_xform(self, mtrl, origin_pt, orient="rail", side=-1.0,
                     custom_axes=None):
        try:
            xf = self.model.GetXform()
            x, y, z, t = Transform3D.GetXYZT(xf)

            if orient == "rung":
                ax, ay, az = self._axes_across()
                T = Transform3D.Transform3D(ax, ay, az, Point3D(origin_pt))
            elif orient == "plate":
                T = Transform3D.Transform3D(x, -z, y, Point3D(origin_pt))
            elif orient == "rail":
                # custom_axes overrides the normal vertical-shaft triad -
                # used for the flare's diagonal segment (build_flare),
                # whose real Point1->Point2 direction is tilted off
                # vertical rather than straight up.
                ax, ay, az = custom_axes if custom_axes is not None \
                    else self._axes_rail(side)
                T = Transform3D.Transform3D(ax, ay, az, Point3D(origin_pt))
            else:
                T = Transform3D.Transform3D(x, y, z, Point3D(origin_pt))
            mtrl.SetTransform(T)
        except Exception as exc:
            self.log.warn("SetTransform(%s): %s" % (orient, exc))

    # -----------------------------------------------------------------
    # Local -> global.  x across the ladder, y away from support, z up.
    #
    # CLIMBER-DIRECTION CONVENTION - CORRECTED 2026-09-20: every
    # docstring in this file written before this date that equated "+y
    # / away from support" with "toward the climber" had it backwards,
    # per an explicit live report ("We have a fundamental
    # misunderstanding of what away from the climber and towards the
    # climber means"). The climber's own body sits in close against
    # the support/rungs while climbing, not out on the open side - so:
    #   +y (away from support)  = AWAY from the climber
    #   -y (toward support)     = TOWARD the climber
    # This is the reverse of what build_return/_gate_pt/_return_
    # geometry_deltas/_bent_intermediate's own docstrings claimed at
    # the time they were written. Only the one shift actually reported
    # broken since this correction (_build_ret_conn_base_plate's
    # flat-bar climber_shift) has been re-signed against it so far -
    # every OTHER "away/toward climber" shift in this file (the gate/
    # hinge/hasp assembly's _gate_pt, _bent_intermediate's standoff
    # shift, _return_geometry_deltas' HSS/Pipe/channel corrections) was
    # still UNCONFIRMED against any live build even before this
    # correction, so none of them have been blindly re-flipped here -
    # re-derive each one against this corrected convention once it is
    # actually live-tested and reported, rather than guessing across
    # every interconnected piece at once.
    # -----------------------------------------------------------------
    def pt(self, x, y, z):
        a = math.radians(self.state.rotation)
        c, sn = math.cos(a), math.sin(a)
        gx = self.ox + x * c - y * sn
        gy = self.oy + x * sn + y * c
        return Point3D(gx, gy, z)

    def ptt(self, x, y, z):
        """
        Local -> global as a plain (x, y, z) tuple.

        The snake_case materials (FlatBar, RndBar, SqrBar, RectPlate,
        BntPlate) reject a Point3D for .pt1/.pt2 and want a tuple.
        The PascalCase RolledSection.Point1/.Point2 DO want Point3D.
        """
        p = self.pt(x, y, z)
        return (p.x, p.y, p.z)

    # -----------------------------------------------------------------
    def generate(self):
        s = self.state
        self._describe()

        if not HAVE_SDS2:
            self.log.warn("SDS2 unavailable - dry run")
            return False

        self.mem = Member(self.model.GetMemberNumber())
        base = self.model.GetLeftLocation()
        self.ox = base.x
        self.oy = base.y

        rails = self.build_rails()
        self.build_flare(rails)
        self.build_return(rails)
        self.build_rungs(rails)

        if s.cap_ends:
            self.build_caps(rails)
        self.build_bottom_connection(rails)
        self.build_intermediate(rails)
        if s.gate_enabled:
            self.build_gate(rails)
        return True

    def _describe(self):
        s = self.state
        rungs = s.rung_elevations()
        self.log.info("JBSimpleLadder  %s" % s.ladder_type)
        self.log.info("  climb %s  inside %s  %d rungs"
                      % (fmt_len(s.climb_height), fmt_len(s.inside_width),
                         len(rungs)))
        self.log.info("  rail %s"
                      % (s.rail_section if s.rail_shape == RailShape.SECTION
                         else "FB %s x %s" % (fmt_len(s.rail_fb_width),
                                              fmt_len(s.rail_fb_thick))))
        self.log.info("  rung %s %s  embed %s  hole %s  (%s)"
                      % (s.rung_shape, fmt_len(s.rung_size),
                         fmt_len(s.effective_rung_embed),
                         fmt_len(s.hole_diameter),
                         "inside face only" if s.is_closed_shape
                         else "through"))

    # -----------------------------------------------------------------
    # Rails
    # -----------------------------------------------------------------
    def build_rails(self):
        s = self.state
        rails = []

        # Cache the web thickness so rungs penetrate the web for clean hole punching
        if s.rail_shape == RailShape.SECTION:
            try:
                tw = Shape(s.rail_section).WebThickness
                s.set_section_wall(tw)
            except Exception:
                pass

        half = s.inside_width / 2.0

        z_bot = self._rail_bottom_elev()
        if s.has_flare:
            # The shaft (this loop) stops at the bend PI; build_flare()
            # adds the diagonal flare segment and the extension above it
            # as separate pieces.
            z_top = s.top_elev + s.flare_to_bend
        elif s.ladder_type == LadderType.STEP_THROUGH:
            z_top = s.top_elev + s.ext_height
        else:
            # Side step: effective_top_elev already accounts for
            # rungs_above_top (extra rungs at the same spacing above
            # top_elev); hatch_rail_extension then extends the rail
            # stub above THAT rung, not the original top_elev. Reduces
            # to the old top_elev + hatch_rail_extension for roof hatch
            # (and side step with no extra rungs).
            z_top = s.effective_top_elev + s.hatch_rail_extension

        for side in (-1.0, 1.0):
            x, y_shift = self._rail_xy(side, half)

            self.log.info("  rail %s workpoint x=%s, y=%s"
                          % ("left" if side < 0 else "right",
                             fmt_len(x), fmt_len(y_shift)))

            if (s.rail_shape == RailShape.FLAT_BAR and s.has_flare
                    and s.flare_construction
                    == FlareConstruction.BEND_FULL_RAIL):
                # The whole rail (shaft + flare + extension) becomes ONE
                # formed piece, built entirely by build_flare(). Leave a
                # placeholder here so rails[] keeps its left-then-right
                # order intact for punch_rung_holes' zip(rails, (-1, 1));
                # build_flare() replaces this entry by index once its
                # formed piece is created.
                rails.append(None)
                continue

            if s.rail_shape == RailShape.FLAT_BAR:
                p_bot = self.ptt(x, y_shift, z_bot)
                p_top = self.ptt(x, y_shift, z_top)
                if s.has_flare:
                    p_top = self._pull_back(
                        p_top, p_bot, self._flat_bar_bend_setback())
                r = self._flat_bar_rail(p_bot, p_top, side)
            else:
                shaft_top_bevel = 0.0
                if s.has_flare:
                    # This shaft's top end meets the flare's bottom end
                    # (build_flare) - same miter joint, so the same
                    # "lower end" bevel from _miter_pair.
                    shaft_top_bevel, _ = self._miter_pair(s.flare_angle)
                r = self._section_rail(self.ptt(x, y_shift, z_bot),
                                       self.ptt(x, y_shift, z_top), side,
                                       bevel_top=shaft_top_bevel)

            if r is not None:
                rails.append(r)
                if s.round_top:
                    r_str = fmt_len(s.round_top_radius or s.rail_fb_width / 2.0)
                    try:
                        r.SetBillRemarks("ROUND TOP R%s" % r_str)
                    except Exception as exc:
                        self.log.warn("round_top bill remark: %s" % exc)
            else:
                self.log.warn("rail %s was NOT created"
                              % ("left" if side < 0 else "right"))

        self.log.info("  %d of 2 rails created"
                      % sum(1 for r in rails if r is not None))
        return rails

    def build_flare(self, rails):
        """
        Step-through flare: shaft -> diagonal flare segment -> vertical
        extension. Three construction styles (LadderState.
        FlareConstruction):

          CUT_WELDED     - shaft (built in build_rails, stops at the bend
                           PI), flare, and extension are 3 SEPARATE
                           straight pieces per rail, mitered/cut and
                           welded. The only style available for SECTION
                           rails. Geometry ported directly from
                           LadderPreview._elevation_rail_paths /
                           _flare_rise, the existing spec for this shape.
          BEND_FLARE     - flare + extension are ONE formed piece
                           (_bent_plate_layout_piece); the shaft (built
                           in build_rails, same as CUT_WELDED) stays a
                           separate straight piece welded to it at the
                           bend PI.
          BEND_FULL_RAIL - shaft + flare + extension are ALL one formed
                           piece. build_rails() leaves a None placeholder
                           in rails[] for each side instead of building a
                           shaft; this replaces it by index.

        Flat bar rails only for the two bent styles - a SECTION rail
        always uses CUT_WELDED's beveled FlangeCut miter (_miter_pair),
        which has no bent equivalent here.

        SECTION shapes (HSS, channel, angle) get a beveled FlangeCut at
        each joint (_miter_pair). Flat bar has no such bevel-cut end
        prep on RectPlate, so instead each end is pulled back square
        along its own axis by _flat_bar_bend_setback() - same visual
        joint (inside corner touching, outside corner open for the
        weld), just without an actual angled face. Neither applies to
        the bent styles - the layout path runs straight through the true
        corner points, and the bend radius is what keeps the material
        physically formable.
        """
        s = self.state
        if not s.has_flare:
            return

        half = s.inside_width / 2.0
        shaft_top = s.top_elev + s.flare_to_bend
        run = (s.flare_width - s.inside_width) / 2.0
        ang = min(max(s.flare_angle, 1.0), 89.0)
        rise = run / math.tan(math.radians(ang))
        flare_top = shaft_top + rise
        # Extension height is measured from the top of the ladder
        # (top_elev), NOT from the flare's own top - flare_to_bend and
        # flare_angle only shape the diagonal flare piece in between.
        ext_top = s.top_elev + s.ext_height

        is_flat_bar = s.rail_shape == RailShape.FLAT_BAR
        bend_flare = (is_flat_bar
                     and s.flare_construction == FlareConstruction.BEND_FLARE)
        bend_full = (is_flat_bar and s.flare_construction
                    == FlareConstruction.BEND_FULL_RAIL)

        self.log.info("  flare: bend at %s, flare top at %s, ext top at %s"
                      % (fmt_len(shaft_top), fmt_len(flare_top),
                         fmt_len(ext_top)))

        # Two joints: shaft/flare turns by +flare_angle going up, then
        # flare/extension turns by -flare_angle back toward vertical
        # (an S-curve) - see _miter_pair's docstring for why that sign
        # reversal matters here.
        _, flare_bottom_bevel = self._miter_pair(s.flare_angle)
        flare_top_bevel, ext_bottom_bevel = self._miter_pair(-s.flare_angle)
        fb_setback = self._flat_bar_bend_setback() if is_flat_bar else 0.0
        # A section rail's extension gets a THIRD miter at its own top
        # end when a return follows (build_return's own first segment
        # mates here) - flat bar return joints are plain butt cuts
        # instead, hardcoded by shape, so this only matters for the
        # non-flat-bar branch below. Same 90-degree pair build_return
        # uses for its own corners, on the theory that this "hook"
        # shape (up, then away, then down) turns the same rotational
        # way at both of its corners - unconfirmed against a live
        # build.
        ext_top_bevel, _ = self._miter_pair(90.0)

        for side in (-1.0, 1.0):
            idx = 0 if side < 0 else 1
            x_shaft, y_shift = self._rail_xy(side, half)
            x_flare, _ = self._rail_xy(side, s.flare_width / 2.0)

            if bend_full:
                # True center points (y=0), NOT the RectPlate-frame-quirk
                # y_shift _rail_xy returns for FLAT_BAR (see its own
                # docstring: a constant offset that only corrects
                # RectPlate's own placement convention). A layout-based
                # piece centers directly on its own pts path
                # (MaterialOriginPoint="Center") and needs none of that -
                # confirmed via a live field test where leaving the quirk
                # in put a formed flare a full half rail-width away from
                # where the straight rail actually sits.
                z_bot = self._rail_bottom_elev()
                p_bottom = self.ptt(x_shaft, 0.0, z_bot)
                p_bend = self.ptt(x_shaft, 0.0, shaft_top)
                p_flare_top = self.ptt(x_flare, 0.0, flare_top)
                p_ext_top = self.ptt(x_flare, 0.0, ext_top)
                piece = self._bent_plate_layout_piece(
                    [(p_bottom, 0.0),
                     (p_bend, max(s.flare_radius, 0.0)),
                     (p_flare_top, max(s.flare_radius, 0.0)),
                     (p_ext_top, 0.0)],
                    s.rail_fb_width, s.rail_fb_thick,
                    "Ladder Rail (Formed)")
                if piece is not None:
                    rails[idx] = piece
                else:
                    self.log.warn("rail %s formed full-rail bend was NOT "
                                  "created"
                                  % ("left" if side < 0 else "right"))
                continue

            if bend_flare:
                # Same true-center-point fix as bend_full above.
                p_bend = self.ptt(x_shaft, 0.0, shaft_top)
                p_flare_top = self.ptt(x_flare, 0.0, flare_top)
                p_ext_top = self.ptt(x_flare, 0.0, ext_top)
                piece = self._bent_plate_layout_piece(
                    [(p_bend, 0.0),
                     (p_flare_top, max(s.flare_radius, 0.0)),
                     (p_ext_top, 0.0)],
                    s.rail_fb_width, s.rail_fb_thick,
                    "Ladder Rail Flare (Formed)")
                if piece is not None:
                    rails.append(piece)
                else:
                    self.log.warn("rail %s formed flare was NOT created"
                                  % ("left" if side < 0 else "right"))
                continue

            # Cut & Welded (also the only path for a SECTION rail, which
            # has no bent equivalent) - unchanged, uses _rail_xy's own
            # y_shift as every other piece in this style already does.
            p_bend = self.ptt(x_shaft, y_shift, shaft_top)
            p_flare_top = self.ptt(x_flare, y_shift, flare_top)
            p_ext_top = self.ptt(x_flare, y_shift, ext_top)

            if is_flat_bar:
                seg1_p1 = self._pull_back(p_bend, p_flare_top, fb_setback)
                seg1_p2 = self._pull_back(p_flare_top, p_bend, fb_setback)
                seg2_p1 = self._pull_back(p_flare_top, p_ext_top, fb_setback)
                seg1 = self._flat_bar_rail(seg1_p1, seg1_p2, side,
                                           usage="Ladder Rail Flare",
                                           is_main=False, tilted=True)
                seg2 = self._flat_bar_rail(seg2_p1, p_ext_top, side,
                                           usage="Ladder Rail Extension",
                                           is_main=False)
            else:
                seg1 = self._section_rail(p_bend, p_flare_top, side,
                                          usage="Ladder Rail Flare",
                                          is_main=False, tilted=True,
                                          bevel_bottom=flare_bottom_bevel,
                                          bevel_top=flare_top_bevel)
                # The extension's own top end needs the same Z and Y
                # corrections build_return applies to its own near end
                # p_top - without them, the extension (still built at
                # the plain, unshifted ext_top/y_shift) does not
                # actually meet the return corner. This is NOT a
                # flare-geometry change (flare_width/flare_angle/
                # flare_to_bend are untouched) - just keeping this one
                # shared joint point in sync. Y goes through
                # _return_ext_y_shift rather than near_delta directly:
                # the angle needs this joint decoupled per side, see
                # that method.
                ext_z_shift = (self._return_section_z_shift(side)
                              if s.has_return else 0.0)
                ext_y_shift = (self._return_ext_y_shift(side)
                              if s.has_return else 0.0)
                p_ext_top_seg = self.ptt(x_flare, y_shift + ext_y_shift,
                                         ext_top + ext_z_shift)
                seg2 = self._section_rail(p_flare_top, p_ext_top_seg, side,
                                          usage="Ladder Rail Extension",
                                          is_main=False,
                                          bevel_bottom=ext_bottom_bevel,
                                          bevel_top=(ext_top_bevel
                                                    if s.has_return
                                                    else 0.0),
                                          cut_axis_top="web",
                                          return_joint_top=True)

            for seg, label in ((seg1, "flare"), (seg2, "extension")):
                if seg is not None:
                    rails.append(seg)
                else:
                    self.log.warn("rail %s %s segment was NOT created"
                                  % ("left" if side < 0 else "right", label))

    # -----------------------------------------------------------------
    # Return to top level (step-through + flare only, see
    # LadderState.has_return)
    # -----------------------------------------------------------------
    def build_return(self, rails):
        """
        Each rail's extension top turns AWAY from the climber by
        return_width, then straight back down to land return_setback
        above top_elev - the "top level" this feature returns to.

        Corner is always square, hardcoded - LadderState.ReturnCorner
        (a Radiused option) was removed after repeated formed-corner
        attempts (a faceted arc, then a Layout3D + FlatBar.layout piece
        modeled on REFERENCE/BentRodMtrl.py's bent-rod schema) both
        failed a live test. Revisit as a separate feature later.

        ptt()'s own y is "away from support" - and, per the
        2026-09-20 climber-direction correction recorded on pt()/
        ptt()'s own docstring, away from support is AWAY from the
        climber, not toward them as this note used to claim. The
        return leg still turns in +y here (return_width was not
        itself reported broken), so in the corrected convention that
        is a turn AWAY from the climber, not toward - this note is
        left updated for whoever reads it next rather than re-deriving
        the same mistake.

        Joint treatment is hardcoded by rail shape, not a user option:
        FLAT_BAR gets a plain square-cut butt joint between its two
        straight segments - both segments meet at the exact same point,
        no bevel, no pullback. Any other shape always gets a mitered
        weld prep (_miter_pair(90), cut_axis="web" - see _section_rail's
        docstring for why this needs the other cut plane than
        build_flare's own joints) instead, and build_flare adds a
        matching third miter at the extension's own top end so the
        return's first segment mates against a beveled face there too,
        not just at its own internal corner.

        Every straight segment gets _axes_return_seg's explicit
        orientation - flat bar via custom_axes (no swap concept there),
        section rails via _section_rail's own return_tilted=True (which
        computes it internally, AFTER any angle-right Point1/Point2
        swap - see that flag's docstring for why passing a pre-swap
        custom_axes broke angle's right rail specifically).

        Section rails that never roll and never swap Point1/Point2 -
        channel's right side, and both tube shapes (round/rect HSS,
        Pipe), on EITHER side - also need their top corner (p_top/
        p_far, NOT the landing point) shifted down one full section
        Depth (_return_section_z_shift), or the joint to the
        extension's true, unshifted top opens a one-Depth gap that
        reads as the extension itself being too tall. Channel/angle's
        rolled side and angle's swapped (right) side already land
        correctly with no shift. And the extension's own new top bevel
        (build_flare) needs the SAME return-corner sign rule as this
        method's own joints, not the older flare-calibrated one it
        used at first - see return_joint_top's docstring on
        _section_rail.

        return_width itself, and the near/far position of this whole
        assembly, get a further per-shape correction from
        _return_geometry_deltas - see that method's docstring for the
        full, precisely-specified (2026-09-19) breakdown. That is a
        SEPARATE correction from this docstring's own Z-shift story
        above: Z (_return_section_z_shift) is about the joint's
        vertical position, _return_geometry_deltas is about
        return_width actually matching the real horizontal gap between
        the rail and the return leg.

        UNCONFIRMED: fixed per several rounds of live tests across flat
        bar, channel, angle, round/rect HSS and Pipe; still no live
        confirmation of the current state.
        """
        s = self.state
        if not s.has_return:
            return

        self.log.info("  return: width %s, setback %s, landing %s"
                      % (fmt_len(s.return_width), fmt_len(s.return_setback),
                         s.return_conn))

        half_flare = s.flare_width / 2.0
        ext_top = s.top_elev + s.ext_height
        land_z = s.top_elev + s.return_setback
        is_flat_bar = s.rail_shape == RailShape.FLAT_BAR
        seg1_top_bevel, seg2_bottom_bevel = self._miter_pair(90.0)

        for side in (-1.0, 1.0):
            label = "left" if side < 0 else "right"
            x, y_shift = self._rail_xy(side, half_flare)
            # width_delta/near_delta/far_delta - see
            # _return_geometry_deltas for the full per-shape spec.
            # near_delta places p_top (this must stay in sync with
            # build_flare's own p_ext_top, which calls the same
            # method, so the two pieces still meet); width_delta +
            # far_delta together place p_far/p_land.
            width_delta, near_delta, far_delta = \
                self._return_geometry_deltas(side)
            y_top = y_shift + near_delta
            y_far = y_shift + far_delta + s.return_width + width_delta
            # z_shift only moves the top corner (p_top/p_far) - the
            # landing point (p_land) stays at the real land_z regardless
            # of shape, so the down segment simply ends up a bit shorter
            # on an affected side rather than landing somewhere new.
            z_shift = self._return_section_z_shift(side)
            p_top = self.ptt(x, y_top, ext_top + z_shift)
            p_far = self.ptt(x, y_far, ext_top + z_shift)
            p_land = self.ptt(x, y_far, land_z)

            if is_flat_bar:
                # Butt joint, hardcoded: both segments meet at the exact
                # same point (p_far), plain square-cut ends, no bevel.
                #
                # RectPlate's "Center" origin does not split WIDTH about
                # the workpoint line - it extends the full width one
                # way (same quirk _rail_xy/_build_base_plate already
                # document for other pieces). For the vertical shaft
                # that's a front-to-back offset _rail_xy already
                # corrects for, but this horizontal segment's width
                # axis sweeps to VERTICAL instead (_axes_return_seg),
                # so the same quirk shows up as the piece floating a
                # full width above the existing extension's true top -
                # shift its workpoints down by rail_fb_width so its top
                # face lands flush with ext_top instead. Confirmed
                # needed against a live build.
                seg1_p1 = (p_top[0], p_top[1], p_top[2] - s.rail_fb_width)
                seg1_p2 = (p_far[0], p_far[1], p_far[2] - s.rail_fb_width)
                seg1_axes = self._axes_return_seg(seg1_p1, seg1_p2, side)
                seg1 = self._flat_bar_rail(seg1_p1, seg1_p2, side,
                                           usage="Ladder Return Top",
                                           is_main=False,
                                           custom_axes=seg1_axes)
                seg2_axes = self._axes_return_seg(p_far, p_land, side)
                seg2 = self._flat_bar_rail(p_far, p_land, side,
                                           usage="Ladder Return Down",
                                           is_main=False,
                                           custom_axes=seg2_axes)
                for seg, seg_label in ((seg1, "top"), (seg2, "down")):
                    if seg is None:
                        self.log.warn("rail %s return %s segment was NOT "
                                      "created" % (label, seg_label))
                    else:
                        rails.append(seg)
            else:
                # Mitered joint, hardcoded: every non-flat-bar shape
                # welds this corner beveled, same as build_flare already
                # hardcodes for its own section-rail joints - no option
                # to make it a butt joint instead.
                seg1 = self._section_rail(p_top, p_far, side,
                                          usage="Ladder Return Top",
                                          is_main=False,
                                          return_tilted=True,
                                          bevel_bottom=seg2_bottom_bevel,
                                          bevel_top=seg1_top_bevel,
                                          cut_axis_bottom="web",
                                          cut_axis_top="web")
                seg2 = self._section_rail(p_far, p_land, side,
                                          usage="Ladder Return Down",
                                          is_main=False,
                                          return_tilted=True,
                                          bevel_bottom=seg2_bottom_bevel,
                                          cut_axis_bottom="web")
                for seg, seg_label in ((seg1, "top"), (seg2, "down")):
                    if seg is None:
                        self.log.warn("rail %s return %s segment was NOT "
                                      "created" % (label, seg_label))
                    else:
                        rails.append(seg)

            self._build_ret_conn(side, x, y_far, land_z, half_flare)

    def _return_section_z_shift(self, side):
        """
        Empirical Z correction for the return's own corner point
        (p_top/p_far - NOT the landing point, which stays put) on a
        SECTION rail - without it, the joint to the extension's true
        (unshifted) top opens up a one-Depth gap, which reads as the
        extension itself looking a full Depth too tall.

        Needed for exactly the shape/side combinations that _axes_rail
        does NOT already compensate some other way: channel's right
        rail and both tube shapes (round/rect HSS, Pipe) - none of
        which ever roll (_section_roll) or swap Point1/Point2. Channel/
        angle's LEFT rail (rolled - _section_roll flips ya/za there)
        and angle's RIGHT rail (Point1/Point2 swapped instead) both
        already land correctly with NO shift - confirmed live; an
        earlier, broader version of this method that also shifted
        those was wrong. Flat bar has its own, separate fix (build_
        return's explicit rail_fb_width shift on the RectPlate piece).
        """
        s = self.state
        if s.rail_shape != RailShape.SECTION:
            return 0.0
        sec = (s.rail_section or "").upper()
        is_angle = sec.startswith(("L", "ML"))
        if is_angle and side > 0:
            return 0.0
        if self._section_roll(side):
            return 0.0
        try:
            return -Shape(s.rail_section).Depth
        except Exception:
            return 0.0

    def _return_geometry_deltas(self, side):
        """
        (width_delta, near_delta, far_delta) - the return-width cleanup,
        REPLACED WHOLESALE 2026-09-19 per the user's own explicit
        instruction to go back to a center-to-center definition of
        return_width (superseding an earlier "outside width" attempt
        entirely - not layered on top of it). All three are local-Y
        (front-to-back) corrections, additive on top of _rail_xy's own
        y_shift:

          width_delta - added alongside return_width itself when
                        computing the far end. Zero for every shape now
                        except FLAT_BAR (see below) - return_width
                        itself is center-to-center, no shape-specific
                        width correction needed.
          near_delta  - shift on the NEAR end (p_top / build_flare's
                        own extension top p_ext_top - see that
                        method's ext_y_shift, which calls this same
                        method so the two stay joined).
          far_delta   - shift on the FAR end (p_far/p_land - the
                        return leg's own vertical run and landing
                        point).

        Per-shape, from the user's own live-measured corrections:

          FLAT_BAR - confirmed good AS-IS, unchanged from the previous
                     round: width_delta = -2*rail_fb_width, no shift.

          Angle (L/ML) - REVISED 2026-09-22. Was near/far both +half
                     the long leg; the live report was that BOTH sides'
                     horizontal and vertical return pieces still needed
                     another half a rail depth TOWARD the ladder. For
                     an angle the long leg IS its depth, so that lands
                     near/far at exactly 0 (+L/2 - 0.5*L). The flare
                     extension does NOT follow near_delta here - only
                     the RIGHT side's extension top was reported as
                     needing the same move, so that one case is split
                     out into _return_ext_y_shift rather than riding on
                     near_delta the way every other shape does.

          HSS rect/PIPE/round HSS - no width correction (center-to-
                     center). REVISED 2026-09-22, same shape of fix the
                     channel needed, and landing on the same numbers:
                     near_delta 0, far_delta -2.0*Depth, both sides
                     equally. Derived from the live report against the
                     old -Depth/2-on-both-ends shift: the horizontal
                     piece's near (ladder-side) end was 0.5*Depth too
                     long (-0.5 + 0.5 = 0) and its far end needed
                     another 1.5*Depth toward the ladder, which is the
                     same single move as "the vertical return shifts
                     1.5*Depth toward the ladder" - p_far is both of
                     those at once (-0.5 - 1.5 = -2.0). Depth doubles
                     as diameter for a round shape, same convention
                     _rail_xy/_section_y_shift already use here.

          Channel (C/MC) - no width correction. REVISED 2026-09-21,
                     twice, against live side-view isometrics:

                     LEFT - a pure translation (near and far move
                     together, no length change), landed at 0 (no
                     shift at all) in the first revision and not
                     reported broken since.

                     RIGHT, first revision - far end (p_far/p_land, the
                     vertical return piece) moved 1.5*Depth toward the
                     climber; near end (p_top) moved only 1.0*Depth of
                     that, meant to shorten the horizontal segment by
                     the then-reported 0.5*Depth. Confirmed wrong next
                     round: it left the horizontal segment's near end
                     1.5*Depth too long AND put an unwanted tilt into
                     build_flare's own extension piece - near_delta is
                     shared with that method's ext_y_shift (see its
                     call site), so any nonzero near_delta tilts the
                     flare extension to match, which reads as extra
                     length there too (a live-reported 5/16" too tall).

                     RIGHT, current - near_delta all the way back to 0,
                     same as left (killing the flare-extension tilt
                     entirely); far_delta stays at -1.5*Depth-plus-the-
                     original-half, i.e. -2.0*Depth, since the vertical
                     return piece itself was never reported wrong. The
                     horizontal segment's shortening is now a side
                     effect of ONLY its far end moving toward the
                     climber while its near end stays anchored to the
                     flare top - not an explicit length correction.

        UNCONFIRMED against a live build - first pass at this specific,
        revised spec; ready for the next live test.
        """
        s = self.state
        if s.rail_shape == RailShape.FLAT_BAR:
            return -2.0 * s.rail_fb_width, 0.0, 0.0
        if s.rail_shape != RailShape.SECTION:
            return 0.0, 0.0, 0.0

        sec = (s.rail_section or "").upper()

        if sec.startswith(("L", "ML")):
            # +long_leg/2 (the old shift) minus the reported 0.5*Depth
            # toward the ladder = 0, since an angle's long leg IS its
            # depth. The flare extension is NOT tied to near_delta for
            # this shape - see _return_ext_y_shift.
            return 0.0, 0.0, 0.0

        try:
            depth = Shape(s.rail_section).Depth
        except Exception:
            depth = 0.0

        if sec.startswith(("C", "MC")):
            # See this method's docstring (2026-09-21 revision, second
            # pass) for the full derivation. near_delta is 0 on BOTH
            # sides now - nonzero near_delta on the right previously
            # both overshot the horizontal segment's near end and
            # tilted build_flare's extension piece via shared ext_y_
            # shift (that tilt read as the extension being too tall).
            # Only far_delta (the return's own vertical piece) still
            # shifts, right side only.
            near_delta = 0.0
            far_delta = -2.0 * depth if side > 0 else 0.0
            return 0.0, near_delta, far_delta

        # HSS (rect or round) and Pipe - see this method's docstring for
        # the 2026-09-22 derivation. Same landing point the channel
        # reached: the near end anchors to the flare top (0) and only
        # the far end - the vertical return piece and the horizontal
        # piece's far end, the same point - moves toward the ladder.
        # Both sides equally, unlike the channel's per-side split.
        return 0.0, 0.0, -2.0 * depth

    def _return_ext_y_shift(self, side):
        """
        Local-y shift for build_flare's own extension TOP corner
        (p_ext_top_seg), the joint the return's horizontal near end
        meets.

        For every shape but one this is simply _return_geometry_deltas'
        near_delta, so the extension top and the return's near end stay
        welded to each other - which is why build_flare used to read
        that value directly.

        The ANGLE is the exception, added 2026-09-22: the live report
        moved both sides' return pieces toward the ladder by half a
        rail depth but only the RIGHT side's extension top with them,
        leaving the left extension where it was. That is a genuine
        per-side decoupling of this joint, not something near_delta can
        express, so it lives here. Left keeps the angle's original
        +long_leg/2; right lands at 0 alongside its own near_delta.
        """
        s = self.state
        if s.rail_shape == RailShape.SECTION:
            sec = (s.rail_section or "").upper()
            if sec.startswith(("L", "ML")):
                if side > 0:
                    return 0.0
                try:
                    long_leg, _short = parse_angle_legs(s.rail_section)
                except Exception:
                    long_leg = 0.0
                return long_leg / 2.0
        return self._return_geometry_deltas(side)[1]

    def _axes_return_seg(self, p1, p2, side):
        """
        Axis triad for the return leg's straight segments, needed
        because _axes_from_points degenerates here: it derives the
        thickness axis as (real direction) x (_axes_rail's width
        axis), which is exactly zero whenever the real direction runs
        parallel to that width axis - true for the return's own
        horizontal segment, which runs front-to-back (the SAME
        direction _axes_rail's "out from support" width axis already
        points), unlike every other tilted piece in this file (flare,
        gate), which only ever tilts within the across-the-ladder
        plane.

        Fixed instead: take the THICKNESS axis directly from
        _axes_rail (across-the-ladder, fixed regardless of which way
        the length axis points) and derive width as thickness x
        length - always valid, since a length axis confined to the
        front-to-back/vertical plane can never be parallel to the
        across-the-ladder thickness axis. This means the return's
        WIDTH face sweeps from front-to-back (matching the existing
        vertical rail) to vertical (at the horizontal run) through the
        corner, while thickness stays fixed - the mirror image of how
        build_flare's bend keeps WIDTH fixed and sweeps thickness,
        because that bend happens in the other plane. UNCONFIRMED
        against a live build.
        """
        p1v, p2v = Point3D(p1), Point3D(p2)
        dx = p2v.x - p1v.x
        dy = p2v.y - p1v.y
        dz = p2v.z - p1v.z
        length = math.sqrt(dx * dx + dy * dy + dz * dz)
        if length < 1e-9:
            return self._axes_rail(side)
        xa = Point3D(dx / length, dy / length, dz / length)
        _, _, za = self._axes_rail(side)
        ya = Point3D(za.y * xa.z - za.z * xa.y,
                     za.z * xa.x - za.x * xa.z,
                     za.x * xa.y - za.y * xa.x)   # za x xa
        return xa, ya, za

    def _build_ret_conn(self, side, x, y_far, land_z, half_flare):
        """Only Welded Direct (nothing to build) and Base Plate remain -
        the clip-angle and bent-leg landings were removed 2026-09-22, see
        ReturnConnection's own docstring. A member persisted with one of
        those is folded onto WELDED by LadderState.from_dict, so it
        lands in the no-op branch here rather than needing a case."""
        s = self.state
        if s.return_conn == ReturnConnection.BASE_PLATE:
            self._build_ret_conn_base_plate(side, y_far, land_z,
                                            half_flare)

    def _build_ret_conn_base_plate(self, side, y_far, land_z, half_flare):
        """
        Horizontal plate under the return leg's landing point, same
        shape as _build_base_plate but referenced off the return leg's
        own y_far/land_z instead of the rail's bottom - see that
        method's docstring for the RectPlate placement quirks this
        mirrors (workpoint = higher-local-x edge, etc).

        x_center (and the hole x's below) are referenced off
        half_flare, not the passed-in x: x already has HSS/round-tube
        centroid-vs-edge correction baked in (_rail_xy's is_hss_rect/
        is_round_tube branches), so pushing further out from it
        double-counts that correction - _build_base_plate's own
        docstring explicitly avoids that kind of shape-corrected
        reference for exactly this reason. Confirmed needed by a live
        report that the return connections were "not aligned with the
        actual legs".
        """
        s = self.state
        half_len = s.ret_conn_bp_length / 2.0

        # Flat bar only, per a live 2026-09-20 report - and per that
        # same report, this file's whole prior understanding of "away
        # from climber"/"toward climber" was backwards: ptt()'s +y
        # ("away from support") is actually AWAY from the climber (the
        # climber's own body sits close in against the support/rungs,
        # not out on the open side), not toward them as every earlier
        # docstring in this file claimed - see pt()/ptt()'s own
        # docstring for the corrected note. A full-rail-width shift
        # overshot (confirmed against a live isometric, 2026-09-21):
        # the plate needs to come back toward the climber by half the
        # rail depth, landing it at a half-width shift overall.
        climber_shift = 0.0
        if s.rail_shape == RailShape.FLAT_BAR:
            climber_shift = s.rail_fb_width / 2.0

        # Per-section corrections, each sized from its own live build.
        # section_shift is local y (negative = toward the ladder);
        # x_out_shift is local x, away from the ladder centerline, and
        # is applied to x_ref so the plate's holes travel with it.
        section_shift = 0.0
        x_out_shift = 0.0
        if s.rail_shape == RailShape.SECTION:
            sec = (s.rail_section or "").upper()
            try:
                depth = Shape(s.rail_section).Depth
            except Exception:
                depth = 0.0
            if sec.startswith(("C", "MC")):
                # Channel: center the plate ON the rail. The channel's
                # own workpoint sits on a FACE rather than its centroid
                # in y, and WHICH face flips between the two rails
                # (channel's left rail rolls, its right does not - the
                # same per-side asymmetry _section_roll and
                # _return_section_z_shift already handle), so centering
                # costs half the Depth, signed per side. Sized live
                # 2026-09-22 (3" channel, 5" plates): a half-PLATE-
                # LENGTH shift (2.5") left the right plate 1" too far
                # from the rungs and the left 1" too close; both center
                # at half-DEPTH (1.5"). Plate length is deliberately NOT
                # part of this - the plate's own size must not move
                # where it centers.
                section_shift = (depth / 2.0) if side > 0 else (-depth / 2.0)
            elif sec.startswith("PIPE") or self._is_hss_round(sec):
                # Pipe / round HSS. The across-ladder half-diameter
                # push was confirmed; front-to-back then needed half a
                # Depth AWAY from the ladder (+y) on the next round.
                # Depth doubles as diameter for a round shape, same
                # convention _rail_xy uses.
                x_out_shift = side * depth / 2.0
                section_shift = depth / 2.0
            elif sec.startswith("HSS"):
                # Rect/square HSS: a full Depth toward the ladder
                # overshot by 1.5*Depth on the next live round, landing
                # it at half a Depth AWAY (+y) - the same place the
                # round tubes ended up.
                section_shift = depth / 2.0
            elif sec.startswith(("L", "ML")):
                # Angle: a full Depth toward the ladder, then half the
                # PLATE's own length back away from it (+y) - the one
                # shape whose correction is tied to the plate rather
                # than to the rail, per the 2026-09-22 live round that
                # left every other shape's plate correct.
                section_shift = -depth + half_len

        x_ref = side * half_flare + x_out_shift
        if side > 0:
            x_center = x_ref + s.ret_conn_bp_width_out
        else:
            x_center = x_ref + s.ret_conn_bp_width_in

        y_center = (y_far + climber_shift + section_shift
                   + s.ret_conn_bp_center_offset)
        z_ref = land_z - s.ret_conn_bp_thick / 2.0

        try:
            p1 = self.ptt(x_center, y_center - half_len, z_ref)
            p2 = self.ptt(x_center, y_center + half_len, z_ref)
            bp = RectPlate()
            bp.member = self.mem
            bp.pt1 = p1
            bp.pt2 = p2
            bp.width = s.ret_conn_bp_width_in + s.ret_conn_bp_width_out
            bp.thick = s.ret_conn_bp_thick
            bp.origin = "Center"
            bp.ref_pt_offset = (0.0, 0.0, 0.0)
            bp.work_pt_dist = Point3D(p1).Distance(Point3D(p2))
            bp.length = bp.work_pt_dist
            bp.mtrl_type = "Plate"
            bp.mtrl_usage = "Ladder Return PL"
            bp.mtrl_is_main = "No"
            bp.finish = self._finish_id()
            if self.color_conn:
                bp.color = self.color_conn
            bp.add()
            self._apply_xform(bp, p1, orient="rail", side=side,
                              custom_axes=self._axes_plate_flat())
        except Exception as exc:
            self.log.warn("return base plate: %s" % exc)
            return

        x_in_hole = x_ref + side * (s.ret_conn_bp_edge_in
                                    - s.ret_conn_bp_width_in)
        x_out_hole = x_ref + side * (s.ret_conn_bp_width_out
                                     - s.ret_conn_bp_edge_out)
        z_top = z_ref + s.ret_conn_bp_thick / 2.0
        face_candidates = (FACE_NS, FACE_FS, None)
        holes = []
        if s.ret_conn_bp_hole_in_enabled:
            holes.append(("inside", x_in_hole))
        if s.ret_conn_bp_hole_out_enabled:
            holes.append(("outside", x_out_hole))
        for label, hole_x in holes:
            pt = self.ptt(hole_x, y_center, z_top)
            made = False
            for face in face_candidates:
                try:
                    h = Hole()
                    h.mtrl = [bp]
                    h.pt1 = pt
                    if face:
                        h.face = face
                    h.hole_type = "Standard Round"
                    h.bolt_dia = float(s.ret_conn_bp_hole_dia)
                    h.hole_dia = float(s.ret_conn_bp_hole_dia)
                    try:
                        h.bolt_type = Job().bolt_sched()[0]
                    except Exception:
                        pass
                    h.columns = 1
                    h.rows = 1
                    h.locate = "Center"
                    h.valid_cnc = "Yes"
                    h.show_window = "No"
                    h.create()
                    made = True
                    break
                except Exception:
                    continue
            if not made:
                self.log.warn("return base plate %s hole did not punch "
                              "(tried NS Face, FS Face, unset)" % label)

    def _flat_bar_rail(self, p1, p2, side, usage=None, is_main=None,
                       tilted=False, custom_axes=None, width=None,
                       thick=None, description=None, color=None):
        """
        width/thick/color default to the main rail's own rail_fb_width/
        rail_fb_thick/color_rail when not given, so every existing
        caller (the shaft/flare/extension/return rail pieces) is
        unaffected - the overrides exist for smaller flat-plate pieces
        built the same confirmed-correct way but with their own
        dimensions (e.g. the gate's hinge plates, _build_gate_hinge).

        description, if given, is set BEFORE .add() - unlike
        _bent_plate_layout_piece's Proxies-based classes, a legacy
        RectPlate's attributes are confirmed to take a plain
        pre-.add() setattr fine (every other field on this same object
        already relies on that), so there is no need for the
        constructor-kwarg workaround that method needs.
        """
        s = self.state
        try:
            fb = RectPlate()
            fb.member = self.mem
            fb.pt1 = p1
            fb.pt2 = p2
            fb.width = width if width is not None else s.rail_fb_width
            fb.thick = thick if thick is not None else s.rail_fb_thick
            fb.origin = "Center"
            fb.ref_pt_offset = (0.0, 0.0, 0.0)
            fb.work_pt_dist = Point3D(p1).Distance(Point3D(p2))
            fb.length = fb.work_pt_dist
            fb.setback_left = 0.0
            fb.setback_right = 0.0
            fb.mtrl_type = "Plate"
            fb.mtrl_usage = usage or "Ladder Rail"
            fb.mtrl_is_main = "Yes" if (is_main if is_main is not None
                                        else side < 0) else "No"
            fb.grade = self._safe_grade(s.rail_grade, "Plate")
            fb.finish = self._finish_id()
            col = color if color is not None else self.color_rail
            if col:
                fb.color = col
            if description:
                self._set_any(fb, ("ImperialDescription",
                                   "MetricDescription",
                                   "MaterialUserDescription",
                                   "UserDescription", "user_description",
                                   "description"), description)
            fb.add()
            if custom_axes is None and tilted:
                custom_axes = self._axes_from_points(p1, p2, side)
            self._apply_xform(fb, p1, orient="rail", side=side,
                              custom_axes=custom_axes)
            return fb
        except Exception as exc:
            self.log.warn("flat bar rail: %s" % exc)
            return None

    def _bent_plate_layout_piece(self, pts, width, thick, usage,
                                 description=None):
        """
        One formed flat-bar/plate piece through an arbitrary bend path.

        `pts` is [(point_tuple, bend_radius), ...] - a straight run
        between consecutive points, with the given inside radius formed
        at each interior vertex (0.0 at the two end points = square,
        unformed ends). This exact shape - a list of (Point, radius)
        pairs assigned to `pts` - is confirmed three times over in
        REFERENCE/: TSFLadderCM.py's walk-through flare, SDS2's own
        GettingStartedSDS2_API/add_material_examples.py stair-tread
        demo, and BoltedPlates/BoltedPlatesCreate.py's PlateLayout demo.

        CONFIRMED BROKEN in a live 2026-08-28 field test: constructing a
        bare Designable.Proxies object (factory()) and then setattr-ing
        fields afterward does NOT work. SDS2's own Warnings dialog
        showed the resulting MaterialAddProxy's internal _vs vector with
        every field still None - Member included - except `pts`, which
        got through only because it was mutated on an already-live list
        object rather than set as a scalar. Every reference example
        (TSFLadderCM.py, add_material_examples.py, api_introduction.
        markdown) constructs these with ALL fields passed as constructor
        kwargs in one call - never post-construction assignment - so
        that is the only path tried now. If a genuinely separate legacy
        (non-Proxies) class ever turns up under the same module/name and
        rejects kwargs construction (TypeError), it falls back to
        construct-empty-then-setattr, since that pattern already works
        for real legacy classes elsewhere in this file (RectPlate,
        RolledSection).

        What is still not confirmed on this install: which class name
        actually resolves - BntPlateLayout vs PlateLayout, legacy
        plate_layout module vs Designable.Proxies (the field test above
        reached Designable.Proxies for both names). Every available
        candidate is tried in turn; the first that both constructs and
        commits (.Execute()/.Add()) wins, logged so a later pass can
        drop the others. See also probe_bentplate_with_member() at the
        bottom of this file.

        Unlike _flat_bar_rail/_section_rail, no _apply_xform call is
        needed - the layout points are already fully-specified global
        coordinates (built by self.ptt()), not a workpoint + local-axes
        triad. TSFLadderCM.py's reference usage sets no explicit depth
        vector either, so this assumes the layout material derives its
        own width/thickness orientation from the path geometry; if the
        formed rail comes out flipped or on the wrong face, that is the
        first thing to check.

        `description`, if given, overrides the material's own
        description (the purchased rung's pr_description, or its own
        auto-generated size callout - see _purchased_rung). Per the
        CONFIRMED BROKEN note above, a Proxies object's fields must all
        be in the one constructor call - a post-.Add() setattr silently
        does nothing - so this is tried as an EXTRA constructor kwarg
        (candidate names, since the real one isn't confirmed on this
        install) rather than after the fact. If every candidate name
        raises TypeError, the piece is still built (retried with the
        plain kwargs below) so a wrong guess here costs only the
        description, never the geometry.

        ImperialDescription/MetricDescription are tried first - the
        REFERENCE/JBLintel.py top-flange attachment sets exactly these
        two (not MaterialUserDescription et al) for its own DBA/Rebar
        purchased-item descriptions on a plain RndBar, confirmed
        working there; the rest of desc_keys are the older, still-
        unconfirmed-on-this-class guesses, kept as fallback in case a
        Proxies bent-plate layout uses a different name than RndBar
        does.
        """
        s = self.state
        kwargs = {
            "Member": self.mem,
            "MaterialOriginPoint": "Center",
            "Thickness": thick,
            "Width": width,
            "MaterialUsageDescription": usage,
            "mtrl_is_main": "No",
            "MaterialGrade": self._safe_grade(s.rail_grade, "Plate"),
            "SurfaceFinish": self._finish_id(),
            "pts": list(pts),
        }
        if self.color_rail:
            kwargs["MaterialColor3d"] = self.color_rail

        candidates = []
        if DP is not None:
            for cls_name in ("BntPlateLayout", "PlateLayout"):
                cls = getattr(DP, cls_name, None)
                if cls is not None:
                    candidates.append(
                        ("Designable.Proxies.%s" % cls_name, cls))
        if _plate_layout_mod is not None:
            for cls_name in ("BntPlateLayout", "PlateLayout"):
                cls = getattr(_plate_layout_mod, cls_name, None)
                if cls is not None:
                    candidates.append(("plate_layout.%s" % cls_name, cls))

        desc_keys = ("ImperialDescription", "MetricDescription",
                    "MaterialUserDescription", "UserDescription",
                    "user_description", "description")

        last_exc = None
        for label, factory in candidates:
            obj = None
            desc_applied = None
            if description:
                for desc_key in desc_keys:
                    try:
                        obj = factory(**dict(kwargs, **{desc_key: description}))
                        desc_applied = desc_key
                        break
                    except Exception:
                        obj = None
                        continue

            if obj is None:
                try:
                    obj = factory(**kwargs)
                except TypeError as exc:
                    # Unexpected kwarg - not a Proxies-style class. Fall
                    # back to the legacy construct-then-setattr pattern.
                    last_exc = exc
                    try:
                        obj = factory()
                        for name, value in kwargs.items():
                            self._set_any(obj, (name,), value)
                        if description:
                            desc_applied = self._set_any(obj, desc_keys,
                                                         description)
                        if hasattr(obj, "pts") and not obj.pts:
                            for p in pts:
                                obj.pts.append(p)
                    except Exception as exc2:
                        last_exc = exc2
                        continue
                except Exception as exc:
                    last_exc = exc
                    continue

            committed = False
            for commit in ("Execute", "Add", "add"):
                if hasattr(obj, commit):
                    try:
                        getattr(obj, commit)()
                        committed = True
                        break
                    except Exception as exc:
                        last_exc = exc
                        continue
            if committed:
                self.log.info("  formed piece created via %s" % label)
                if description and not desc_applied:
                    self.log.warn("  formed piece description not applied "
                                  "(no working attribute name found)")
                return obj

        self.log.warn("formed flat bar piece: no working bent-plate "
                      "layout API found (last error: %s)" % last_exc)
        return None

    def _section_rail(self, p1, p2, side, usage=None, is_main=None,
                      tilted=False, bevel_bottom=0.0, bevel_top=0.0,
                      custom_axes=None, cut_axis_bottom="flange",
                      cut_axis_top="flange", return_tilted=False,
                      return_joint_bottom=False, return_joint_top=False):
        s = self.state
        try:
            rs = RolledSection()

            # Angle end-for-end mirror (see _section_roll's docstring):
            # the right rail reverses its extrusion direction (Point1/
            # Point2 swapped) to pair with the matching 180-deg roll
            # _axes_rail applies below, reproducing the left rail's
            # mirror image without an actual reflection transform.
            section_upper = (s.rail_section or "").upper()
            swapped = side > 0 and section_upper.startswith(("L", "ML"))
            if swapped:
                p1, p2 = p2, p1

            rs.Member = self.mem
            rs.Point1 = p1
            rs.Point2 = p2
            rs.SectionSize = s.rail_section
            rs.MaterialUsageDescription = usage or "Ladder Rail"
            rs.mtrl_is_main = "Yes" if (is_main if is_main is not None
                                        else side < 0) else "No"
            rs.MaterialType = Shape(s.rail_section).type()
            rs.MaterialGrade = self._safe_grade(s.rail_grade, rs.MaterialType)

            rs.Centered = "No"
            rs.RollType = "None"
            rs.WorkpointSlopeDistance = Point3D(p1).Distance(Point3D(p2))
            rs.OrderLength = rs.WorkpointSlopeDistance
            rs.MaterialSetbackLeftEnd = 0.0
            rs.MaterialSetbackRightEnd = 0.0
            rs.WebCutLeftEnd = 0.0
            rs.WebCutRightEnd = 0.0
            rs.FlangeCutLeftEnd = 0.0
            rs.FlangeCutRightEnd = 0.0
            rs.LeftEndPreparation = "Standard Cut"
            rs.RightEndPreparation = "Standard Cut"

            # Miter cut for a flared/kinked joint (build_flare passes
            # bevel_bottom/bevel_top; build_rails passes bevel_top for
            # the shaft's flare-side end). Channel/angle/HSS (rect and
            # round)/pipe - confirmed real property (FlangeCutLeftEnd/
            # RightEnd, LeftEndPreparation = 'Bevel Cut') per
            # EmbedAngle.py, a real production custom member. Only
            # FlangeCut is needed for THIS orientation - WebCut stays 0
            # (per direct confirmation, setting both was unnecessary/
            # wrong) - build_flare's bend (across the ladder) and the
            # normal vertical shaft both use this, the default.
            #
            # build_return's corners bend the OTHER way (front-to-back/
            # vertical, via _axes_return_seg rather than the standard
            # tilt) and a live test showed FlangeCut mitering the wrong
            # (short) axis there - cut_axis_bottom/cut_axis_top="web"
            # routes that end's signed bevel to WebCutLeftEnd/RightEnd
            # instead, on the hypothesis that the two properties
            # address the section's two orthogonal cut planes and the
            # return's corners need the other one. Independently
            # selectable per end because the extension segment needs
            # BOTH: its bottom joint (to the flare) stays flange, its
            # top joint (to a return, when one follows) needs web.
            # Unconfirmed which one is actually right - ready for the
            # next live test.
            #
            # bevel_bottom/bevel_top are signed degrees for THIS
            # segment's geometric bottom/top end (see build_flare.
            # _miter_pair for the sign derivation). Two independent
            # things flip which physical end/direction that lands on,
            # and per direct visual confirmation BOTH matter:
            #   1. Point1/Point2 order - `swapped` (angle's right rail
            #      only) reverses which end (Left/Right) is
            #      geometrically top vs bottom.
            #   2. The AXES actually used to place this rail - a roll
            #      (_section_roll: channel/angle left) or the angle-
            #      right-only za-flip (`swapped` again, since it's the
            #      same condition) inverts the local frame FlangeCut is
            #      measured against, which flips the SIGN needed.
            # Confirmed empirically (channel both sides correct as-is;
            # HSS/pipe never roll or swap, so left needed a sign flip
            # and right didn't; angle rolls on the left only, so right
            # - the side with neither roll nor swap cancelling it out -
            # needed a sign flip while left didn't). mirror_flip below
            # is exactly "side and axes-flip disagree" (XOR) - it's
            # False whenever the two effects cancel (channel/angle
            # left, both rolled+left), and True whenever exactly one of
            # them applies (HSS/pipe left has neither so "side" alone
            # tips it; angle right has the za-flip alone so that tips
            # it) - matches every case reported so far for build_flare's
            # OWN joints (tilted=True/_axes_from_points).
            #
            # return_tilted's joints (_axes_return_seg) empirically need
            # a DIFFERENT rule - a live test found tube sections (round/
            # rect HSS, Pipe) correct on the right and backwards on the
            # left, and channel correct on the right but needing a flip
            # on the left (angle's left matches channel here too) - i.e.
            # simply "flip on the left, for everything except a tube
            # section" - unrelated to axes_flipped/swapped, which is
            # calibrated for the other (tilted) convention instead.
            #
            # This is a per-END property, not per-piece: the extension
            # segment (build_flare, ordinary tilted=True) has TWO
            # different joints on its own two ends - its bottom (to the
            # flare) is the old, flare-calibrated joint, but its top
            # (the NEW miter added when a return follows) is the SAME
            # kind of joint as the return's own corners and needs the
            # SAME sign rule - confirmed live: applying the return rule
            # there instead of the flare rule fixed it for both channel
            # (left only) and angle (both sides - angle's "both sides
            # disagree with the flare rule" here happens to invert to
            # exactly the return rule). return_joint_bottom/_top let a
            # single call mix the two rules per end; return_tilted (the
            # return's own seg1/seg2 pieces) implies both ends use it.
            EPS = 1e-6
            is_tube_sec = section_upper.startswith(("HSS", "PIPE"))
            if ((self._is_channel_or_angle_section(section_upper)
                    or is_tube_sec)
                    and (abs(bevel_bottom) > EPS or abs(bevel_top) > EPS)):
                def _return_rule():
                    return (side < 0) and not is_tube_sec

                def _flare_rule():
                    axes_flipped = self._section_roll(side) or swapped
                    return (side < 0) != axes_flipped

                mirror_flip_bottom = (_return_rule()
                                      if (return_tilted or return_joint_bottom)
                                      else _flare_rule())
                mirror_flip_top = (_return_rule()
                                   if (return_tilted or return_joint_top)
                                   else _flare_rule())
                bb = -bevel_bottom if mirror_flip_bottom else bevel_bottom
                bt = -bevel_top if mirror_flip_top else bevel_top
                if swapped:
                    left_deg, left_axis = bt, cut_axis_top
                    right_deg, right_axis = bb, cut_axis_bottom
                else:
                    left_deg, left_axis = bb, cut_axis_bottom
                    right_deg, right_axis = bt, cut_axis_top
                if left_axis == "web":
                    rs.WebCutLeftEnd = left_deg
                else:
                    rs.FlangeCutLeftEnd = left_deg
                if right_axis == "web":
                    rs.WebCutRightEnd = right_deg
                else:
                    rs.FlangeCutRightEnd = right_deg
                rs.LeftEndPreparation = ("Bevel Cut" if abs(left_deg) > EPS
                                         else "Standard Cut")
                rs.RightEndPreparation = ("Bevel Cut" if abs(right_deg) > EPS
                                          else "Standard Cut")

            rs.SurfaceFinish = self._finish_id()
            if self.color_rail:
                rs.MaterialColor3d = self.color_rail

            shp = Shape(s.rail_section)
            bf = shp.FlangeWidth
            tw = shp.WebThickness
            tf = shp.FlangeThickness

            dx, dy, dz = 0.0, 0.0, 0.0
            section = s.rail_section.upper()
            dy = 0.0

            is_chan_ang = self._is_channel_or_angle_section(section)
            is_angle_sec = section.startswith(("L", "ML"))

            # Toe in/out (channel) and OSL side (angle) were both
            # removed as user controls - channels are always toe-in,
            # angle rails are always OSL Near Side (the only
            # configurations that were ever tested/confirmed working;
            # angle OSL Far Side is now unreachable). The actual
            # left/right asymmetry for angle lives in _section_roll,
            # not here - see its docstring for the full evidence.
            want_toe_in = is_chan_ang

            if USE_NATIVE_TOE and is_chan_ang:
                # SDS2 owns toe direction. No manual dz; the native flag
                # (set after Add) positions the flanges. toe_io values are
                # the confirmed strings 'In' / 'Out'.
                dz = 0.0
            elif is_chan_ang:
                # Legacy manual-roll path.
                if want_toe_in:
                    dz = -bf
                else:
                    dz = 0.0
            elif section.startswith("HSS") or section.startswith("PIPE"):
                # HSS (rect or round) and PIPE: across-the-ladder
                # positioning is handled entirely in build_rails' x now.
                # A dz = d/2 half-diameter push used to live here for
                # PIPE/round HSS specifically, on the assumption that it
                # reproduced the same outward push rectangular HSS gets
                # from build_rails' x - but a live check showed neither
                # pipe nor round HSS was actually shifting outward, so
                # it wasn't doing the intended job. Dropped in favor of
                # the same build_rails' x mechanism every other tube
                # shape already uses correctly.
                pass

            rs.ReferencePointOffset = (dx, dy, dz)
            rs.Add()
            axes = custom_axes
            if axes is None and tilted:
                axes = self._axes_from_points(p1, p2, side)
            elif axes is None and return_tilted:
                # Computed from the LOCAL (possibly already-swapped) p1/
                # p2, not the caller's original points - angle's right
                # rail swaps them above, and _axes_return_seg's xa must
                # match whichever direction Point1->Point2 actually end
                # up being, same invariant _axes_from_points already
                # follows for the tilted=True path. Passing a custom_axes
                # computed from the pre-swap points instead was the
                # likely cause of the angle-right orientation/Z-span bugs
                # reported live (this rail's xa pointed the opposite way
                # from its real, swapped Point1->Point2).
                axes = self._axes_return_seg(p1, p2, side)
            self._apply_xform(rs, p1, orient="rail", side=side,
                              custom_axes=axes)

            # Native toe: set AFTER Add(). ToeInOrOut (PascalCase) is
            # the real, confirmed property - EmbedAngle.py (a real
            # production custom member) sets self.angle.ToeInOrOut,
            # matching every other PascalCase RolledSection property.
            # toe_io (lowercase) may be a stale/no-op alias: it always
            # read back as a plain bool regardless of which string we
            # assigned, in a live material dump. Try both, preferring
            # ToeInOrOut, so a difference in this SDS2 version doesn't
            # lose whatever made channels work under toe_io.
            if USE_NATIVE_TOE and is_chan_ang:
                toe_val = "In" if want_toe_in else "Out"
                toe_set_via = []
                for attr in ("ToeInOrOut", "toe_io"):
                    if hasattr(rs, attr):
                        try:
                            setattr(rs, attr, toe_val)
                            toe_set_via.append(attr)
                        except Exception as exc:
                            self.log.warn("  %s set failed: %s"
                                          % (attr, exc))
                if toe_set_via:
                    self.log.info("  rail %s toe -> %r (via %s)"
                                  % ("left" if side < 0 else "right",
                                     toe_val, ", ".join(toe_set_via)))
                else:
                    self.log.warn("  no toe attribute found on rail "
                                  "(tried ToeInOrOut, toe_io)")

            # Angle only: IsLongLegVerticalMaterial (PascalCase) is the
            # real property per EmbedAngle.py - llv (lowercase) read
            # back as a plain bool regardless of what string we
            # assigned, same red flag as toe_io above.
            #
            # Long leg orientation is NOT a user control (removed from
            # the dialog/state) - angle rails are always built Long Leg
            # to Rung, which is this "HZ." (horizontal) value.
            if is_angle_sec:
                llv_val = "HZ."
                llv_set_via = []
                for attr in ("IsLongLegVerticalMaterial", "llv"):
                    if hasattr(rs, attr):
                        try:
                            setattr(rs, attr, llv_val)
                            llv_set_via.append(attr)
                        except Exception as exc:
                            self.log.warn("  %s set failed: %s"
                                          % (attr, exc))
                if llv_set_via:
                    self.log.info("  rail %s long-leg -> %r (via %s)"
                                  % ("left" if side < 0 else "right",
                                     llv_val, ", ".join(llv_set_via)))
                else:
                    self.log.warn("  no long-leg attribute found on "
                                  "rail (tried IsLongLegVerticalMaterial, "
                                  "llv)")

            return rs

        except Exception as exc:
            self.log.warn("section rail: %s" % exc)
            return None

    # -----------------------------------------------------------------
    # Rungs + holes
    # -----------------------------------------------------------------
    def build_rungs(self, rails):
        s = self.state
        purchased = s.rung_shape == RungShape.PURCHASED

        if purchased and s.rail_is_round:
            # The dialog pulls Purchased Rung off the menu entirely for a
            # round rail (it welds to a flat inside face a round rail
            # doesn't have), but an existing member saved before that
            # guard existed could still carry it - fall back to round
            # bar rather than build a weld joint that can't work.
            self.log.warn("  purchased rung not supported on a round "
                          "rail - building round bar instead")
            purchased = False

        if purchased:
            # Buyout/purchased rungs are NOT set into the rails - they weld
            # to the INSIDE face of each rail. No setback, no holes.
            half = s.inside_width / 2.0
        else:
            half = s.rung_half_length

        rung_list = s.rung_elevations()
        for i, e in enumerate(rung_list):
            p1 = self.ptt(-half, 0.0, e)
            p2 = self.ptt(half, 0.0, e)
            if i == 0:
                if purchased:
                    self.log.info("  purchased rung: welded to inside of "
                                  "rails, length %s (no holes)"
                                  % fmt_len(2 * half))
                else:
                    self.log.info("  rung length %s  (inside %s, setback "
                                  "%s from outside)"
                                  % (fmt_len(2 * half),
                                     fmt_len(s.inside_width),
                                     fmt_len(s.rung_setback)))

            if purchased:
                rung = self._purchased_rung(half, e)
            elif s.rung_shape == RungShape.SQUARE_BAR:
                self._square_rung(p1, p2)
            else:
                self._round_rung(p1, p2)

            # Only set-in rungs get holes; buyout rungs are welded.
            if not purchased:
                self.punch_rung_holes(rails, e)

    def _common_bar(self, bar, p1, p2, usage):
        bar.member = self.mem
        bar.pt1 = p1
        bar.pt2 = p2
        bar.origin = "Center"
        bar.ref_pt_offset = (0.0, 0.0, 0.0)
        bar.work_pt_dist = Point3D(p1).Distance(Point3D(p2))
        bar.length = bar.work_pt_dist
        bar.setback_left = 0.0
        bar.setback_right = 0.0
        bar.mtrl_usage = usage
        bar.mtrl_is_main = "No"
        bar.finish = self._finish_id()
        if self.color_rung:
            bar.color = self.color_rung

    def _round_rung(self, p1, p2):
        s = self.state
        try:
            rb = RndBar()
            self._common_bar(rb, p1, p2, "Ladder Rung")
            rb.mtrl_type = "Round Bar"
            for attr in ("diameter", "width"):
                try:
                    setattr(rb, attr, s.rung_size)
                except Exception:
                    continue
            rb.add()
            self._apply_xform(rb, p1, orient="rung")
            return rb
        except Exception as exc:
            self.log.warn("round rung: %s" % exc)
            return None

    def _square_rung(self, p1, p2):
        s = self.state
        try:
            sb = SqrBar()
            self._common_bar(sb, p1, p2, "Ladder Rung")
            sb.mtrl_type = "Square Bar"
            for attr, val in (("width", s.rung_size), ("thick", s.rung_size)):
                try:
                    setattr(sb, attr, val)
                except Exception:
                    continue
            sb.add()
            self._apply_xform(sb, p1, orient="rung")
            return sb
        except Exception as exc:
            self.log.warn("square rung: %s" % exc)
            return None

    def _purchased_rung(self, half, elevation):
        """
        Buyout / purchased rung: an inverted-U bent-plate cross-section
        (pr_width overall x pr_height legs x pr_thick material, pr_radius
        inside corners), spanning rail to rail like any other rung.

        Previously modelled as a round-bar placeholder pending
        confirmation that a Designable.Proxies bent-plate LAYOUT actually
        works on this install - now that _bent_plate_layout_piece IS
        confirmed working (the intermediate standoff builds one live),
        this reuses it directly rather than continuing to guess.

        _bent_plate_layout_piece was written for a path that runs ALONG
        a member's length with the bend IN that path (the standoff, the
        flare) - `pts` traces the length and `width` becomes the
        perpendicular (there, vertical) dimension. A rung is the mirror
        image of that: the bend is in its CROSS-SECTION, constant along
        its length. So here `pts` traces the U profile in a single Y-Z
        plane (fixed local X - across, up; no across-the-ladder
        variation) and `width` is handed the rung's LENGTH instead of a
        literal width, so it extrudes along local X - by the same "width
        runs perpendicular to whatever plane pts vary in" rule that
        already sends the standoff's width vertical off an X-Y path.

        The extrusion is CENTERED on the profile's own plane, not run
        forward from it - confirmed via a live 2026-09-12 field test
        where an x_ref of -half (the left rail) put every rung half its
        own length left of the climber, i.e. centered on x_ref instead
        of spanning from it. x_ref = 0 (the ladder centerline, midway
        between the rails) is therefore the correct anchor, not the
        left rail.

        The profile is centered on `elevation` the same way a round/
        square rung is (its pt1/pt2 line, Center origin, is the bar's
        own centerline) - the U's mid-height sits on the rung elevation,
        legs hanging pr_height/2 below and the top pr_height/2 above,
        rather than assuming the elevation is the top (walking surface)
        or bottom (leg tip).

        pr_width is dialog-labelled "Overall width", and the existing
        purchased-rung preview detail already draws it as the outside-
        to-outside span, so the CENTERLINE path used here is inset by
        half the thickness on each side (pr_width - pr_thick), not
        pr_width itself - matching that preview instead of introducing
        a second, disagreeing interpretation.

        Each leg is pulled back from its open bottom tip toward its top
        bend corner by half the material thickness - the exact same
        "the bend consumes thickness/2 of the leg's real length beyond
        the straight-line distance between the points we hand it"
        correction _bent_intermediate already applies to the standoff
        (see _pull_back's docstring there), confirmed needed here too by
        a live 2026-09-12 field test: a requested 1-1/4" leg height
        measured 1-3/8" as-built with 1/4" material - exactly
        height + thickness/2.
        """
        s = self.state
        half_w = max(s.pr_width - s.pr_thick, 0.0625) / 2.0
        h = max(s.pr_height, 0.0625)
        half_thick = s.pr_thick / 2.0
        x_ref = 0.0

        p_top_l = self.ptt(x_ref, -half_w, elevation + h / 2.0)
        p_top_r = self.ptt(x_ref, half_w, elevation + h / 2.0)
        p_leg_l = self.ptt(x_ref, -half_w, elevation - h / 2.0)
        p_leg_r = self.ptt(x_ref, half_w, elevation - h / 2.0)
        p_leg_l = self._pull_back(p_leg_l, p_top_l, half_thick)
        p_leg_r = self._pull_back(p_leg_r, p_top_r, half_thick)

        radius = max(s.pr_radius, 0.0)
        pts = [(p_leg_l, 0.0), (p_top_l, radius),
              (p_top_r, radius), (p_leg_r, 0.0)]

        # Same treatment REFERENCE/JBLintel.py gives its DBA/Rebar top-
        # flange attachments: a purchased/buyout item gets an actual
        # size callout as its description instead of sitting blank,
        # built from the piece's own dimensions via fmt_len (this
        # file's equivalent of JBLintel's DimensionStyled()) - the user
        # override (pr_description) still wins whenever it is set.
        auto_desc = ("%s X %s X %s BENT PL"
                     % (fmt_len(s.pr_width), fmt_len(s.pr_height),
                        fmt_len(s.pr_thick)))
        rung = self._bent_plate_layout_piece(pts, 2.0 * half, s.pr_thick,
                                             "Ladder Rung",
                                             description=s.pr_description
                                             or auto_desc)
        if rung is None:
            self.log.warn("purchased rung was NOT created")
        return rung

    def punch_rung_holes(self, rails, elevation):
        s = self.state
        half = s.inside_width / 2.0

        # A BEND_FULL_RAIL rail is a formed BntPlateLayout/PlateLayout
        # piece, not a RectPlate - FACE_NS/FACE_FS is specifically the
        # RectPlate convention (see the module docstring on FACE_NS),
        # and punching a named face against this different material type
        # was confirmed live to fail. Swept below like _build_base_plate
        # already does for its own (also non-RectPlate-guaranteed) holes.
        is_formed_flat_bar = (s.rail_shape == RailShape.FLAT_BAR
                              and s.has_flare and s.flare_construction
                              == FlareConstruction.BEND_FULL_RAIL)

        tw = 0.0
        is_hss_rect = False
        is_round_tube = False
        hss_bf = hss_d = 0.0
        if s.rail_shape == RailShape.SECTION:
            try:
                shp = Shape(s.rail_section)
                tw = shp.WebThickness
                sec = (s.rail_section or "").upper()
                is_hss_rect = (sec.startswith("HSS")
                               and not self._is_hss_round(sec))
                is_round_tube = (sec.startswith("PIPE")
                                 or self._is_hss_round(sec))
                if is_hss_rect:
                    hss_bf = shp.FlangeWidth
                    hss_d = shp.Depth
            except Exception:
                tw = 0.0

        if not hasattr(self, "_hole_diag_logged"):
            self._hole_diag_logged = set()
        if not hasattr(self, "_hole_obj_dumped"):
            self._hole_obj_dumped = set()

        for rail, side in zip(rails, (-1.0, 1.0)):
            if rail is None:
                continue
            tag = "left" if side < 0 else "right"

            if s.rail_shape == RailShape.FLAT_BAR:
                # _rail_xy (used by build_rails/build_flare to place the
                # actual material, formed or not) always pushes flat bar
                # out by +thick/2 in local X for this rail_shape - that
                # IS the material's real geometric center, not
                # side*half. A first attempt at is_formed_flat_bar
                # assumed side*half was the "true centerline" and swept
                # +-thick/2 from there instead, landing either exactly
                # back on the true center (mid-thickness, no surface) or
                # a full thickness past the real surface - confirmed via
                # a live 2026-08-29 field test's exact failed-punch
                # coordinates matching that error precisely. Both
                # branches now agree with _rail_xy so _punch_formed's
                # +-thick/2 sweep actually straddles the two real faces.
                x_hole = side * (half + s.rail_fb_thick / 2.0)
                y_hole = 0.0
            elif is_hss_rect:
                across = hss_bf
                x_hole = side * (half + across / 2.0)
                y_hole = 0.0
            elif is_round_tube:
                # Pipe/round HSS: the INNER wall surface - the face the
                # rung actually enters - NOT the tube's centroid.
                # Matching build_rails' x (side*(half + diameter/2))
                # put pt1 on the tube's own AXIS, inside the bore and
                # on no polygon at all, and with no named face to
                # disambiguate (see below) SDS2 had nothing to punch
                # against: every rung failed with "There are no holes
                # in selected material to match". Confirmed by the
                # 2026-09-22 diagnostic sweep on a live HSS1.660x0.140
                # build - inner wall OK, centroid FAILED, far wall
                # reachable but only as a second hole.
                x_hole = side * half
                y_hole = 0.0
            else:
                # SDS2's own channel point map (tech support pages
                # pt_c_b_i/pt_c_b_o) puts a RolledSection's origin
                # (ReferencePointOffset (0,0,0)) at the TOP CORNER OF
                # THE HEEL: local Y=0 is that corner (depth runs
                # negative from there), local Z=0 is the heel face
                # (the web spans Z=0 to Z=web-thickness, toward the
                # toe). build_rails' y_shift already centers the depth
                # on the rung's y=0 plane by design ("web lands
                # centered on the rung") - that puts mid-web at global
                # y=0 for both rails regardless of the toe-in roll, so
                # the punch stays on that plane. Across the web, aim
                # for its mid-thickness: half the web thickness in
                # from the rail's own x=side*half workpoint (the
                # heel), toward the ladder centreline.
                x_hole = side * (half - tw / 2.0)
                y_hole = 0.0

            pt = self.ptt(x_hole, y_hole, elevation)
            if s.rail_shape == RailShape.FLAT_BAR:
                face = FACE_FS if side < 0 else FACE_NS
                far_face = FACE_NS if side < 0 else FACE_FS
            elif is_hss_rect:
                # Confirmed via Beam_Clips.py / Kicker Angle.py: an
                # angle/channel's web is punched with "Web NS"/"Web FS",
                # not "NS Face"/"FS Face" (that's the RectPlate name).
                # HSS never rolls (_section_roll is always False for
                # it), so side is still the right split here.
                face = FACE_WEB_FS if side < 0 else FACE_WEB_NS
                far_face = FACE_WEB_NS if side < 0 else FACE_WEB_FS
            elif is_round_tube:
                # Round HSS/pipe has no flat named face: "Web NS"/"Web
                # FS"/"Top Face" all fail with "There are no holes in
                # selected material to match" even at the correct
                # point (2026-09-22 sweep). Leaving face unset punches
                # perpendicular to whichever polygon contains pt1,
                # which is the only mechanism a curved surface has -
                # and that IS confirmed working, at the inner wall
                # surface x_hole above. ("NS Face"/"FS Face" also land
                # there, but unset is the one that matches how a
                # curved wall actually resolves.)
                #
                # far_face (PLUG_WELD's second, opposite-wall hole) has
                # no equivalent: same point with no face just finds the
                # same near wall again. The sweep did reach the far
                # wall from its own x (side*(half + diameter)), so a
                # plug-weld hole there is possible - not wired up yet,
                # so PLUG_WELD stays unimplemented for round tube.
                face = None
                far_face = None
            else:
                # Channel/angle: face tracks the roll state that sets
                # the rail's actual axis orientation (_section_roll),
                # rather than raw side, so this can never drift out of
                # sync with the rail's real orientation if that
                # predicate ever changes. _section_roll is side-based
                # for both channel and angle (see its docstring), so in
                # practice this currently resolves the same as a plain
                # side<0 split - but going through _section_roll keeps
                # that guarantee automatic instead of assumed.
                rolled = self._section_roll(side)
                face = FACE_WEB_FS if rolled else FACE_WEB_NS
                far_face = FACE_WEB_NS if rolled else FACE_WEB_FS

            # One-time Hole() attribute probe for closed shapes (HSS/
            # Pipe) - dumped regardless of whether the punch below
            # lands, since attributes are visible before .create() is
            # even called.
            dump_tag = None
            if s.is_closed_shape and side not in self._hole_obj_dumped:
                self._hole_obj_dumped.add(side)
                dump_tag = tag

            hole_type = s.rung_hole_shape
            if s.is_closed_shape:
                # Confirmed via the Hole() attribute probe: both_sides
                # ('Yes'/'No') is the through-vs-blind switch. Plug weld
                # is a genuinely separate second hole on the far wall,
                # per the physical description - a small hole where the
                # rung actually passes through, plus a larger hole on
                # the wall it doesn't reach for weld access - not a
                # single-call feature.
                mode = s.hss_punch_mode
                if mode == HSSPunchMode.INNER_ONLY:
                    ok = self._punch(rail, pt, face, s.hole_diameter,
                                     dump_tag=dump_tag, both_sides="No",
                                     hole_type=hole_type)
                elif mode == HSSPunchMode.PLUG_WELD:
                    ok = self._punch(rail, pt, face, s.hole_diameter,
                                     dump_tag=dump_tag, both_sides="No",
                                     hole_type=hole_type)
                    self._punch(rail, pt, far_face, s.hss_outer_hole_dia,
                               both_sides="No", hole_type=hole_type)
                else:
                    ok = self._punch(rail, pt, face, s.hole_diameter,
                                     dump_tag=dump_tag, both_sides="Yes",
                                     hole_type=hole_type)
            elif is_formed_flat_bar:
                ok = self._punch_formed(rail, x_hole, y_hole, elevation,
                                        s.rail_fb_thick, s.rung_size,
                                        s.hole_diameter, hole_type=hole_type)
            else:
                ok = self._punch(rail, pt, face, s.hole_diameter,
                                 dump_tag=dump_tag, hole_type=hole_type)

            # Diagnostics only run after a real failure, and only once
            # per side (first rung) - the sweep below calls the real
            # Hole().create() for each candidate, so any candidate that
            # happens to land creates an actual hole. Keeping it gated
            # to "already failed, first rung only" limits that to a
            # handful of exploratory holes on one rung instead of all
            # of them, and since CreateMaterial fully rebuilds the
            # member's material every reprocess, they don't persist
            # past the next build.
            if (not ok and s.rail_shape == RailShape.SECTION
                    and side not in self._hole_diag_logged):
                self._hole_diag_logged.add(side)
                self._dump_rail_attrs(rail, tag)
                self._diag_punch_sweep(rail, tag, side, half, tw,
                                       elevation, s.hole_diameter)

    def _diag_punch_sweep(self, rail, tag, side, half, tw, elevation,
                          dia):
        """
        Quiet, log-only sweep of alternate hole points/faces, run once
        per rail alongside the real punch attempt.

        Two candidate sets, because the two failure modes are nothing
        alike:

        ROUND TUBE (pipe / round HSS) - the open question is WHERE on
        the tube pt1 has to sit, not which face name to use: a curved
        wall has no flat named face, so face is left unset and SDS2
        punches perpendicular to whichever polygon contains pt1 (see
        punch_rung_holes' own round-tube branch). The real punch
        currently aims at side*(half + dia/2), which is the tube's own
        CENTROID - i.e. its axis, inside the bore, on no polygon at
        all - so this walks the point across the tube (inner wall,
        mid-wall, centroid, far wall) with no face, and retries the
        most likely one with each named face for completeness.

        CHANNEL / ANGLE - the "Web NS"/"Web FS" hypothesis (from
        Beam_Clips.py / Kicker Angle.py) at a few point variants,
        including the pattern those scripts actually use: the SAME
        face string on both physical sides, with left/right controlled
        purely by the sign of the point instead of by swapping the
        face name.
        """
        s = self.state
        sec = (s.rail_section or "").upper()
        is_round_tube = sec.startswith("PIPE") or self._is_hss_round(sec)

        if is_round_tube:
            try:
                tube_d = Shape(s.rail_section).Depth
            except Exception:
                tube_d = 0.0
            wall = tw if tw > 0 else 0.25
            inner = side * half
            candidates = [
                ("round: INNER wall surface, no face",
                 inner, 0.0, None),
                ("round: inner wall + half wall, no face",
                 side * (half + wall / 2.0), 0.0, None),
                ("round: inner wall + full wall, no face",
                 side * (half + wall), 0.0, None),
                ("round: CENTROID/axis (what we punch now), no face",
                 side * (half + tube_d / 2.0), 0.0, None),
                ("round: FAR wall surface, no face",
                 side * (half + tube_d), 0.0, None),
                ("round: inner wall surface, NS Face",
                 inner, 0.0, FACE_NS),
                ("round: inner wall surface, FS Face",
                 inner, 0.0, FACE_FS),
                ("round: inner wall surface, Web NS",
                 inner, 0.0, FACE_WEB_NS),
                ("round: inner wall surface, Web FS",
                 inner, 0.0, FACE_WEB_FS),
                ("round: inner wall surface, Top Face",
                 inner, 0.0, FACE_TOP),
            ]
            self.log.info("    diag round tube %s: dia=%s wall=%s "
                          "half=%s (inner wall at x=%s)"
                          % (tag, fmt_len(tube_d), fmt_len(wall),
                             fmt_len(half), fmt_len(inner)))
        else:
            candidates = [
                ("workpoint, no nudge, Web NS",
                 side * half, 0.0, FACE_WEB_NS),
                ("workpoint, no nudge, Web FS",
                 side * half, 0.0, FACE_WEB_FS),
                ("mid-web (toward toe), Web NS",
                 side * (half - tw / 2.0), 0.0, FACE_WEB_NS),
                ("mid-web (toward toe), Web FS",
                 side * (half - tw / 2.0), 0.0, FACE_WEB_FS),
                ("mid-web (away from toe), Web NS",
                 side * (half + tw / 2.0), 0.0, FACE_WEB_NS),
                ("mid-web (away from toe), Web FS",
                 side * (half + tw / 2.0), 0.0, FACE_WEB_FS),
            ]

        for label, x, y, face in candidates:
            pt = self.ptt(x, y, elevation)
            ok, err = self._punch(rail, pt, face, dia, quiet=True,
                                  return_error=True)
            self.log.info("    diag %-42s -> %s%s"
                          % (label, "OK" if ok else "FAILED",
                             "" if ok else (": %s" % err)))

    def _dump_rail_attrs(self, rail, tag):
        """
        One-time full attribute + method-name dump of a live rail
        material, written into the same build log (info level - does
        not feed the popup warning summary). The BV Detailing macros
        (Beam_Clips.py, Kicker Angle.py) call helper methods like
        .translate()/.trans_to_global()/.location that a properties-
        only dump would hide entirely - list method names too so we
        know what's actually callable on this object, not just its
        current attribute values.
        """
        self.log.info("  %s rail attributes (post toe_io):" % tag)
        methods = []
        for n in sorted(dir(rail)):
            if n.startswith("_"):
                continue
            try:
                v = getattr(rail, n)
            except Exception as exc:
                self.log.info("    %-28s <error: %s>" % (n, exc))
                continue
            if callable(v):
                methods.append(n)
                continue
            self.log.info("    %-28s = %r" % (n, v))
        self.log.info("  %s rail methods: %s" % (tag, ", ".join(methods)))

    def _punch(self, target, pt, face_str, hole_dia=None, quiet=False,
              return_error=False, dump_tag=None, both_sides=None,
              hole_type="Standard Round"):
        s = self.state
        dia = float(hole_dia if hole_dia is not None else s.hole_diameter)
        try:
            h = Hole()
            h.mtrl = [target]
            h.pt1 = pt
            if face_str:
                h.face = face_str
            # else: leave face unset. Per SDS2 documentation (v7.300+),
            # face is no longer required - an unset face punches
            # perpendicular to whichever polygon contains pt1, which is
            # the only mechanism that works for a round tube (it has no
            # named flat face like "Web NS"/"Web FS" to punch from - see
            # is_round_tube in punch_rung_holes).
            h.hole_type = hole_type
            h.bolt_dia = float(s.rung_size)
            h.hole_dia = dia
            if both_sides is not None:
                h.both_sides = both_sides
            try:
                h.bolt_type = Job().bolt_sched()[0]
            except Exception:
                pass
            h.columns = 1
            h.rows = 1
            h.locate = "Center"
            h.valid_cnc = "Yes"
            h.show_window = "No"
            if dump_tag:
                self._dump_hole_attrs(h, dump_tag)
            h.create()
            return (True, None) if return_error else True
        except Exception as exc:
            dp_ok, dp_exc = self._punch_dp(target, pt, face_str,
                                           s.rung_size, dia,
                                           hole_type=hole_type)
            if dp_ok:
                return (True, None) if return_error else True
            combined = "legacy: %s | proxy: %s" % (exc, dp_exc)
            if not quiet:
                self.log.warn("hole punch failed on %s: %s"
                              % (face_str or "(unset face, by point)",
                                 combined))
            return (False, combined) if return_error else False

    def _punch_dp(self, target, pt, face_str, bolt_dia, hole_dia,
                 hole_type="Standard Round"):
        """
        Fallback hole punch for a material built via Designable.Proxies
        (_bent_plate_layout_piece's formed BntPlateLayout/PlateLayout
        pieces). Confirmed via a 2026-08-29 field test: the legacy
        hole_add.Hole class's `.mtrl` cannot target a Proxies object -
        every rung/standoff hole failed against a formed piece regardless
        of face (NS/FS/unset all failed identically), which only makes
        sense as an object-type mismatch, not a face-naming problem.
        REFERENCE/DesignableExamples/BoltedPlates/BoltedPlatesCreate.py
        confirms the fix: a Proxies-built material must be punched with
        Proxies.Hole (`Material=`, not `mtrl=`), committed the same way
        the formed piece itself is (Execute/Create).

        Diameter is passed as a constructor kwarg rather than set
        post-construction - the same "every field must be in the one
        constructor call" rule _bent_plate_layout_piece's docstring
        documents for MaterialAddProxy objects (post-construction
        setattr silently never reaching the internal _vs vector).
        Unconfirmed whether Hole proxies share that quirk, but there is
        no cost to avoiding it. Returns (ok, error_or_None) so a still-
        failing punch surfaces the REAL exception text instead of being
        silently swallowed - a second still-not-punching report with no
        error detail cannot be diagnosed further.
        """
        if DP is None or not hasattr(DP, "Hole"):
            return False, "Designable.Proxies.Hole not available"
        try:
            kwargs = {
                "Material": [target],
                "pt1": pt,
                "Columns": 1,
                "Rows": 1,
                "Locate": "Center",
                "BoltDiameter": float(bolt_dia),
                "BoltType": "AUTO",
                "HoleType": hole_type,
                "Diameter": float(hole_dia),
            }
            if face_str:
                kwargs["face"] = face_str
            h = DP.Hole(**kwargs)
            for commit in ("Execute", "Create", "create"):
                if hasattr(h, commit):
                    getattr(h, commit)()
                    return True, None
            return False, "no Execute/Create/create method on Hole proxy"
        except Exception as exc:
            return False, str(exc)

    def _punch_formed(self, target, local_x, local_y, local_z, thick,
                      bolt_dia, hole_dia, hole_type="Standard Round",
                      preferred_axis=None):
        """
        Hole punch for a material built via _bent_plate_layout_piece (a
        Designable.Proxies BntPlateLayout/PlateLayout formed piece) -
        rung holes on a BEND_FULL_RAIL rail, or a bent standoff's bolt
        holes.

        Confirmed via a live 2026-08-29 field test with the real
        "Failed solids operation HoleAddProxy(...)" error text: the
        RectPlate-style centerline point (the SAME one that works fine
        for a RectPlate with an explicit face) fails on every face
        candidate INCLUDING unset, because it does not lie on any real
        surface polygon at all - it is offset in the wrong local axis
        (RectPlate's thickness-offset axis doesn't necessarily match a
        Center-origin layout piece's real one; build_flare's y_shift
        quirk already established these two material types disagree on
        frame conventions). REFERENCE/TSFLadderCM.py's own add_hole()
        helper confirms the correct approach for this material type:
        never set a face string at all - offset pt1 onto the actual
        surface and let SDS2's face auto-detect find whichever polygon
        contains it. Since which local axis (X or Y) really holds the
        thickness here is not assumed, both are tried, each sign, in
        the ladder's local (across, away-from-support, up) frame,
        stopping at the first that lands.

        Z is swept too, last, purely as a fallback. A bent standoff's
        two legs do not share a thickness axis - the rail leg runs along
        -Y so its faces are normal to X, while the outstanding leg turns
        outboard so its faces are normal to Y - but both of those are
        already covered by the X/Y candidates. Z only matters if a leg
        ever ends up running vertically, and it goes last so the
        confirmed rung-hole behavior still resolves on exactly the
        candidate it resolved on before.

        `preferred_axis`, if given, is a (dx, dy) direction (need not be
        unit length) to try FIRST, both signs, before the fixed X/Y/Z
        sweep above. The plain X-then-Y order is tuned for the
        BEND_FULL_RAIL rung case (flat bar, thickness on X); a bent
        standoff's OSL leg generally does NOT run along a pure local
        axis (it turns off the rail leg by ic_bend_angle), so its real
        thickness-normal is whatever is perpendicular to ITS OWN travel
        direction, not necessarily X. Guessing X first for that leg
        wasted two guaranteed-failing solid-ops attempts (and their
        "Failed solids operation HoleAddProxy(...)" console spam) before
        ever reaching the candidate that actually lands - confirmed via
        a live 2026-09-12 report of exactly that repeating error text.
        _punch_standoff_osl_bolt passes the OSL's own (dx, dy) here so
        the correct perpendicular is tried first instead of guessed at.
        """
        half_t = thick / 2.0
        candidates = []
        if preferred_axis is not None:
            pdx, pdy = preferred_axis
            plen = math.sqrt(pdx * pdx + pdy * pdy)
            if plen > 1e-9:
                # Perpendicular to travel, in-plane: rotate 90 degrees.
                nx, ny = -pdy / plen, pdx / plen
                candidates.append((nx * half_t, ny * half_t, 0.0))
                candidates.append((-nx * half_t, -ny * half_t, 0.0))
        candidates.extend([(half_t, 0.0, 0.0), (-half_t, 0.0, 0.0),
                           (0.0, half_t, 0.0), (0.0, -half_t, 0.0),
                           (0.0, 0.0, half_t), (0.0, 0.0, -half_t)])
        for dx, dy, dz in candidates:
            pt = self.ptt(local_x + dx, local_y + dy, local_z + dz)
            ok, _err = self._punch_dp(target, pt, None, bolt_dia, hole_dia,
                                      hole_type=hole_type)
            if ok:
                return True
        return False

    def _punch_sweep(self, target, pt, dia, dump_tag=None):
        """
        Try FACE_NS, FACE_FS, then unset (perpendicular-to-pt1 auto-
        detect) - for a material whose face-naming convention isn't
        the guaranteed RectPlate one, same known-good sweep
        _build_base_plate already uses for its own holes. Each
        candidate punches quietly; one overall warning is logged only
        if every candidate fails, now WITH the last real error text
        attached (a bare "did not punch" with no detail could not be
        diagnosed from a second failing field report).
        """
        last_err = None
        for face in (FACE_NS, FACE_FS, None):
            ok, err = self._punch(target, pt, face, dia, quiet=True,
                                  return_error=True, dump_tag=dump_tag)
            if ok:
                return True
            last_err = err
        self.log.warn("rung hole did not punch (tried NS Face, FS Face, "
                      "unset) - last error: %s" % last_err)
        return False

    def _dump_hole_attrs(self, h, tag):
        """
        One-time attribute + method-name dump of a live Hole() object,
        taken right before .create() (mtrl/pt1/face/hole_type/etc are
        already set at that point, same as a real punch). Written into
        the build log at info level - does not feed the popup warning
        summary. Looking for whatever field controls single-face
        (blind) vs through punching on a closed section, and whatever
        supports a second, differently-sized hole for plug-weld mode.
        """
        self.log.info("  %s Hole() attributes (pre-create):" % tag)
        methods = []
        for n in sorted(dir(h)):
            if n.startswith("_"):
                continue
            try:
                v = getattr(h, n)
            except Exception as exc:
                self.log.info("    %-28s <error: %s>" % (n, exc))
                continue
            if callable(v):
                methods.append(n)
                continue
            self.log.info("    %-28s = %r" % (n, v))
        self.log.info("  %s Hole() methods: %s" % (tag, ", ".join(methods)))

    # -----------------------------------------------------------------
    # Caps / connections / gate
    # -----------------------------------------------------------------
    def build_caps(self, rails):
        s = self.state
        if s.ladder_type == LadderType.STEP_THROUGH:
            z_top = s.top_elev + s.ext_height
        else:
            z_top = s.effective_top_elev + s.hatch_rail_extension
        half = s.inside_width / 2.0
        for side in (-1.0, 1.0):
            for do_it, z in ((s.cap_top, z_top),
                             (s.cap_bottom, self._rail_bottom_elev())):
                if not do_it:
                    continue
                try:
                    w = s.rail_fb_width + 2.0 * s.cap_overhang
                    p1 = self.ptt(side * half - w / 2.0, 0.0, z)
                    p2 = self.ptt(side * half + w / 2.0, 0.0, z)
                    rp = RectPlate()
                    rp.member = self.mem
                    rp.pt1 = p1
                    rp.pt2 = p2
                    rp.width = w
                    rp.thick = s.cap_thick
                    rp.origin = "Center"
                    rp.ref_pt_offset = (0.0, 0.0, 0.0)
                    rp.work_pt_dist = Point3D(p1).Distance(Point3D(p2))
                    rp.length = rp.work_pt_dist
                    rp.mtrl_type = "Plate"
                    rp.mtrl_usage = "Ladder Cap PL"
                    rp.mtrl_is_main = "No"
                    rp.finish = self._finish_id()
                    if self.color_conn:
                        rp.color = self.color_conn
                    rp.add()
                    self._apply_xform(rp, p1, orient="plate")
                except Exception as exc:
                    self.log.warn("cap plate: %s" % exc)

    def _bc_clip_edge_push(self):
        """
        Extra outward push (across the ladder) so a bottom-connection
        clip's own FACE - not its ReferencePointOffset origin - sits
        flush against the rail's face. An angle's origin sits at the
        heel, a true corner, so it needs no push (0.0). An HSS or
        round Pipe/HSS's origin sits at its CENTROID instead - same
        centroid-vs-edge gap _rail_xy already corrects for on the
        rails (is_hss_rect/is_round_tube branches), applied here to
        bc_ang_size instead of rail_section.
        """
        s = self.state
        sec = (s.bc_ang_size or "").upper()
        if sec.startswith(("L", "ML")):
            return 0.0
        try:
            shp = Shape(s.bc_ang_size)
            if sec.startswith("HSS") and not self._is_hss_round(sec):
                return shp.FlangeWidth / 2.0
            if sec.startswith("PIPE") or self._is_hss_round(sec):
                return shp.Depth / 2.0
        except Exception:
            pass
        return 0.0

    def _rail_clip_push(self):
        """
        Base outward push from 'half' (the rung-intersection plane) to
        the RAIL's own face the OSL-Outside clip should rest against.

        Defaults to LadderState.rail_thickness (WebThickness for a
        SECTION rail) - the confirmed-working value for a flat bar
        rail, and left unchanged for channel/angle rails (their own
        "against the web" default placement, per _rail_xy's own "no x
        adjustment" convention for those shapes) - EXCEPT for HSS/
        round Pipe/HSS rails, whose true exterior face is a FULL
        across-ladder dimension away (FlangeWidth/Depth), not just the
        wall thickness rail_thickness gives. Same centroid-vs-edge-
        style gap _rail_xy's own is_hss_rect/is_round_tube branches
        already correct for placing the rail itself. Confirmed needed:
        without this, an HSS/Pipe rail's clip was landing on the
        tube's INTERIOR instead of its true outer face.
        """
        s = self.state
        if s.rail_shape == RailShape.SECTION:
            sec = (s.rail_section or "").upper()
            try:
                shp = Shape(s.rail_section)
                if sec.startswith("HSS") and not self._is_hss_round(sec):
                    return shp.FlangeWidth
                if sec.startswith("PIPE") or self._is_hss_round(sec):
                    return shp.Depth
            except Exception:
                pass
        return s.rail_thickness

    def _channel_k1(self, shp):
        """
        AISC k1 (web-toe-of-fillet distance) for a channel. Shape()'s
        exact attribute name for k1 is NOT confirmed - tried across a
        few plausible candidates, first one found wins. Falls back to
        FlangeThickness as a rough stand-in (ignores the fillet
        radius) if no k1-like attribute exists - a real approximation,
        not a confirmed correct value.
        """
        for attr in ("K1", "K_1", "Kdim1", "K"):
            if hasattr(shp, attr):
                try:
                    v = float(getattr(shp, attr))
                except Exception:
                    continue
                if v > 0:
                    return v
        try:
            return float(shp.FlangeThickness)
        except Exception:
            return 0.0

    def _bc_channel_fit(self):
        """
        (mode, flange_reach) for a channel rail_section + OSL Outside
        clip, per the user's explicit spec:

          'web'  - bc_ang_length fits within the channel's clear flat
                   T (Depth - 2*k1) - nests inside the channel against
                   the web. Unchanged placement (_rail_clip_push's
                   default WebThickness push already puts it there).
          'toe'  - bc_ang_length is as long as, or longer than, the
                   channel's full Depth - too long to nest between the
                   flanges, has to reach past them and rest against
                   their toes instead. flange_reach (FlangeWidth) is
                   the push _rail_clip_push's default should be
                   overridden with in this case.
          'warn' - strictly in between: physically collides with the
                   fillet, not buildable as modelled - flagged in the
                   build log (the dialog also flags it live, in
                   LadderDialog._bc_channel_fit_issue).

        Only meaningful for a channel (C/MC) rail_section - callers
        must check that themselves first.
        """
        s = self.state
        try:
            shp = Shape(s.rail_section)
            depth = shp.Depth
            k1 = self._channel_k1(shp)
            flange_reach = shp.FlangeWidth
        except Exception:
            return "web", 0.0
        t = depth - 2.0 * k1
        L = s.bc_ang_length
        if L <= t + 1e-6:
            return "web", 0.0
        if L >= depth - 1e-6:
            return "toe", flange_reach
        return "warn", 0.0

    def build_bottom_connection(self, rails):
        s = self.state
        if s.bottom_conn == BottomConnection.NONE:
            return
        self.log.info("  bottom connection: %s" % s.bottom_conn)
        if s.bottom_conn == BottomConnection.BASE_PLATE:
            for side in (-1.0, 1.0):
                self._build_base_plate(side)
            return
        half = s.inside_width / 2.0
        # NOT _rail_bottom_elev(): rail_setback_bottom raises the RAIL
        # off the floor for a wall-mounted ladder, but the floor clip
        # always sits at the true floor/support elevation regardless -
        # confirmed needed (the clip was drifting with the rail before).
        z_bot = s.bottom_elev
        sec = (s.bc_ang_size or "").upper()
        is_angle_sec = sec.startswith(("L", "ML"))

        # Channel rail + OSL Outside: the clip either nests against the
        # web (short enough to clear the fillets) or has to reach past
        # the flanges to their toes instead - see _bc_channel_fit's
        # docstring for the full spec. Computed once (symmetric for
        # both sides), not per-side.
        rail_sec = (s.rail_section or "").upper()
        is_channel_rail = (s.rail_shape == RailShape.SECTION
                           and rail_sec.startswith(("C", "MC")))
        chan_fit_mode, chan_flange_reach = (
            self._bc_channel_fit()
            if (is_channel_rail and s.bc_osl_side == BcOSLSide.OUTSIDE)
            else (None, 0.0))
        if chan_fit_mode == "warn":
            self.log.warn(
                "bc clip length %s does not fit within channel k "
                "(fits up to T, or needs the full channel depth+ to "
                "reach the flange toes) - see dialog warning"
                % fmt_len(s.bc_ang_length))

        for side in (-1.0, 1.0):
            try:
                # Tuples, not Point3D - _apply_xform's Point3D(origin_pt)
                # wrap chokes ("Wrong type for attribute: pt1") on an
                # already-a-Point3D origin_pt, same double-wrap bug fixed
                # earlier this session elsewhere; RolledSection.Point1/
                # Point2 accept a plain tuple fine (see _section_rail,
                # which is passed tuples from build_rails' self.ptt()).
                #
                # x pushed outward by the rail's own outer-face offset
                # (_rail_clip_push - flat bar thickness, section
                # web-ish thickness, or the channel toe-of-flange
                # override below) - confirmed needed for the heel-roll
                # below to land the vertical leg flush against the
                # rail instead of overlapping it.
                #
                # OSL Inside is a literal mirror of that OSL-Outside
                # placement about the plane containing the rail (see
                # _axes_bc_clip's mirror=True docstring): the heel
                # moves from the rail's OUTER face (half + push) to
                # its INNER face (half, the same plane the rung first
                # intersects the rail) instead.
                osl_inside = (s.bc_osl_side == BcOSLSide.INSIDE)
                rail_push = (chan_flange_reach if chan_fit_mode == "toe"
                            else self._rail_clip_push())
                # HSS/Pipe CLIP (bc_ang_size, not the rail): same
                # centroid-vs-edge gap _rail_xy already corrects for on
                # the rails themselves - the heel formula above assumes
                # the piece's own origin sits AT a face (true for an
                # angle's heel), but an HSS/Pipe's origin sits at its
                # CENTROID, so its own half-dimension has to be added
                # on top so the piece's actual FACE (not its centroid)
                # lands flush with the rail's face.
                edge_push = self._bc_clip_edge_push()
                x_clip = (side * (half - edge_push) if osl_inside
                         else side * (half + rail_push + edge_push))
                # Whole piece shifted away from the climber (-y) by
                # half its own length - confirmed direction needed
                # against a live build, previous sign was backwards.
                half_ang = s.bc_ang_length / 2.0
                y1 = half_ang
                y2 = -s.bc_ang_length + half_ang
                p1 = self.ptt(x_clip, y1, z_bot)
                p2 = self.ptt(x_clip, y2, z_bot)
                # Point1/Point2 must track every ax-negation the axes
                # triad applies: side>0 negates ax (see _axes_bc_clip's
                # else branch), and mirror=True (OSL Inside) negates it
                # AGAIN on top of that - so whether to swap is the XOR
                # of the two, not just "side>0" alone.
                if (side > 0) != osl_inside:
                    p1, p2 = p2, p1
                ang = RolledSection()
                ang.Member = self.mem
                ang.Point1 = p1
                ang.Point2 = p2
                ang.SectionSize = s.bc_ang_size
                ang.MaterialUsageDescription = "Ladder Base Clip"
                ang.mtrl_is_main = "No"
                ang.MaterialType = (Shape(s.bc_ang_size).type()
                                    if s.bc_ang_size else "Angle")
                ang.MaterialGrade = self._safe_grade("", ang.MaterialType)
                ang.Centered = "No"
                ang.RollType = "None"
                ang.WorkpointSlopeDistance = Point3D(p1).Distance(Point3D(p2))
                ang.OrderLength = ang.WorkpointSlopeDistance
                ang.MaterialSetbackLeftEnd = 0.0
                ang.MaterialSetbackRightEnd = 0.0
                ang.LeftEndPreparation = "Standard Cut"
                ang.RightEndPreparation = "Standard Cut"
                ang.SurfaceFinish = self._finish_id()
                if self.color_conn:
                    ang.MaterialColor3d = self.color_conn
                ang.ReferencePointOffset = (0.0, 0.0, 0.0)
                ang.Add()
                self._apply_xform(ang, p1, orient="rail", side=side,
                                  custom_axes=self._axes_bc_clip(
                                      side, mirror=osl_inside))

                if is_angle_sec:
                    # Same native-attribute mechanism _section_rail uses
                    # for the rails (see its docstring for why these two
                    # PascalCase names are the confirmed-real ones,
                    # tried alongside their lowercase aliases which read
                    # back as no-op bools in a live dump). Always the
                    # OSL-Outside-confirmed value: per the user's exact
                    # instruction, OSL Inside is generated identically
                    # to Outside and then mirrored (see _axes_bc_clip's
                    # mirror docstring) - it does NOT get its own toe
                    # value. "VT." for LLV is NOT independently
                    # confirmed - only "HZ." has ever been verified
                    # working in this file (for the rails, which are
                    # always LLH).
                    toe_val = "Out"
                    for attr in ("ToeInOrOut", "toe_io"):
                        if hasattr(ang, attr):
                            try:
                                setattr(ang, attr, toe_val)
                            except Exception as exc:
                                self.log.warn("  clip angle %s set "
                                              "failed: %s" % (attr, exc))
                    llv_val = ("VT." if s.bc_leg_orientation
                              == BcLegOrientation.LLV else "HZ.")
                    for attr in ("IsLongLegVerticalMaterial", "llv"):
                        if hasattr(ang, attr):
                            try:
                                setattr(ang, attr, llv_val)
                            except Exception as exc:
                                self.log.warn("  clip angle %s set "
                                              "failed: %s" % (attr, exc))

                self._punch_bc_clip(ang, side, x_clip, z_bot, osl_inside)
            except Exception as exc:
                self.log.warn("bottom clip: %s" % exc)

    def _punch_bc_clip(self, ang, side, x_clip, z_bot, osl_inside):
        """
        Bolt holes for the clip angle: bc_bolt_qty holes, bc_bolt_dia
        each. Which leg(s) get holes depends on bottom_conn:
        Bolted-Bolted bolts BOTH legs (rail leg and floor leg);
        Bolted-Welded welds the RAIL leg (no hole there) and bolts
        only the floor leg - confirmed against a live build; the
        previous version had this backwards (always holed the rail
        leg, only conditionally holed the floor leg).

        No user-entered gage: per the user's request, the heel-to-hole
        distance on each leg comes from the AISC standard single-line
        workable gage for THAT leg's own size (LadderState.
        bc_vertical_gage / bc_horizontal_gage - looked up from the
        actual leg dimension parsed out of bc_ang_size,
        bc_leg_orientation-aware), not a guessed leg_dim/2 or a free
        field. When bc_bolt_qty > 1, that same standard gage is also
        reused as the spacing between the multiple holes along the
        piece's own length - there is no dedicated field left for that
        distinct purpose, so this is a first-pass reuse, not confirmed
        against a live build with qty > 1.

        osl_inside mirrors which physical side of x_clip the
        horizontal leg's hole falls on, matching the mirror
        build_bottom_connection/_axes_bc_clip applies to the angle
        itself for OSL Inside. Face string is tried from several
        candidates and keeps whichever one actually punches, same
        approach that resolved the base plate's holes - the rail leg
        (a "Web"-style face, same convention the rails themselves
        punch through) and the floor leg (a horizontal "Flange"-style
        face, untested before now - confirmed needed since the floor
        leg was never actually getting punched under the old
        Web-only candidate list, per direct report) get separate
        candidate lists instead of sharing one.
        """
        s = self.state
        n = max(1, s.bc_bolt_qty)

        v_gage = s.bc_vertical_gage
        h_gage = s.bc_horizontal_gage

        def y_positions(gage):
            return [(i - (n - 1) / 2.0) * gage for i in range(n)]

        z_vert = z_bot + v_gage
        horiz_sign = -side if osl_inside else side
        x_horiz = x_clip + horiz_sign * h_gage

        rail_faces = (FACE_WEB_NS, FACE_WEB_FS, FACE_NS, FACE_FS, None)
        floor_faces = (FACE_TOP, FACE_BOTTOM, FACE_WEB_NS, FACE_WEB_FS,
                       FACE_NS, FACE_FS, None)

        legs = []
        if s.bottom_conn == BottomConnection.BOLT_WELD_ANGLE:
            legs.append(("horizontal (floor)", x_horiz, z_bot, h_gage,
                        floor_faces))
        else:
            legs.append(("vertical (rail)", x_clip, z_vert, v_gage,
                        rail_faces))
            legs.append(("horizontal (floor)", x_horiz, z_bot, h_gage,
                        floor_faces))

        for label, hx, hz, gage, face_candidates in legs:
            for y in y_positions(gage):
                pt = self.ptt(hx, y, hz)
                made = False
                for face in face_candidates:
                    try:
                        h = Hole()
                        h.mtrl = [ang]
                        h.pt1 = pt
                        if face:
                            h.face = face
                        h.hole_type = "Standard Round"
                        h.bolt_dia = float(s.bc_bolt_dia)
                        h.hole_dia = float(s.bc_bolt_dia)
                        try:
                            h.bolt_type = Job().bolt_sched()[0]
                        except Exception:
                            pass
                        h.columns = 1
                        h.rows = 1
                        h.locate = "Center"
                        h.valid_cnc = "Yes"
                        h.show_window = "No"
                        h.create()
                        made = True
                        break
                    except Exception:
                        continue
                if not made:
                    self.log.warn("clip angle %s hole did not punch "
                                  "(tried %d face candidates)"
                                  % (label, len(face_candidates)))

    def _build_base_plate(self, side):
        """
        Horizontal base plate under one rail: length (bp_length) runs
        front-to-back, centered by default (before bp_center_offset)
        on local y=0 - the rung's own position (see build_rungs), and
        the ladder's true geometric front-to-back centerline regardless
        of rail shape. Deliberately NOT referenced off _rail_xy's y -
        that value is a workpoint position with shape-specific quirk
        compensation already baked in (e.g. flat bar's rail_fb_width/2,
        see _rail_xy's FLAT_BAR branch), not the rail's true center, so
        using it here made the plate's center drift by half of
        whatever bp_length was set to instead of staying fixed at the
        rung.

        Width is split into bp_width_in/bp_width_out measured from the
        plane where the rung first intersects the rail (inside_width/2
        - NOT the plate's own centerline, so the plate can sit
        asymmetrically about the rail). Thickness (bp_thick) sits with
        its BOTTOM at the rail's own unplated bottom elevation (see
        _rail_bottom_elev) and extends UP from there - the rail itself
        then rests on TOP of the plate (_rail_bottom_elev adds bp_thick
        once bottom_conn is BASE_PLATE, so the two stay in sync). Two
        holes, one measured in from each edge (bp_edge_in/bp_edge_out),
        centered on the plate's length.

        RectPlate's width does NOT split symmetrically about pt1/pt2
        despite origin="Center" - confirmed empirically (same quirk as
        the flat bar rail, see _rail_xy's FLAT_BAR branch): the full
        width extends toward LOWER local-x (the axis _axes_plate_flat
        calls `ay`, which does NOT mirror between left/right the way
        _axes_rail's toe-in/out roll does) FROM the workpoint - i.e.
        the workpoint always has to be the HIGHER-local-x edge of the
        two boundaries. For the right rail (side>0) that's the outside
        edge; for the left rail (side<0), because x_ref itself is
        negative, the outside edge (further negative) is the LOWER one
        and the inside edge is higher - so the left rail's workpoint
        has to be its inside edge instead. Confirmed empirically: right
        rail was correct with the outside-edge workpoint, left rail was
        not.
        """
        s = self.state
        half = s.inside_width / 2.0
        # Outboard by half the rail's across-ladder dimension, every
        # shape (live 2026-09-22). Folded into x_ref rather than into
        # x_center alone so the plate's two holes below, which are also
        # measured off x_ref, travel with it.
        x_ref = side * (half + self._rail_across() / 2.0)
        if side > 0:
            x_center = x_ref + s.bp_width_out
        else:
            x_center = x_ref + s.bp_width_in
        half_len = s.bp_length / 2.0
        y_center = s.bp_center_offset
        z_ref = self._rail_bottom_elev() - s.bp_thick / 2.0

        try:
            p1 = self.ptt(x_center, y_center - half_len, z_ref)
            p2 = self.ptt(x_center, y_center + half_len, z_ref)
            bp = RectPlate()
            bp.member = self.mem
            bp.pt1 = p1
            bp.pt2 = p2
            bp.width = s.bp_width_in + s.bp_width_out
            bp.thick = s.bp_thick
            bp.origin = "Center"
            bp.ref_pt_offset = (0.0, 0.0, 0.0)
            bp.work_pt_dist = Point3D(p1).Distance(Point3D(p2))
            bp.length = bp.work_pt_dist
            bp.mtrl_type = "Plate"
            bp.mtrl_usage = "Ladder Base PL"
            bp.mtrl_is_main = "No"
            bp.finish = self._finish_id()
            if self.color_conn:
                bp.color = self.color_conn
            bp.add()
            self._apply_xform(bp, p1, orient="rail", side=side,
                              custom_axes=self._axes_plate_flat())
        except Exception as exc:
            self.log.warn("base plate: %s" % exc)
            return

        x_in_hole = x_ref + side * (s.bp_edge_in - s.bp_width_in)
        x_out_hole = x_ref + side * (s.bp_width_out - s.bp_edge_out)
        z_top = z_ref + s.bp_thick / 2.0
        # "Top Face"/"Bottom Face" turned out wrong - punch_rung_holes'
        # FLAT_BAR branch (RectPlate, same class as this plate) confirms
        # the real RectPlate convention is FACE_NS/FACE_FS ("NS Face"/
        # "FS Face"), not Top/Bottom. Which of the two lands on the true
        # top face of THIS plate (built off _axes_plate_flat, a
        # different axis triad than a rail's) isn't confirmed yet, so
        # try both plus unset-face auto-detect and keep whichever
        # actually creates the hole.
        face_candidates = (FACE_NS, FACE_FS, None)
        holes = []
        if s.bp_hole_in_enabled:
            holes.append(("inside", x_in_hole))
        if s.bp_hole_out_enabled:
            holes.append(("outside", x_out_hole))
        for label, hole_x in holes:
            pt = self.ptt(hole_x, y_center, z_top)
            made = False
            for face in face_candidates:
                try:
                    h = Hole()
                    h.mtrl = [bp]
                    h.pt1 = pt
                    if face:
                        h.face = face
                    h.hole_type = "Standard Round"
                    h.bolt_dia = float(s.bp_hole_dia)
                    h.hole_dia = float(s.bp_hole_dia)
                    try:
                        h.bolt_type = Job().bolt_sched()[0]
                    except Exception:
                        pass
                    h.columns = 1
                    h.rows = 1
                    h.locate = "Center"
                    h.valid_cnc = "Yes"
                    h.show_window = "No"
                    h.create()
                    self.log.info("  base plate %s hole: %s worked"
                                  % (label, face or "(unset face)"))
                    made = True
                    break
                except Exception as exc:
                    self.log.info("  base plate %s hole: %s failed: %s"
                                  % (label, face or "(unset face)", exc))
            if not made:
                self.log.warn("base plate %s hole did not punch (tried "
                              "NS Face, FS Face, unset)" % label)

    def build_intermediate(self, rails):
        s = self.state
        elevs = s.intermediate_elevations()
        if not elevs:
            return
        self.log.info("  intermediate: %d x %s" % (len(elevs), s.ic_type))
        # Spelled out in the log so a field test can tell at a glance
        # which branch actually ran - the whole point of this connection
        # misbehaving before was that the log named a type the builder
        # then quietly ignored.
        self.log.info("    shape bent, rail leg welded, OSL %s"
                      % ("bolted" if s.ic_osl_bolted else "welded"))
        half = s.inside_width / 2.0
        # Every remaining IntermediateConnection type builds the same
        # formed bent-plate standoff - only which ends get bolts
        # differs. FLAT_PLATE (a straight two-point BntPlate) was
        # removed 2026-09-19 per explicit user request.
        for e in elevs:
            for side in (-1.0, 1.0):
                self._bent_intermediate(side, half, e)

    def _bent_intermediate(self, side, half, elevation):
        """
        One bent-plate standoff, built the same proven way as the formed
        flare/rail (_bent_plate_layout_piece - BntPlateLayout/
        PlateLayout, pts=[(point, radius), ...]) rather than the
        parametric BntPlate leg/osl/bend_rad/bend_angle/bent fields.
        That parametric path was tried first (its attribute names even
        confirmed via a live material property probe) but still did not
        produce actual bent geometry in a follow-up field test - only
        the layout mechanism has ever been confirmed to actually bend,
        so this uses it instead of continuing to guess at BntPlate's
        remaining preconditions.

        ORIENTATION (corrected after a 2026-09-10 field test that came
        out with the two legs swapped - the rail leg ran vertically and
        the outstanding leg hung straight down; corrected again after a
        2026-09-11 field test that came out with the whole standoff
        built on the rung/climber side of the rail instead of bracing
        back to the support - _BENT_STANDOFF_Y_SIGN flipped the rail
        leg's direction to fix it):

            plan view, left rail, support at the bottom

                  support face  ================#=====
                                                |  <- OSL, turns
                                                |     OUTBOARD (away
                             p_end  <-----------+     from ladder CL),
                                              p_bend  ic_osl long
                                                |
                                                |  <- rail leg, runs
                                                |     rail -> support,
                                       p_rail   +     s.standoff long
                  rung CL       - - - - - - - - - - - -
                                                x = side * half

        Both legs are HORIZONTAL, so the profile lies in the plan
        plane and the formed piece's `width` (ic_plate_width) becomes
        its vertical height - a plate standing on edge, bent in plan.
        The rail leg welds/bolts flat against the rail; the OSL lands
        flat on the support face and is the leg that carries the bolts
        for a Bolted-Welded standoff.

        The rail leg's far (bend) end sits standoff_dist from the rung
        CL plane no matter what the user typed for ic_leg (standoff_dist
        is "face of support -> CL of rung", exactly the span this leg
        has to cover to reach the support - ic_leg is left unused by
        this path for that reason). Its NEAR end is normally the rung
        CL plane itself (local y = 0), EXCEPT for channel/angle - see
        _standoff_rail_geometry.

        x_rail is pushed outward from the ladder centerline past
        `half` (the inside-face-of-rail reference every other piece
        here uses) to the rail's OUTER face, plus half the standoff's
        own thickness (so its "Center"-origin centerline, not its inner
        face, is what lands on that face) - see
        _standoff_rail_geometry for the per-shape reach (confirmed via
        a live 2026-09-12 field test for FLAT_BAR; HSS/round tube and
        channel/angle follow the same outer-face convention _rail_xy
        already uses elsewhere but are NOT yet field-confirmed for this
        piece).

        For channel/angle, that same lookup also returns a y-target: the
        rail leg is supposed to weld flush against the FLANGE closest to
        the climber, not the web at the rung's own CL plane (y=0), so
        its near end (p_rail) moves out to y=+rt/2 there instead of 0,
        lengthening the leg by that much on top of the standoff-to-
        rung-CL span. UNCONFIRMED pending a live test on an actual
        channel/angle rail.

        Leg 2 turns off the rail leg by (180 - ic_bend_angle) degrees
        within the plan plane - see _bend_leg_direction - so the
        default 90 gives a pure outboard run and 180 means no bend at
        all (the piece runs straight on into the support).

        Both far ends are then pulled back toward the bend corner by
        half the material thickness (_pull_back - same mechanism
        build_flare's cut & welded joints already use for a related
        "the joint consumes some of the requested length" correction).
        Confirmed needed via a live 2026-08-29 test: a requested 3"
        leg measured 3-3/16" as-built with 3/8" material - the bend
        itself is adding exactly thickness/2 to each leg's real length
        beyond the straight-line distance between the points we hand
        it, so pulling back by that same amount cancels it out.
        """
        s = self.state
        try:
            x_push, y_rail = self._standoff_rail_geometry()
            standoff_dist = max(s.standoff, 0.0625)
            osl = max(s.ic_osl, s.ic_bent_leg2_length, 0.0625)
            x_rail = side * (half + x_push + s.ic_plate_thick / 2.0)
            y_bend = self._BENT_STANDOFF_Y_SIGN * standoff_dist
            dx, dy = self._bend_leg_direction(side)

            # _BENT_STANDOFF_Y_SIGN points toward the SUPPORT (confirmed
            # via the 2026-09-11 field test that set it); the climber is
            # the opposite direction along this same axis.
            #
            # Whole standoff shifted toward the climber by half its own
            # material thickness, per the user's explicit request
            # (2026-09-19) - added directly onto y_bend (which p_bend,
            # p_end, AND _punch_standoff_osl_bolt below all derive from)
            # and onto p_rail's own y so the bolt hole and the rest of
            # the piece move together. UNCONFIRMED against a live build.
            climber_sign = -self._BENT_STANDOFF_Y_SIGN
            climber_shift = climber_sign * (s.ic_plate_thick / 2.0)
            y_bend += climber_shift
            p_rail = self.ptt(x_rail, climber_sign * y_rail + climber_shift,
                              elevation)
            p_bend = self.ptt(x_rail, y_bend, elevation)
            p_end = self.ptt(x_rail + dx * osl, y_bend + dy * osl, elevation)

            half_thick = s.ic_plate_thick / 2.0
            p_rail = self._pull_back(p_rail, p_bend, half_thick)
            p_end = self._pull_back(p_end, p_bend, half_thick)

            standoff = self._bent_plate_layout_piece(
                [(p_rail, 0.0),
                 (p_bend, max(s.ic_bend_radius, 0.0)),
                 (p_end, 0.0)],
                s.ic_plate_width, s.ic_plate_thick, "Ladder Standoff")
            if standoff is None:
                self.log.warn("standoff was NOT created")
                return
            if s.ic_osl_bolted:
                self._punch_standoff_osl_bolt(standoff, x_rail, y_bend,
                                              dx, dy, elevation)
        except Exception as exc:
            self.log.warn("bent standoff: %s" % exc)

    def _bend_leg_direction(self, side):
        """
        (dx, dy) unit direction the outstanding leg travels from the
        bend corner, in the ladder's local (across, depth, up) frame
        that self.ptt() already converts to global. Both components are
        horizontal - the OSL stays in the plan plane with the rail leg.

        The rail leg runs toward the support, i.e. along
        (0, _BENT_STANDOFF_Y_SIGN). The OSL turns off it by
        (180 - ic_bend_angle) degrees, splitting into a component that
        keeps going toward the support (cos) and one that swings
        OUTBOARD, away from the ladder centerline (sin). `side` is
        -1/+1 for the left/right rail, so outboard is just +side. The
        default ic_bend_angle=90 therefore gives a pure outboard leg
        lying flat on the support face, and 180 means no bend at all
        (the piece continues straight into the support).

        Which way that outboard swing goes is the user's Toe In/Toe Out
        choice (ic_toe) as of 2026-09-22 - Toe In is the same bend
        turned the other way, so it just negates the sin component.
        _BENT_STANDOFF_SIGN remains the build-wide flip point on top of
        that, for the case where BOTH toe directions come out mirrored
        from what the names say. The cos component tracks
        _BENT_STANDOFF_Y_SIGN rather than a hardcoded -1 so it keeps
        matching whichever way the rail leg itself actually runs.
        """
        s = self.state
        turn = math.radians(180.0 - s.ic_bend_angle)
        toe_sign = -1.0 if s.ic_toe == IcToe.IN else 1.0
        dy = self._BENT_STANDOFF_Y_SIGN * math.cos(turn)
        dx = (self._BENT_STANDOFF_SIGN * toe_sign * side * math.sin(turn))
        return dx, dy

    def _standoff_rail_geometry(self):
        """
        (x_push, y_rail) for how the bent standoff's RAIL leg meets the
        rail, per rail_shape/section - see _bent_intermediate for how
        these are used.

        x_push is added to `half` (same base every rail-adjacent piece
        in this file uses) to reach the rail's OUTER face, mirroring
        the exact same per-shape convention _rail_xy already applies to
        the rail material itself and punch_rung_holes applies to rung
        holes:
          - FLAT_BAR: `half` is that shape's INNER face (confirmed live
            for the standoff via a 2026-09-12 test), so the full
            rail_fb_thick reaches the outer face.
          - HSS rect / round tube: `half` is the tube's CENTROID (per
            _rail_xy's own centroid-vs-edge note), so only half its own
            across-ladder dimension (FlangeWidth or Depth/diameter)
            reaches the outer face.
          - Channel: shp.FlangeWidth.
          - Angle: shp.WebThickness.

        y_rail is where the rail leg's NEAR end (p_rail) sits, as a
        distance toward the climber from the rung CL plane (y=0) -
        zero for every shape except channel. A channel's
        long dimension (its Depth - the web-to-toe span, confirmed by
        this file's own rail placement: IsLongLegVerticalMaterial is
        forced "HZ." for angles, and _section_y_shift's docstring calls
        its return value a "depth-centering offset") runs FORE-AFT
        (toward/away from the climber) rather than across the ladder,
        centered on the rung CL plane - so the flange closest to the
        climber sits at +Depth/2 from that plane. The rail leg is
        supposed to land flush against THAT flange, not the web at
        y=0, per a live report that it needed to reach it.
        """
        s = self.state
        if s.rail_shape == RailShape.FLAT_BAR:
            return s.rail_fb_thick, 0.0
        if s.rail_shape != RailShape.SECTION:
            return 0.0, 0.0
        sec = (s.rail_section or "").upper()
        try:
            shp = Shape(s.rail_section)
        except Exception:
            return 0.0, 0.0
        if sec.startswith("HSS") and not self._is_hss_round(sec):
            return shp.FlangeWidth, 0.0
        if sec.startswith("PIPE") or self._is_hss_round(sec):
            return shp.Depth, 0.0
        if sec.startswith(("L", "ML")):
            return shp.WebThickness, 0.0
        if sec.startswith(("C", "MC")):
            return shp.FlangeWidth, shp.Depth / 2.0
        return 0.0, 0.0

    def _punch_standoff_osl_bolt(self, standoff, x_rail, y_bend,
                                 dx, dy, elevation):
        """
        The single bolt hole on the OUTSTANDING leg - the one turning
        outboard at the support face - for the types whose support end
        is bolted (IntermediateConnection.OSL_BOLTED), which is where a
        Bolted-Welded standoff's bolt belongs. ic_bolt_qty/ic_edge_dist
        were removed 2026-09-12: every bolted OSL now takes exactly one
        bolt, sitting ic_gage out from the HEEL of the bend along
        whichever way _bend_leg_direction points this leg.

        (x_rail, y_bend) is the bend CENTERLINE point - the path point
        _bent_plate_layout_piece's pts actually bend around - not the
        heel. The heel is the bend's outside corner, which sits half a
        thickness further back toward the rail leg than that centerline
        point (same half_thick-per-corner the bend already consumes -
        see _pull_back's docstring). Gage-ing straight off the
        centerline point therefore over-shoots the heel by half_thick;
        confirmed via a live 2026-09-12 field test with the hole landing
        exactly half the plate thickness too far out. Subtracting it
        back out here (rather than moving x_rail/y_bend themselves,
        which are also the rail leg's own reference point) keeps the
        correction local to this one hole.

        (dx, dy) is that unit direction and (x_rail, y_bend) the bend
        corner, both handed down from _bent_intermediate rather than
        recomputed, so the hole can't drift from the leg the piece was
        actually built with.

        The standoff is always a _bent_plate_layout_piece formed piece
        (Designable.Proxies BntPlateLayout/PlateLayout), never a
        RectPlate, so this goes straight through _punch_formed (same
        mechanism punch_rung_holes uses for a BEND_FULL_RAIL rail) -
        the legacy Hole()/NS-FS-unset face sweep was confirmed live to
        fail on this material type regardless of face, because the
        centerline point it punches at doesn't sit on any real surface
        polygon (see _punch_formed's docstring).
        """
        s = self.state
        gage = s.ic_gage - s.ic_plate_thick / 2.0
        ok = self._punch_formed(standoff, x_rail + dx * gage,
                                y_bend + dy * gage, elevation,
                                s.ic_plate_thick,
                                s.ic_bolt_dia, s.ic_bolt_dia,
                                preferred_axis=(dx, dy))
        if not ok:
            self.log.warn("standoff OSL bolt hole did not punch")

    def _rail_depth(self):
        """
        Front-to-back extent of the rail material itself - flat bar's
        own rail_fb_width (already documented in LadderState as
        "width (depth of rail)"), or a section rail's Depth (the same
        front-to-back extent _section_y_shift already treats `rt` as).
        Used only by _gate_pt's climb-side shift below.
        """
        s = self.state
        if s.rail_shape == RailShape.FLAT_BAR:
            return s.rail_fb_width
        try:
            return Shape(s.rail_section).Depth
        except Exception:
            return 0.0

    def _rail_across(self):
        """
        ACROSS-the-ladder extent of the rail material - the companion
        to _rail_depth's front-to-back one. Flat bar's own
        rail_fb_thick (its rail_fb_width is the front-to-back
        dimension, per LadderState's own "width (depth of rail)"
        wording); a section's FlangeWidth, except a round tube where
        Depth doubles as the diameter in both directions - the same
        per-shape convention _rail_xy already applies when it pushes
        the rail outward. Used by the gate's hinge/hasp plates to
        clear the rail's outer face.
        """
        s = self.state
        if s.rail_shape == RailShape.FLAT_BAR:
            return s.rail_fb_thick
        sec = (s.rail_section or "").upper()
        try:
            shp = Shape(s.rail_section)
            if sec.startswith("PIPE") or self._is_hss_round(sec):
                return shp.Depth
            return shp.FlangeWidth
        except Exception:
            return 0.0

    def _gate_mount_x_offset(self, plate_thick):
        """
        Outboard (away from the ladder centerline) delta for a gate
        hinge/hasp plate: half the plate's own thickness plus half the
        rail's across-ladder dimension, which is what puts the plate
        flat on the OUTSIDE face of the rail rather than buried in it.

        Returned as a magnitude to SUBTRACT from the x handed to
        _build_gate_hinge/_build_gate_hasp: that x is already the
        negated rail position (see build_gate), and _gate_pt negates
        once more, so subtracting here comes out as outboard.
        """
        return plate_thick / 2.0 + self._rail_across() / 2.0

    def _gate_mount_offsets(self, plate_width, plate_thick):
        """
        (y_wp, x_out_delta) for a gate HINGE plate, per the live
        2026-09-22 report: toward the ladder by one full plate width,
        and outboard onto the rail's outer face.

        In this assembly's own flipped frame (_gate_pt) the gate
        projects out at INCREASING local y, so "toward the ladder" is
        -y - one full plate_width down from the half-width centering
        these plates used before, landing y_wp at -plate_width/2.

        The hasp does NOT come through here: its front-to-back
        placement is given directly by its own two reaches off the
        gate-tip datum, see _build_gate_hasp.
        """
        y_wp = plate_width / 2.0 - plate_width
        return y_wp, self._gate_mount_x_offset(plate_thick)

    def _gate_pt(self, x, y, z):
        """
        Local -> global for gate/hinge/hasp geometry only, folding in
        the correction reported live 2026-09-19: the whole assembly
        (gate, hinges, hasp) needs to rotate 180 degrees about the
        ladder's own vertical centerline (x=0/y=0 in local coordinates
        - negating both x and y does exactly that), then shift AWAY
        from the climber by half the rail's own depth (_rail_depth) so
        it clears the rail instead of landing on/inside it (the first
        pass had this shift backwards - corrected 2026-09-19, same
        report: "gate offset went the wrong direction"). Every gate/
        hinge/hasp coordinate is built through this instead of the
        plain self.ptt() build_gate used before, so build_gate's own
        x_hinge/x_latch/y_near/y_far documentation below still
        describes the CONCEPTUAL layout - this is what actually places
        it. UNCONFIRMED beyond the specific corrections reported; ready
        for the next live test.
        """
        rd = self._rail_depth()
        return self.ptt(-x, -y - rd / 2.0, z)

    def build_gate(self, rails):
        """
        Security gate: ONE formed bent plate (_bent_plate_layout_piece,
        the same mechanism _purchased_rung uses), U-shaped in PLAN -
        per the user's exact spec (2026-09-19): "the gate itself is
        simply a u shaped bent plate. In plan it will look like a U."

        The U's two open ends sit near the rails - one at the hinge
        rail (gate_hinge_side), one at the opposite (latch) rail - and
        the bend between them projects gate_depth out toward the climber
        (+y - "on the climb side of the ladder", same sense pt()/
        ptt()'s "y away from support" docstring already uses for the
        rung/flare/return's own outward direction), so "the open part
        of the u will face the ladders" reads as: both open ends face
        back at the rails, not out at the climber. See _gate_pt for the
        actual placement correction applied on top of this layout.

        Extruded vertically from gate_bottom_elev to gate_top_elev
        (both relative to the ladder's own bottom_elev, per the user's
        explicit request - see LadderState.gate_bottom_abs/gate_top_abs),
        centered on its own plan path the same way _purchased_rung's
        cross-section is centered on its own plane (both hand
        _bent_plate_layout_piece a `width` that extrudes perpendicular
        to whatever plane `pts` varies in) - here pts vary in X/Y at a
        fixed reference Z (the gate's own mid-height), so the height
        passed as `width` extrudes along Z, centered on that mid-height.

        Width is the user's own gate_width again as of 2026-09-22. It
        was build-computed from the RAILS' outside-to-outside dimension
        at the MAIN (shaft) section between 2026-09-20 and then, after
        a live report that a typed width could end up matching the
        FLARE's spacing instead ("the gate is currently being [sized]
        so that the outside width equals the inside width of the flare.
        We need it to be the outside width of the main ladder
        section."). That derived figure is still computed below and
        logged, and LadderState.gate_width_display still offers it as
        the suggested value, but it no longer overwrites what the user
        typed.

        The span is spent on the OUTER faces of the two leg
        plates, not their centerlines: a "Center"-origin formed piece
        extends `thick` half on each side of its own path (see
        _bent_plate_layout_piece), so a leg centered at x=+-half would
        put its outer face at half + gate_thick/2, gate_thick wider
        overall than the true rail-to-rail span. Narrowing each leg's
        centerline inward by half_thick cancels that exactly, so the
        built gate's true outside dimension matches the rails - the
        live-reported "needs to be narrowed on each side" fix.

        UNCONFIRMED against a live build - first pass at brand-new
        geometry per the user's own description, not yet tested.
        """
        s = self.state
        gate_bottom, gate_top = s.gate_bottom_abs, s.gate_top_abs
        self.log.info("  gate %s to %s, hinge %s"
                      % (fmt_len(gate_bottom), fmt_len(gate_top),
                         s.gate_hinge_side))

        half_inside = s.inside_width / 2.0
        x_rail_left, _ = self._rail_xy(-1.0, half_inside)
        x_rail_right, _ = self._rail_xy(1.0, half_inside)
        outside_width_main = abs(x_rail_right - x_rail_left)
        if abs(s.gate_width - outside_width_main) > 1e-6:
            self.log.info("  gate width %s (rails' own outside-to-outside "
                          "at the main section is %s)"
                          % (fmt_len(s.gate_width),
                             fmt_len(outside_width_main)))

        half = (s.gate_width - s.gate_thick) / 2.0
        hinge_sign = -1.0 if s.gate_hinge_side == HingeSide.LEFT else 1.0
        x_hinge = hinge_sign * half
        x_latch = -hinge_sign * half
        y_near = 0.0
        y_far = s.gate_depth
        z_ref = (gate_bottom + gate_top) / 2.0
        height = gate_top - gate_bottom
        half_thick = s.gate_thick / 2.0

        p_hinge_near = self._gate_pt(x_hinge, y_near, z_ref)
        p_hinge_far = self._gate_pt(x_hinge, y_far, z_ref)
        p_latch_far = self._gate_pt(x_latch, y_far, z_ref)
        p_latch_near = self._gate_pt(x_latch, y_near, z_ref)
        # Same "the bend consumes thickness/2 of the leg's real length
        # beyond the straight-line distance between the points we hand
        # it" pull-back _purchased_rung already applies to its own
        # open-end legs (see that method's docstring) - both of this
        # piece's open ends are legs off a bend exactly the same way.
        p_hinge_near = self._pull_back(p_hinge_near, p_hinge_far, half_thick)
        p_latch_near = self._pull_back(p_latch_near, p_latch_far, half_thick)

        radius = max(s.gate_radius, 0.0)
        pts = [(p_hinge_near, 0.0), (p_hinge_far, radius),
              (p_latch_far, radius), (p_latch_near, 0.0)]

        piece = self._bent_plate_layout_piece(pts, height, s.gate_thick,
                                              "Ladder Gate")
        if piece is None:
            self.log.warn("gate was NOT created")

        # Hinges/hasp mount to the RAIL, not to the gate leg's own
        # (now narrowed) x position - per a live 2026-09-20 report,
        # they need to "move sideways towards the centerline...lay on
        # the outside of the rail and gate", i.e. attach right at the
        # rail's own outer face (same reference every rail piece in
        # this file uses, _rail_xy(side, half_inside)) rather than
        # gate_width/2, which no longer necessarily lines up with the
        # rail now that the gate itself is a user-independent
        # dimension. hinge_sign/-hinge_sign are the TRUE physical
        # rail sides (-1=left, +1=right, matching every other side
        # argument in this file) - the same values _rail_xy already
        # expects.
        #
        # x_rail_* pass through _gate_pt's own x-negation (reported
        # live 2026-09-19 - the whole gate/hinge/hasp assembly is
        # built in a 180-degree-rotated local frame), so they are
        # negated here first, same as x_latch/x_hinge were before -
        # otherwise the computed rail position lands on the WRONG
        # physical rail once _gate_pt flips it back. Reuses the same
        # x_rail_left/x_rail_right this method already computed above
        # for the gate's own outside-width, rather than calling
        # _rail_xy a second time.
        x_rail_hinge_side = x_rail_left if hinge_sign < 0 else x_rail_right
        x_rail_latch_side = x_rail_right if hinge_sign < 0 else x_rail_left
        for elev in s.gate_hinge_elevations():
            self._build_gate_hinge(-x_rail_hinge_side, hinge_sign, elev)

        if s.gate_hasp:
            self._build_gate_hasp(-x_rail_latch_side, -hinge_sign, rails)

    def _build_gate_hinge(self, x, side, elev):
        """
        One plain plate at the hinge-side rail, `elev` being one of
        LadderState.gate_hinge_elevations() - a placeholder for the
        real hinge hardware, same "plain plate + user-editable
        description" treatment the user asked for, matching
        _purchased_rung's own description pattern exactly (override
        field first, auto-generated size callout otherwise).

        Built via _flat_bar_rail (a vertical pt1->pt2 RectPlate using
        the same confirmed-correct _axes_rail(side) orientation every
        vertical rail piece already uses) rather than inventing a new
        axes triad - see that method's own width/thick/description
        override params, added for exactly this use.

        Placement (both y_wp and the outboard x) comes from
        _gate_mount_offsets - see it for the 2026-09-22 spec and for
        why the outboard delta is SUBTRACTED from x here. RectPlate's
        width extends the full amount from the workpoint toward -y
        under this axes triad (confirmed via _rail_xy's FLAT_BAR
        y_shift correction, which places a WIDTH-centered-on-0 piece's
        workpoint at +width/2), which is why y_wp is expressed
        relative to that half-width centering rather than as a raw
        offset.
        """
        s = self.state
        half_h = s.gate_hinge_height / 2.0
        y_wp, x_out = self._gate_mount_offsets(s.gate_hinge_width,
                                               s.gate_hinge_thick)
        x_mount = x - side * x_out
        p1 = self._gate_pt(x_mount, y_wp, elev - half_h)
        p2 = self._gate_pt(x_mount, y_wp, elev + half_h)
        auto_desc = ("%s X %s X %s HINGE PL"
                     % (fmt_len(s.gate_hinge_width),
                        fmt_len(s.gate_hinge_height),
                        fmt_len(s.gate_hinge_thick)))
        piece = self._flat_bar_rail(
            p1, p2, side, usage="Ladder Gate Hinge", is_main=False,
            width=s.gate_hinge_width, thick=s.gate_hinge_thick,
            description=s.gate_hinge_description or auto_desc,
            color=self.color_conn)
        if piece is None:
            self.log.warn("gate hinge at %s was NOT created"
                          % fmt_len(elev))

    def _build_gate_hasp(self, x, side, rails):
        """
        One plain plate at the latch-side rail with a single hole
        sized for a padlock shackle (gate_hasp_hole_dia) - own size
        fields (gate_hasp_*), independent of the hinge plates'.
        Elevation is gate_hasp_offset from the gate's own vertical
        center, defaulting to 0 (dead center) per the user's spec,
        adjustable in case it lands on a rung.

        Front-to-back size and position come from two reaches off ONE
        datum (2026-09-22): the plane where the closed gate's tip meets
        the face of the rail nearest the gate. That plane is exactly
        local y=0 in this assembly's own frame - _gate_pt's own
        -rail_depth/2 shift already puts y=0 on the rail's gate-facing
        face - so gate_hasp_w_gate reaches from there toward the gate
        (+y here) and gate_hasp_w_rail back across the rail (-y). The
        plate's overall width is their sum, and its workpoint sits at
        the +y end of that span because RectPlate's width runs the full
        amount toward -y from the workpoint (see _build_gate_hinge).

        The padlock hole is gate_hasp_edge_dist in from the RAIL-side
        edge, which is what lands it over the rail so the matching rail
        hole lines up - measuring from the gate-side edge instead would
        put it out past the rail with nothing behind it.

        Outboard placement is still shared with the hinges
        (_gate_mount_x_offset), and it carries no description override:
        it is just a piece of plate, so the auto-generated size callout
        is the only description.

        The matching RAIL hole is punched by sweeping every piece in
        `rails`, since build_gate does not otherwise know which of
        build_rails' several pieces per side covers this elevation -
        see _punch_gate_hasp_hole.
        """
        s = self.state
        elev = ((s.gate_bottom_abs + s.gate_top_abs) / 2.0
               + s.gate_hasp_offset)
        half_h = s.gate_hasp_height / 2.0
        width = s.gate_hasp_w_gate + s.gate_hasp_w_rail
        # Live 2026-09-22: the plate landed one full width short, on the
        # climber side of where it belongs, so the whole assembly - hole
        # included, it has to stay on the plate - moves one width toward
        # the return/top side. Gate-local +y runs toward the climber
        # (see _gate_pt), so "away from the climber" is -width here.
        y_datum = -width
        y_wp = s.gate_hasp_w_gate + y_datum
        y_hole = -(s.gate_hasp_w_rail - s.gate_hasp_edge_dist) + y_datum
        x_mount = x - side * self._gate_mount_x_offset(s.gate_hasp_thick)
        p1 = self._gate_pt(x_mount, y_wp, elev - half_h)
        p2 = self._gate_pt(x_mount, y_wp, elev + half_h)
        auto_desc = ("%s X %s X %s HASP PL"
                     % (fmt_len(width),
                        fmt_len(s.gate_hasp_height),
                        fmt_len(s.gate_hasp_thick)))
        piece = self._flat_bar_rail(
            p1, p2, side, usage="Ladder Gate Hasp", is_main=False,
            width=width, thick=s.gate_hasp_thick,
            description=auto_desc, color=self.color_conn)
        if piece is None:
            self.log.warn("gate hasp was NOT created")
            return
        # The hole sits at its own y (over the rail), NOT at the plate's
        # workpoint y - the plate and the rail are punched from that one
        # shared point so a padlock passes through both.
        self._punch_gate_hasp_hole(piece, x_mount, y_hole, elev, rails)

    def _punch_gate_hasp_hole(self, hasp_piece, x, y_hole, elev, rails):
        """
        One hole through the hasp plate itself and a matching one
        through whichever rail piece sits at this point, both centered
        on the same physical point so a padlock passes through both.

        Which of `rails` (built by build_rails/build_flare/
        build_return, several pieces per side) actually covers this
        elevation is not tracked separately here, so every piece is
        tried in turn and whichever one's Hole().create() actually
        succeeds is kept - the same "sweep and keep the first success"
        approach _build_base_plate's own holes already use for an
        unconfirmed face/target. UNCONFIRMED
        against a live build.
        """
        s = self.state
        pt = self._gate_pt(x, y_hole, elev)
        dia = float(s.gate_hasp_hole_dia)
        face_candidates = (FACE_NS, FACE_FS, FACE_WEB_NS, FACE_WEB_FS, None)

        def _punch_one(target):
            for face in face_candidates:
                try:
                    h = Hole()
                    h.mtrl = [target]
                    h.pt1 = pt
                    if face:
                        h.face = face
                    h.hole_type = "Standard Round"
                    h.bolt_dia = dia
                    h.hole_dia = dia
                    h.columns = 1
                    h.rows = 1
                    h.locate = "Center"
                    h.valid_cnc = "Yes"
                    h.show_window = "No"
                    h.create()
                    return True
                except Exception:
                    continue
            return False

        if not _punch_one(hasp_piece):
            self.log.warn("gate hasp plate hole did not punch")
            self._diag_hasp_hole_sweep(hasp_piece, x, y_hole, elev, dia)

        for r in rails:
            if r is not None and _punch_one(r):
                break
        else:
            self.log.warn("gate hasp rail hole did not punch "
                          "(tried %d rail piece(s))"
                          % len([r for r in rails if r is not None]))

    def _diag_hasp_hole_sweep(self, hasp_piece, x, y_hole, elev, dia):
        """
        Quiet, log-only sweep run when the hasp PLATE's own hole fails
        to punch - the same idea as _diag_punch_sweep does for the rung
        holes, and for the same reason: one build then names the
        point/face that actually lands instead of costing a round trip
        per guess.

        The rung-hole version proved the failure mode is almost always
        WHERE pt1 sits rather than which face is named (a point off any
        polygon matches nothing, whatever face is asked for), so this
        walks pt1 across the plate's own thickness - the plate is a
        RectPlate built by _flat_bar_rail, whose workpoint/thickness
        convention is the open question here - and retries each offset
        against every plausible face.
        """
        s = self.state
        t = s.gate_hasp_thick
        offsets = (("workpoint", 0.0),
                   ("+half thick", t / 2.0),
                   ("-half thick", -t / 2.0),
                   ("+full thick", t),
                   ("-full thick", -t))
        faces = ((FACE_NS, "NS Face"), (FACE_FS, "FS Face"),
                 (None, "unset"))
        self.log.info("    diag hasp hole: thick=%s at x=%s y=%s"
                      % (fmt_len(t), fmt_len(x), fmt_len(y_hole)))
        for label, dx in offsets:
            for face, fname in faces:
                pt = self._gate_pt(x + dx, y_hole, elev)
                try:
                    h = Hole()
                    h.mtrl = [hasp_piece]
                    h.pt1 = pt
                    if face:
                        h.face = face
                    h.hole_type = "Standard Round"
                    h.bolt_dia = dia
                    h.hole_dia = dia
                    h.columns = 1
                    h.rows = 1
                    h.locate = "Center"
                    h.valid_cnc = "Yes"
                    h.show_window = "No"
                    h.create()
                    ok, err = True, ""
                except Exception as exc:
                    ok, err = False, str(exc).replace("\n", " ")
                self.log.info("    diag hasp %-12s %-8s -> %s%s"
                              % (label, fname, "OK" if ok else "FAILED",
                                 "" if ok else (": %s" % err)))


# ---------------------------------------------------------------------------
# Offline dry-run helper (used by the test harness only)
# ---------------------------------------------------------------------------
def build(state, origin=(0.0, 0.0), log=None):
    log = log or BuildLog()
    g = LadderGeometry(None, state, log)
    g.ox, g.oy = origin
    g._describe()
    if not HAVE_SDS2:
        log.warn("SDS2 unavailable - dry run")
    return [], log



# ---------------------------------------------------------------------------
# PROBES - run these in the SDS2 python console
# ---------------------------------------------------------------------------

def probe_bentplate_api():
    """
    Probe BntPlateLayout and BntPlate AFTER setting a member context,
    since these objects fail attribute access without one.

    Usage (run inside a custom member's CreateMaterial):
        from LadderBuild import probe_bentplate_api
        probe_bentplate_api(self)   # pass the member object (self)
    """
    # This probe must be called from CreateMaterial so self is available.
    # Call it like: probe_bentplate_api(self)
    import plate_layout, bnt_plate, rect_plate, flat_bar
    from member import Member

    print("=" * 70)
    print("PROBE: BntPlate and BntPlateLayout")
    print("=" * 70)

    for mod_name, cls_name in [
        ("flat_bar",    "FlatBar"),
        ("rect_plate",  "RectPlate"),
        ("bnt_plate",   "BntPlate"),
        ("plate_layout","BntPlateLayout"),
        ("plate_layout","PlateLayout"),
    ]:
        mod = __import__(mod_name)
        factory = getattr(mod, cls_name, None)
        if factory is None:
            print("\n%s.%s: NOT FOUND" % (mod_name, cls_name))
            continue
        print("\n%s.%s" % (mod_name, cls_name))
        try:
            obj = factory()
        except Exception as e:
            print("  construct() failed: %s" % e)
            continue
        for n in sorted(dir(obj)):
            if n.startswith("_"):
                continue
            try:
                v = getattr(obj, n)
                d = getattr(v, "__doc__", "") or ""
                print("  %-35s %s" % (n, d.split("\n")[0][:50]))
            except Exception as e:
                print("  %-35s <err: %s>" % (n, e))


def probe_bentplate_with_member(member_self):
    """
    Call this from your CreateMaterial, passing self:
        from LadderBuild import probe_bentplate_with_member
        probe_bentplate_with_member(self)
    """
    from member import Member
    import plate_layout, bnt_plate
    from Point3D import Point3D

    mem = Member(member_self.GetMemberNumber())
    base = member_self.GetLeftLocation()

    print("=" * 70)
    print("PROBE: BntPlate with live member")
    print("=" * 70)

    for mod_name, cls_name in [("bnt_plate","BntPlate"),
                                 ("plate_layout","BntPlateLayout")]:
        mod = __import__(mod_name)
        factory = getattr(mod, cls_name, None)
        if not factory:
            continue
        print("\n--- %s.%s ---" % (mod_name, cls_name))
        try:
            obj = factory()
            obj.member = mem
            obj.pt1 = (base.x, base.y, base.z)
            obj.pt2 = (base.x, base.y, base.z + 12.0)
            obj.thick = 0.25
            obj.width = 4.0
            obj.work_pt_dist = 12.0
            obj.length = 12.0
            obj.origin = "Center"
            obj.ref_pt_offset = (0.0, 0.0, 0.0)
            obj.mtrl_type = "Plate"
            obj.mtrl_usage = "Test"
            obj.mtrl_is_main = "No"
            print("  set basic attrs OK - now checking layout-specific attrs:")
            for n in sorted(dir(obj)):
                if n.startswith("_"):
                    continue
                # only show ones not in flat_bar to find unique attrs
                try:
                    v = getattr(obj, n)
                    d = getattr(v, "__doc__", "") or ""
                    print("  %-35s %s" % (n, d.split("\n")[0][:50]))
                except Exception as e:
                    print("  %-35s <err: %s>" % (n, e))
        except Exception as e:
            print("  FAILED: %s" % e)


def probe_dump(obj, label):
    """
    Dump every attribute on obj to the message window and to a log
    file next to this script. Specifically calls out anything with
    "face" in the name, since that's usually what's needed to fix
    Hole() face_str problems.

    Usage - drop this right after any .Add()/.add() call on a live
    material object:
        from LadderBuild import probe_dump
        probe_dump(rs, "live channel rail RolledSection")
    """
    import datetime as _dt

    lines = []
    lines.append("=" * 70)
    lines.append("PROBE DUMP: %s" % label)
    lines.append("class: %s" % type(obj))
    lines.append("=" * 70)

    for n in sorted(dir(obj)):
        if n.startswith("_"):
            continue
        try:
            v = getattr(obj, n)
            if callable(v):
                lines.append("  [method] %-35s" % n)
            else:
                lines.append("  %-35s = %r" % (n, v))
        except Exception as exc:
            lines.append("  %-35s <error: %s>" % (n, exc))

    lines.append("")
    lines.append("-- attributes/methods with 'face' in the name --")
    found_face = False
    for n in sorted(dir(obj)):
        if "face" in n.lower():
            found_face = True
            try:
                v = getattr(obj, n)
                lines.append("  %-35s = %r" % (n, v))
            except Exception as exc:
                lines.append("  %-35s <error: %s>" % (n, exc))
    if not found_face:
        lines.append("  (none found)")

    text = "\n".join(lines)
    print(text)

    try:
        here = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(here, "probe_dump.log")
        with open(path, "a") as fh:
            fh.write("\n%s\n" % _dt.datetime.now().isoformat())
            fh.write(text)
            fh.write("\n")
    except Exception:
        path = None

    try:
        summary = "PROBE DUMP written for %s (%d lines)" % (label, len(lines))
        if path:
            summary += "\nFile: %s" % path
        param.Warning(summary)
    except Exception:
        pass

    return text
    """
    Find ALL attributes on a live FlatBar, looking for round/radius/end-prep.
    Call from CreateMaterial:
        from LadderBuild import probe_flatbar_with_member
        probe_flatbar_with_member(self)
    """
    from member import Member
    import flat_bar
    from Point3D import Point3D

    mem = Member(member_self.GetMemberNumber())
    base = member_self.GetLeftLocation()

    print("=" * 70)
    print("PROBE: FlatBar with live member - ALL attrs")
    print("=" * 70)

    obj = flat_bar.FlatBar()
    obj.member = mem
    obj.pt1 = (base.x, base.y, base.z)
    obj.pt2 = (base.x, base.y, base.z + 12.0)
    obj.thick = 0.375
    obj.width = 2.5
    obj.work_pt_dist = 12.0
    obj.length = 12.0
    obj.origin = "Center"
    obj.ref_pt_offset = (0.0, 0.0, 0.0)
    obj.mtrl_type = "Plate"
    obj.mtrl_usage = "Test"
    obj.mtrl_is_main = "No"

    for n in sorted(dir(obj)):
        if n.startswith("_"):
            continue
        try:
            v = getattr(obj, n)
            d = getattr(v, "__doc__", "") or ""
            print("  %-40s %s" % (n, d.split("\n")[0][:45]))
        except Exception as e:
            print("  %-40s <err: %s>" % (n, e))

def probe_bar_materials_with_member(member_self):
    """
    Call this from your _CreateMaterial, passing self:
        from LadderBuild import probe_bar_materials_with_member
        probe_bar_materials_with_member(self)
    """
    from member import Member

    mem = Member(member_self.GetMemberNumber())
    base = member_self.GetLeftLocation()

    print("=" * 70)
    print("PROBE: Bar Materials (RndBar, SqrBar, FlatBar)")
    print("=" * 70)

    for mod_name, cls_name in [
        ("rnd_bar", "RndBar"),
        ("sqr_bar", "SqrBar"),
        ("flat_bar", "FlatBar")
    ]:
        print("\n--- %s.%s ---" % (mod_name, cls_name))
        try:
            mod = __import__(mod_name)
            factory = getattr(mod, cls_name, None)
            if not factory:
                print("  Class not found.")
                continue
                
            obj = factory()
            obj.member = mem
            obj.pt1 = (base.x, base.y, base.z)
            obj.pt2 = (base.x, base.y, base.z + 12.0)
            
            for n in sorted(dir(obj)):
                if n.startswith("_"):
                    continue
                try:
                    v = getattr(obj, n)
                    d = getattr(v, "__doc__", "") or ""
                    print("  %-25s %s" % (n, d.split("\n")[0][:45]))
                except Exception as e:
                    print("  %-25s <err: %s>" % (n, e))
        except Exception as e:
            print("  FAILED: %s" % e)