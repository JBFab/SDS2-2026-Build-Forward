"""
=============================================================================
JBSimpleLadder
Copyright (c) 2026 Jason Bondioli

LICENSE AND TERMS OF USE:
Permission is hereby granted to use, copy, modify, and freely distribute 
this software, subject to the following conditions:

1. ATTRIBUTION: Any distribution of this software, whether in its original 
   or modified form, must clearly credit the original author, Jason Bondioli.

2. NO RESALE: This software and any of its derivatives may not be sold or 
   packaged for commercial gain by anyone other than the original author.

3. DISCLAIMER OF LIABILITY: THE SOFTWARE IS PROVIDED "AS IS", WITHOUT 
   WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. In no event shall the author 
   be held responsible for any mishaps, lost work, data loss, or other 
   damages arising from the use of this software or its derivatives. 
=============================================================================
"""

"""
=============================================================================
 JBSimpleLadder - LadderState
=============================================================================
 Single source of truth for every user input.

 Nothing in this module imports SDS2 or PySide6, so it can be unit-tested
 standalone and is safe to import from both the dialog and the modeler.

 All linear dimensions are stored in DECIMAL INCHES.
 All angles are stored in DEGREES (converted to radians only at the API
 boundary, since SDS2 rotations want radians).
=============================================================================
"""

import json
import re
import copy


# ---------------------------------------------------------------------------
# Enumerations (plain strings so they serialize cleanly to JSON)
# ---------------------------------------------------------------------------
class LadderType:
    ROOF_HATCH = "Roof Hatch"
    SIDE_STEP = "Side Step"
    STEP_THROUGH = "Step Through"
    ALL = (ROOF_HATCH, SIDE_STEP, STEP_THROUGH)


class RailShape:
    FLAT_BAR = "Flat Bar"
    SECTION = "Material File Section"
    ALL = (FLAT_BAR, SECTION)


class FlareConstruction:
    """
    How the step-through flare transition (shaft -> flare -> extension)
    is fabricated. Flat bar rails only - a SECTION rail always uses the
    beveled-cut miter joint (_section_rail's FlangeCut), which has no
    bent equivalent here.
    """
    CUT_WELDED = "Cut & Welded"            # existing: 3 straight pieces, mitered
    BEND_FLARE = "Bend Flare Extensions"   # flare + extension formed as 1 piece;
                                            # shaft stays a separate straight piece
    BEND_FULL_RAIL = "Bend Full Rail"      # shaft + flare + extension all 1 piece
    ALL = (CUT_WELDED, BEND_FLARE, BEND_FULL_RAIL)


class RungShape:
    ROUND_BAR = "Round Bar"
    SQUARE_BAR = "Square Bar"
    PURCHASED = "Purchased Rung"
    ALL = (ROUND_BAR, SQUARE_BAR, PURCHASED)


class RungSpacingMode:
    ODD_FIRST = "First Rung Odd + Spacing"
    EVEN = "Evenly Spaced"
    ALL = (ODD_FIRST, EVEN)


class BottomConnection:
    NONE = "None"
    BOLT_BOLT_ANGLE = "Bolted-Bolted Angle"
    BOLT_WELD_ANGLE = "Bolted-Welded Angle"
    BASE_PLATE = "Base Plate"
    ALL = (NONE, BOLT_BOLT_ANGLE, BOLT_WELD_ANGLE, BASE_PLATE)


class BcOSLSide:
    """
    Bottom connection clip angle only: which side of the rail the
    angle's horizontal leg (against the floor) sticks out toward.
    Mapped onto RolledSection's native ToeInOrOut ('In'/'Out') - the
    same property _section_rail uses for the rails themselves.
    """
    INSIDE = "OSL Inside"
    OUTSIDE = "OSL Outside"
    ALL = (INSIDE, OUTSIDE)


class BcLegOrientation:
    """
    Bottom connection clip angle only, matters for an unequal-leg
    angle: which leg is vertical (against the rail) vs horizontal
    (against the floor). Mapped onto RolledSection's native
    IsLongLegVerticalMaterial - same property _section_rail uses for
    the rails (which always hardcode it to "HZ."; "VT." for the long
    leg vertical case is not otherwise confirmed in this codebase).
    """
    LLV = "Long Leg Vertical (LLV)"
    LLH = "Long Leg Horizontal (LLH)"
    ALL = (LLV, LLH)


class IcToe:
    """
    Which way the bent-plate standoff's outstanding leg turns where it
    meets the support: OUT swings it away from the ladder centerline,
    IN swings it toward the centerline - the same bend, 90 degrees the
    other way. Applies to both BENT_* IntermediateConnection types
    (bolted and welded); it describes the piece's shape, not how its
    ends are fastened.

    Was hardcoded to OUT (LadderBuild._BENT_STANDOFF_SIGN) until
    2026-09-22.
    """
    OUT = "Toe Out"
    IN = "Toe In"
    ALL = (OUT, IN)


class IntermediateConnection:
    """
    How each intermediate standoff attaches at its two ends.

    The BENT_* types both build the SAME bent-plate standoff
    (LadderBuild._bent_intermediate) - the Bolted/Welded words only say
    how each END is fastened, not what shape the piece is.

    Word order is (support end)-(rail end), matching the convention
    BottomConnection already uses and that was confirmed against a live
    build: "Bolted-Welded Angle" bolts the FLOOR leg and welds the RAIL
    leg (see LadderBuild._punch_bc_clip). So Bolted-Welded here bolts
    the OSL that reaches the support and welds the leg against the rail.

    BENT_BOLT_BOLT ("Bent Plate Bolted-Bolted") was removed 2026-09-12 -
    the rail leg is always welded now, so every remaining type welds it
    and only the OSL can be bolted.

    FLAT_PLATE ("Flat Plate") was removed 2026-09-19 per explicit user
    request - every remaining type builds the same bent-plate standoff
    (LadderBuild._bent_intermediate is now the only path build_
    intermediate ever takes; see BENT below).
    """
    BENT_BOLT_WELD = "Bent Plate Bolted-Welded"
    BENT_WELD_WELD = "Bent Plate Welded-Welded"
    ALL = (BENT_BOLT_WELD, BENT_WELD_WELD)

    # Every remaining type builds a real bent piece - kept as its own
    # tuple (rather than just using ALL) so build_intermediate's own
    # `s.ic_type in IntermediateConnection.BENT` reads the same way it
    # did when FLAT_PLATE made this a real distinction.
    BENT = (BENT_BOLT_WELD, BENT_WELD_WELD)
    # Types with a bolted outstanding leg (the rail leg is always welded).
    OSL_BOLTED = (BENT_BOLT_WELD,)

    # Values persisted by older versions of this plugin, which stored
    # ic_type as a raw string on the member. Mapped forward on load so
    # an existing ladder keeps meaning what it meant - except that the
    # old "Bolted-Welded"/"Welded-Welded" never actually bent, so those
    # members will now rebuild as the bent piece the name promised, the
    # removed Bolted-Bolted type falls forward to Bolted-Welded (its
    # rail leg is now welded instead of bolted), and the removed Flat
    # Plate type falls forward to Bolted-Welded too (the closest
    # equivalent - a welded rail leg, bolted OSL).
    LEGACY = {
        "Bolted-Welded": BENT_BOLT_WELD,
        "Welded-Welded": BENT_WELD_WELD,
        "Bent Plate Bolted-Bolted": BENT_BOLT_WELD,
        "Flat Plate": BENT_BOLT_WELD,
    }

    @classmethod
    def normalize(cls, value):
        """Current enum value for `value`, mapping legacy strings."""
        text = str(value or "")
        if text in cls.ALL:
            return text
        return cls.LEGACY.get(text, cls.BENT_BOLT_WELD)


class IntermediateSpacing:
    EVEN = "Evenly Spaced"
    AT_ELEVATIONS = "At Specified Elevations"
    ALL = (EVEN, AT_ELEVATIONS)


class ElevDatum:
    """
    Which datum a typed elevation is measured from. Added 2026-09-22
    so the intermediate connections and the gate can each be located
    either way instead of each being locked to one.

    ABSOLUTE    - a real model elevation, the same numbers the
                  Location page's own bottom/top elevations use.
    FROM_BOTTOM - measured up from the ladder's own bottom end
                  (bottom_elev), so the feature keeps its position
                  relative to the ladder when the ladder moves.

    Defaults preserve each feature's previous behaviour: the
    intermediate connections were absolute, the gate was from-bottom.
    """
    ABSOLUTE = "Absolute Elevation"
    FROM_BOTTOM = "From Ladder Bottom"
    ALL = (ABSOLUTE, FROM_BOTTOM)


class ReturnConnection:
    """
    How the step-through return leg lands at the top level.

    The two clip-angle options and Bent Leg on Return were REMOVED
    2026-09-22 at the user's request - only Welded Direct and Base
    Plate are offered now. The constants are kept (not deleted) purely
    so an existing member persisted with one of them still loads
    instead of raising; _coerce_return_conn maps any of them onto
    WELDED. Do NOT add them back to ALL.
    """
    NONE = "No Return"
    WELDED = "Welded Direct"
    BASE_PLATE = "Base Plate"
    ALL = (NONE, WELDED, BASE_PLATE)

    # Retired - see the class docstring.
    BOLT_WELD_CLIP = "Bolted-Welded Clip Angle"
    BOLT_BOLT_CLIP = "Bolted-Bolted Clip Angle"
    BENT_LEG = "Bent Leg on Return"
    RETIRED = (BOLT_WELD_CLIP, BOLT_BOLT_CLIP, BENT_LEG)


class PickMode:
    ONE_POINT_PLAN = "Single Point (Plan)"
    TWO_POINT_ELEV = "Two Points (Elevation)"
    ALL = (ONE_POINT_PLAN, TWO_POINT_ELEV)


class HingeSide:
    LEFT = "Left"
    RIGHT = "Right"
    ALL = (LEFT, RIGHT)


class HSSPunchMode:
    INNER_ONLY = "Inner Face Only"
    BOTH_FACES = "Both Faces (Through)"
    PLUG_WELD = "Plug Weld (Different Outer Dia)"
    ALL = (INNER_ONLY, BOTH_FACES, PLUG_WELD)    


# ---------------------------------------------------------------------------
# Field metadata: drives the dialog AND the preview highlight wiring.
#
#   key        -> attribute name on LadderState
#   label      -> what the user sees
#   kind       -> 'len' | 'ang' | 'int' | 'bool' | 'str' | 'choice' | 'mtrl'
#   page       -> which dialog page it belongs on
#   detail     -> which preview blow-up detail illustrates it (or None)
#
# The `key` is also the token the preview widget uses to decide what to
# highlight, so these strings must match the preview's dimension tags.
# ---------------------------------------------------------------------------
FIELD_PAGES = (
    "Location",
    "Type & Top",
    "Rails",
    "Rungs",
    "Connections",
    "Gate",
)


class LadderState(object):
    """Every parameter for one JBSimpleLadder instance."""

    VERSION = 1

    def __init__(self):
        # -- Location ----------------------------------------------------
        self.pick_mode = PickMode.ONE_POINT_PLAN
        self.rotation = 90.0             # degrees, 0 = ladder faces +X
        self.bottom_elev = 0.0          # floor
        self.top_elev = 144.0           # top surface of top rung
        self.standoff = 7.0             # face of support -> CL of rung

        # -- Type & Top --------------------------------------------------
        self.ladder_type = LadderType.ROOF_HATCH
        self.rungs_above_top = 0        # side step only
        self.hatch_rail_extension = 0.0 # roof hatch: bare rail stub above top
        self.rail_setback_bottom = 0.0  # wall-mounted: rail stops short of
                                         # bottom_elev by this much (rung
                                         # elevations are unaffected)

        self.ext_height = 42.0          # top rung -> top of extension

        # -- Flare (step through) ---------------------------------------
        self.flare_enabled = True
        self.flare_to_bend = 6.0        # top elev -> bend PI (inside of mtrl)
        self.flare_angle = 45.0         # degrees off vertical
        self.flare_width = 24.0         # inside-to-inside at top of flare
        self.flare_construction = FlareConstruction.CUT_WELDED
        self.flare_radius = 6.0         # inside bend radius - only used when
                                         # flare_construction is BEND_FLARE or
                                         # BEND_FULL_RAIL

        # -- Return down to top level -------------------------------------
        # Step-through + has_flare only (see has_return). Each rail's
        # extension turns AWAY from the climber, out over the platform/
        # roof edge by return_width, then back down to land return_setback
        # above top_elev (the "top level" this group's name refers to).
        # The landing connection (return_conn) is deliberately built by
        # its own ret_conn_* dedicated functions/fields rather than
        # reusing BottomConnection's bc_* helpers - the return can land
        # on different things than the bottom connection does. Only
        # Welded Direct and Base Plate remain (2026-09-22) - the clip
        # angle and bent leg landings, and every ret_conn_ang_/bolt_/
        # weld_/gage/bent_osl field that only fed them, were removed
        # with them. See ReturnConnection's own docstring.
        self.return_enabled = False
        self.return_width = 8.0         # climb-side rail face -> far side
                                         # of the return leg
        self.return_setback = 4.0       # top_elev -> bottom of return leg
        self.return_conn = ReturnConnection.WELDED

        self.ret_conn_bp_thick = 0.375
        self.ret_conn_bp_length = 2.5
        self.ret_conn_bp_center_offset = 0.0
        self.ret_conn_bp_width_in = 3.0
        self.ret_conn_bp_width_out = 3.0
        self.ret_conn_bp_edge_in = 1.25
        self.ret_conn_bp_edge_out = 1.25
        self.ret_conn_bp_hole_dia = 0.8125
        self.ret_conn_bp_hole_in_enabled = True
        self.ret_conn_bp_hole_out_enabled = True

        # -- Rails -------------------------------------------------------
        self.rail_shape = RailShape.FLAT_BAR
        self.rail_section = ""          # section name from JBMaterialPicker
        self.rail_fb_width = 2.5        # flat bar: width (depth of rail)
        self.rail_fb_thick = 0.375      # flat bar: thickness
        self.inside_width = 18.0        # 1'-6" inside the rails  <-- default
        self.rail_grade = ""            # blank = job default
        # -- Rails (Additions) --
        # OSL side is not a user control: angle rails are always built
        # OSL Near Side (Far Side was never verified working and is now
        # unreachable - see LadderBuild._section_rail/_section_roll).
        # Long leg orientation is not a user control either: angle rails
        # are always built Long Leg to Rung (see LadderBuild._section_rail).

        self.round_top = False          # flat bar only
        self.round_top_radius = 0.0     # 0 = auto (half thickness)

        self.cap_ends = False           # HSS/Pipe sections only
        self.cap_thick = 0.375
        self.cap_top = True
        self.cap_bottom = True
        self.cap_overhang = 0.0



        # -- Rungs -------------------------------------------------------
        self.rung_shape = RungShape.ROUND_BAR
        self.rung_size = 0.75           # dia (round) or across-flats (square)
        self.rung_spacing_mode = RungSpacingMode.ODD_FIRST
        self.rung_spacing = 12.0
        self.first_rung_odd = 3.0       # floor -> first rung when ODD_FIRST

        self.rung_setback = 0.0         # setback from OUTSIDE of rail:
        #   0     = rung runs flush to the outside face of each rail
        #   1/8   = rung stops 1/8" short of the outside face, each end
        # (buyout / purchased rungs ignore this - they weld to the inside)
        self.hole_clearance = 0.0625    # rung size + this = hole dia
        self.hole_dia_override = 0.0    # >0 forces an exact hole dia
        # -- Rungs (Additions) --
        self.hss_punch_mode = HSSPunchMode.INNER_ONLY
        self.hss_outer_hole_dia = 0.8125
        self.hss_setback = 0.0625  # Setback relative to outermost wall for HSS/Pipe

        # Purchased rung (inverted "U" bent plate layout)
        self.pr_width = 3.0             # overall outside width of the U
        self.pr_height = 1.25           # leg height
        self.pr_thick = 0.1875          # material thickness
        self.pr_radius = 0.25           # inside bend radius
        self.pr_description = ""        # overrides material user description

        # -- Connections -------------------------------------------------
        self.bottom_conn = BottomConnection.NONE
        self.bc_ang_size = "L4x4x3/8"    # section name from JBMaterialPicker
        self.bc_ang_length = 6.0
        self.bc_osl_side = BcOSLSide.INSIDE
        self.bc_leg_orientation = BcLegOrientation.LLV
        self.bc_bolt_dia = 0.75
        self.bc_bolt_qty = 1
        self.bc_weld_size = 0.25

        # Base plate: horizontal plate under each rail, front-to-back
        # (bp_length) x across-the-ladder (bp_width_in + bp_width_out),
        # two holes. bp_width_in/out are measured from the plane where
        # the rung first intersects the rail (inside_width/2), NOT the
        # plate's own centerline, so the plate can be asymmetric about
        # the rail. bp_length defaults to 2.5" (the default flat bar
        # rail's depth) - adjust to match whatever rail is selected.
        self.bp_thick = 0.375
        self.bp_length = 2.5
        self.bp_center_offset = 0.0     # + = away from the climber (toward
                                         # support) - see LadderBuild's
                                         # 2026-09-20 climber-direction
                                         # convention note
        self.bp_width_in = 3.0
        self.bp_width_out = 3.0
        self.bp_hole_dia = 0.8125
        self.bp_edge_in = 1.25
        self.bp_edge_out = 1.25
        self.bp_hole_in_enabled = True
        self.bp_hole_out_enabled = True

        self.ic_count = 0
        self.ic_spacing_mode = IntermediateSpacing.EVEN
        self.ic_elevations = []         # list of floats when AT_ELEVATIONS
        self.ic_elev_datum = ElevDatum.ABSOLUTE
        self.ic_type = IntermediateConnection.BENT_BOLT_WELD
        self.ic_plate_width = 3.0       # all types (bent piece's width too)
        self.ic_plate_thick = 0.375
        self.ic_leg = 4.0                # bent types: leg against rail
        self.ic_osl = 4.0                # bent types: outstanding leg,
                                          # reaches out to the support
        self.ic_bend_radius = 0.375
        self.ic_bend_angle = 90.0       # bent types only
        self.ic_toe = IcToe.OUT         # bent types only - which way the
                                         # OSL turns at the support
        self.ic_bolt_dia = 0.75
        self.ic_gage = 2.5               # OSL bolt's distance off the
                                          # heel of the bend (one bolt -
                                          # ic_bolt_qty/ic_edge_dist were
                                          # removed 2026-09-12)

        # -- Gate ----------------------------------------------------------
        # One formed bent plate (_bent_plate_layout_piece), U-shaped in
        # PLAN: two short legs near the rails (the open ends of the U -
        # one hinges to gate_hinge_side, the other is the free/latching
        # edge approaching the opposite rail) joined by a bend that
        # projects gate_depth out toward the climber (+y, same sense as
        # rung projection/the flare's outward direction - see pt()/
        # ptt()'s "y away from support" docstring), then bends back to
        # the other rail. Extruded vertically from gate_bottom_elev to
        # gate_top_elev, centered on that plan path the same way
        # _purchased_rung's profile is centered on its own plane (see
        # that method's docstring on _bent_plate_layout_piece's
        # "width extrudes perpendicular to whatever plane pts vary in,
        # centered on it" convention).
        # gate_bottom_elev/gate_top_elev are read against whichever
        # datum gate_elev_datum names - from the LADDER's own
        # bottom_elev by default (the only behaviour before
        # 2026-09-22), or as absolute model elevations. See
        # LadderState.gate_bottom_abs/gate_top_abs.
        self.gate_enabled = False
        self.gate_bottom_elev = 0.0
        self.gate_top_elev = 42.0
        self.gate_elev_datum = ElevDatum.FROM_BOTTOM
        self.gate_hinge_side = HingeSide.LEFT
        # A user input again as of 2026-09-22. It was made build-
        # computed on 2026-09-20 (always overwritten from the rails'
        # own outside-to-outside dimension at the MAIN/shaft section)
        # after a live report that a typed width could end up matching
        # the FLARE's spacing instead of the rails the gate actually
        # closes against - gate_width_display still carries that
        # suggested figure, and the default below matches it for a
        # 24" ladder, but the typed value is what gets built now.
        self.gate_width = 24.0
        self.gate_depth = 1.5           # rail plane -> outer (climb-side)
                                         # face of the U's bend
        self.gate_thick = 0.1196        # 11 ga sheet
        self.gate_radius = 0.1875       # 3/16 inside bend radius, each
                                         # corner
        # Clearance rail-to-gate was a user field (gate_gap); hardcoded
        # to 0 per the user's explicit request - see LadderBuild.build_gate.

        # Hinges: plain plates along the hinge-side rail. Quantity and
        # end-inset are user fields (default 3 hinges, 6" in from each
        # end, remaining hinges evenly spaced between those two - see
        # LadderBuild.build_gate's _gate_hinge_elevations).
        self.gate_hinge_qty = 3
        self.gate_hinge_offset = 6.0    # inset from gate_bottom_elev/
                                         # gate_top_elev to the first/
                                         # last hinge
        self.gate_hinge_width = 3.0
        self.gate_hinge_height = 4.0
        self.gate_hinge_thick = 0.375
        self.gate_hinge_description = ""   # blank = auto-generated, same
                                            # pattern as pr_description

        # Hasp: one plain plate at the latch-side rail with a single
        # hole sized for a padlock shackle - LadderBuild also punches a
        # MATCHING hole through the rail itself at the same point, so a
        # padlock can pass through both. gate_hasp_offset is measured
        # from the gate's own vertical center (gate_bottom_elev/
        # gate_top_elev midpoint), not an absolute elevation, so it
        # naturally defaults to "center of gate height" (0.0) and keeps
        # tracking the gate's own span if that span changes, while
        # still being adjustable in case it lands on a rung.
        #
        # The plate's front-to-back size is given as two reaches from a
        # single datum plane rather than one overall width (2026-09-22):
        # the datum is the plane where the closed gate's tip meets the
        # face of the rail nearest the gate, gate_hasp_w_gate reaches
        # from there toward the gate and gate_hasp_w_rail back across
        # the rail. The padlock hole sits gate_hasp_edge_dist in from
        # the rail-side edge - measured from THAT edge, not the gate
        # side, because the hole has to land over the rail for the
        # matching rail hole to line up with it.
        #
        # gate_hasp_w_rail defaults to the default flat bar rail's own
        # width; it does not auto-follow rail_fb_width/the section,
        # deliberately - a build-computed dimension silently overriding
        # a typed one is the trap gate_width had to be pulled back out
        # of on 2026-09-22.
        self.gate_hasp = True
        self.gate_hasp_w_gate = 1.0
        self.gate_hasp_w_rail = 2.5
        self.gate_hasp_edge_dist = 0.5
        self.gate_hasp_height = 4.0
        self.gate_hasp_thick = 0.375
        self.gate_hasp_hole_dia = 0.5
        self.gate_hasp_offset = 0.0
        # No description override here, unlike the hinges: the hasp is
        # just a piece of plate (removed 2026-09-22), so LadderBuild's
        # auto-generated size callout is always its description.

        # -- Bookkeeping -------------------------------------------------
        self.description = "JBSimpleLadder"
        self.last_tab = 0     # dialog nav row last viewed - see
                               # LadderDialog._page_changed - so re-
                               # opening an existing ladder for Edit
                               # returns to the tab last being used.

    # -----------------------------------------------------------------
    # Derived geometry helpers - pure math, no SDS2
    # -----------------------------------------------------------------
    @property
    def climb_height(self):
        """Floor to top surface of top rung."""
        return max(0.0, self.top_elev - self.bottom_elev)

    @property
    def rung_half_length(self):
        """
        Half the rung length, from ladder centreline to the rung END.

        The rung reaches the OUTSIDE face of the rail, then is pulled back
        by rung_setback. So:

            half = inside/2 + rail_thickness - setback

        setback 0   -> rung end flush with outside of rail
        setback 1/8 -> rung end 1/8" inside the outside face
        """
        return (self.inside_width / 2.0
                + self.rail_thickness
                - self.rung_setback)

    @property
    def rung_length(self):
        return 2.0 * self.rung_half_length

    @property
    def effective_rung_embed(self):
        """Backwards-compatible alias used by the preview detail."""
        return max(0.0, self.rail_thickness - self.rung_setback)

    @property
    def rail_thickness(self):
        """Thickness the rung punches into. For sections this is the wall."""
        if self.rail_shape == RailShape.FLAT_BAR:
            return self.rail_fb_thick
        if self._section_wall_cache:
            return self._section_wall_cache
        return 0.25

    _section_wall_cache = 0.0

    def set_section_wall(self, thickness):
        """Called after the material file lookup gives us the real wall."""
        self._section_wall_cache = float(thickness or 0.0)

    @property
    def bc_leg_sizes(self):
        """(long_leg, short_leg) inches, parsed from bc_ang_size."""
        return parse_angle_legs(self.bc_ang_size)

    @property
    def bc_vertical_leg(self):
        """Whichever leg (long or short) bc_leg_orientation put against the rail."""
        long_leg, short_leg = self.bc_leg_sizes
        return long_leg if self.bc_leg_orientation == BcLegOrientation.LLV else short_leg

    @property
    def bc_horizontal_leg(self):
        """Whichever leg (long or short) bc_leg_orientation put against the floor."""
        long_leg, short_leg = self.bc_leg_sizes
        return short_leg if self.bc_leg_orientation == BcLegOrientation.LLV else long_leg

    @property
    def bc_vertical_gage(self):
        return standard_angle_gage(self.bc_vertical_leg)

    @property
    def bc_horizontal_gage(self):
        return standard_angle_gage(self.bc_horizontal_leg)

    @property
    def hole_diameter(self):
        if self.hole_dia_override > 0.0:
            return self.hole_dia_override
        return self.rung_size + self.hole_clearance

    @property
    def rung_hole_shape(self):
        """
        SDS2 Hole() hole_type for the rail hole a rung sits in - a
        square bar needs a square hole, not a round one sized to its
        diagonal. Purchased rungs never reach this (they weld to the
        inside face, no holes - see build_rungs), so only ROUND_BAR and
        SQUARE_BAR matter here.
        """
        if self.rung_shape == RungShape.SQUARE_BAR:
            return "Standard Square"
        return "Standard Round"

    @property
    def is_closed_shape(self):
        """Closed shapes get punched on the inside face only."""
        if self.rail_shape == RailShape.FLAT_BAR:
            return False
        s = (self.rail_section or "").upper()
        return s.startswith("HSS") or s.startswith("PIPE")

    @property
    def rail_is_round(self):
        """
        True for a round Pipe or round HSS rail. String-only check (no
        live Shape() lookup - this module has no SDS2 imports) mirroring
        LadderBuild._is_hss_round: round HSS is HSS<dia>x<wall> (one 'X'
        after the prefix), rectangular/square HSS has two. A purchased
        rung welds to a flat inside face, which a round rail does not
        have - see RungShape.PURCHASED and rung_shape's dialog wiring.
        """
        s = (self.rail_section or "").upper()
        if self.rail_shape != RailShape.SECTION:
            return False
        if s.startswith("PIPE"):
            return True
        return s.startswith("HSS") and s[3:].count("X") == 1

    @property
    def drill_both_sides(self):
        """Flat bar punches through; tube punches inside face only."""
        return not self.is_closed_shape

    @property
    def has_flare(self):
        return (self.ladder_type == LadderType.STEP_THROUGH
                and self.flare_enabled)

    @property
    def has_return(self):
        """Step-through + flare only - see the Return field comments."""
        return (self.ladder_type == LadderType.STEP_THROUGH
                and self.has_flare
                and self.return_enabled)

    def rung_elevations(self):
        """
        Return the list of rung centerline elevations, bottom to top.

        The TOP rung's *top surface* sits at top_elev, so its centerline is
        half a rung below that.
        """
        half = self.rung_size / 2.0
        top_cl = self.top_elev - half
        out = []

        if self.climb_height <= 0.0:
            return out

        if self.rung_spacing_mode == RungSpacingMode.ODD_FIRST:
            # The top rung is fixed at top_cl. Work DOWN from it at the
            # nominal spacing; whatever is left over at the bottom becomes
            # the odd first space. That guarantees every space except the
            # first is exactly rung_spacing, and never leaves a sliver at
            # the top (which is what a naive upward walk produces).
            sp = max(self.rung_spacing, 0.0625)
            usable = top_cl - (self.bottom_elev + self.first_rung_odd)
            if usable < 0:
                out = [round(top_cl, 4)]
            else:
                # Walk down from the fixed top rung at full spacing for as
                # long as the remaining bottom space stays >= the user's
                # odd dimension. The leftover is absorbed INTO the first
                # space, so the odd space is always the largest one rather
                # than a stub. first_rung_odd is therefore a minimum.
                n_full = int(usable / sp + 1e-6)
                out = [round(top_cl - sp * i, 4)
                       for i in range(n_full, -1, -1)]
                # Drop the lowest rung if it would sit closer to the floor
                # than the odd dimension allows, folding it into space 1.
                while len(out) > 1 and (out[0] - self.bottom_elev) < \
                        self.first_rung_odd - 1e-6:
                    out.pop(0)
        else:
            span = top_cl - self.bottom_elev
            if span <= 0:
                return [round(top_cl, 4)]
            n = max(1, int(round(span / max(self.rung_spacing, 0.0625))))
            step = span / float(n)
            for i in range(1, n + 1):
                out.append(round(self.bottom_elev + step * i, 4))

        # Side step extras carry the same spacing above the top rung
        if (self.ladder_type == LadderType.SIDE_STEP
                and self.rungs_above_top > 0):
            base = out[-1] if out else top_cl
            sp = (self.rung_spacing
                  if self.rung_spacing_mode == RungSpacingMode.ODD_FIRST
                  else (out[-1] - out[-2] if len(out) > 1
                        else self.rung_spacing))
            for i in range(1, self.rungs_above_top + 1):
                out.append(round(base + sp * i, 4))

        return out

    @property
    def effective_top_elev(self):
        """
        Top-of-ladder reference elevation for rail/cap height - NOT
        just top_elev. Side step ladders add rungs_above_top extra
        rungs above top_elev at the same spacing as the rest of the
        ladder (see rung_elevations), so the rail has to reach that
        new top rung's top surface, not stop at the original top_elev.
        Reduces to top_elev exactly when there are no extra rungs
        (every other ladder type, and side step with rungs_above_top
        == 0), so it is safe to use unconditionally in place of
        top_elev anywhere the rail/cap top is computed.
        """
        elevs = self.rung_elevations()
        if not elevs:
            return self.top_elev
        return elevs[-1] + self.rung_size / 2.0

    @property
    def ic_is_bent(self):
        """True when ic_type builds a real bent standoff (not FLAT_PLATE)."""
        return self.ic_type in IntermediateConnection.BENT

    @property
    def ic_osl_bolted(self):
        """True when the outstanding leg (to the support) gets bolts."""
        return self.ic_type in IntermediateConnection.OSL_BOLTED

    @property
    def ic_bolt_pattern_length(self):
        """
        Length a bolted leg must run to fit its one bolt hole, which
        sits ic_gage out from the bend/heel (ic_bolt_qty/ic_edge_dist
        were removed 2026-09-12 - every bolted OSL now takes exactly
        one bolt).
        """
        return self.ic_gage

    @property
    def ic_bent_rail_leg_length(self):
        """
        Length of the bent standoff's RAIL leg - the one running from
        the rail back to the support. It is `standoff` (defined as "face
        of support -> CL of rung"), which is exactly the span that leg
        has to cover, NOT the ic_leg field: a leg shorter than the
        standoff simply doesn't reach the support.
        """
        return self.standoff

    @property
    def ic_bent_leg2_length(self):
        """
        MINIMUM length the outstanding leg needs to fit its own bolt
        pattern - zero unless that leg is the bolted one. The built leg
        is max(ic_osl, this), so an explicit ic_osl never comes out
        shorter than the bolts actually need.
        """
        if not self.ic_osl_bolted:
            return 0.0
        return self.ic_bolt_pattern_length

    def _datum_base(self, datum):
        """0 for an absolute elevation, the ladder's own bottom end for
        a from-the-bottom one - add it to a typed value to get a real
        model elevation. See ElevDatum."""
        return 0.0 if datum == ElevDatum.ABSOLUTE else self.bottom_elev

    def intermediate_elevations(self):
        """Absolute elevations of the intermediate standoff connections."""
        if self.ic_count <= 0:
            return []
        if self.ic_spacing_mode == IntermediateSpacing.AT_ELEVATIONS:
            base = self._datum_base(self.ic_elev_datum)
            return [base + float(e)
                    for e in self.ic_elevations][: self.ic_count]
        lo = self.bottom_elev
        hi = self.top_elev
        n = self.ic_count
        step = (hi - lo) / float(n + 1)
        return [round(lo + step * (i + 1), 4) for i in range(n)]

    @property
    def gate_bottom_abs(self):
        """Gate bottom as a real model elevation, gate_bottom_elev read
        against whichever datum gate_elev_datum names."""
        return self._datum_base(self.gate_elev_datum) + self.gate_bottom_elev

    @property
    def gate_top_abs(self):
        """Gate top, absolute elevation (see gate_bottom_abs)."""
        return self._datum_base(self.gate_elev_datum) + self.gate_top_elev

    @property
    def rail_outside_reach(self):
        """
        Approximate outward reach (centerline -> outer face) of one
        rail at the main (shaft) section - flat bar's own rail_fb_width
        exactly, or a flat 3.0" placeholder for any section shape.
        LadderState/LadderPreview have no live SDS2 Shape lookup
        available (this module has zero SDS2 imports, by design, so it
        works fully offline), so this is only an approximation for the
        dialog's read-only display and the preview drawing - the same
        simplified convention LadderPreview's own elevation/plan
        drawing already used before this property existed.
        LadderBuild computes the EXACT figure at build time via real
        Shape.Depth/FlangeWidth lookups (_rail_xy) and that is what
        actually drives the built gate - see build_gate.
        """
        return (self.rail_fb_width if self.rail_shape == RailShape.FLAT_BAR
                else 3.0)

    @property
    def gate_width_display(self):
        """
        Approximate main-section outside width - what gate_width
        defaults to matching. Kept as the preview's own reference (and
        as a sane suggestion) now that gate_width is a real user input
        again as of 2026-09-22; the BUILD uses the typed gate_width,
        not this. See rail_outside_reach for why this is only an
        approximation (no SDS2 Shape access in this module).
        """
        return self.inside_width + 2.0 * self.rail_outside_reach

    def gate_hinge_elevations(self):
        """
        ABSOLUTE elevations for the gate's hinge plates, bottom to top.

        Default (qty=3): one gate_hinge_offset above the gate's bottom,
        one gate_hinge_offset below its top, one centered between them -
        the user's explicit spec. Generalized for other quantities:
        first/last always sit at the offset inset from each end;
        anything in between is spaced evenly across the remaining span.
        qty=1 centers the single hinge; qty=2 is just the two end
        hinges with nothing between them.
        """
        if not self.gate_enabled or self.gate_hinge_qty < 1:
            return []
        bottom, top = self.gate_bottom_abs, self.gate_top_abs
        lo = bottom + self.gate_hinge_offset
        hi = top - self.gate_hinge_offset
        n = self.gate_hinge_qty
        if n == 1:
            return [(bottom + top) / 2.0]
        if hi < lo:
            lo = hi = (bottom + top) / 2.0
        step = (hi - lo) / float(n - 1)
        return [round(lo + step * i, 4) for i in range(n)]

    # -----------------------------------------------------------------
    # Validation - returns a list of (severity, field_key, message)
    # -----------------------------------------------------------------
    def validate(self):
        issues = []
        E, W = "error", "warn"

        if self.climb_height <= 0:
            issues.append((E, "top_elev",
                           "Top elevation must be above bottom elevation."))
        if self.inside_width < 12.0:
            issues.append((W, "inside_width",
                           "Inside width under 1'-0\" is unusually narrow."))
        if self.rung_size <= 0:
            issues.append((E, "rung_size", "Rung size must be positive."))
        if self.rung_spacing <= 0:
            issues.append((E, "rung_spacing", "Rung spacing must be positive."))
        if self.rung_spacing > 12.0:
            issues.append((W, "rung_spacing",
                           "Rung spacing over 12\" exceeds typical code max."))

        if self.rail_shape == RailShape.SECTION and not self.rail_section:
            issues.append((E, "rail_section", "No rail section selected."))

        if self.rung_setback < 0:
            issues.append((W, "rung_setback",
                           "Setback is negative; rung runs past the rail."))
        if self.rung_setback > self.rail_thickness:
            issues.append((W, "rung_setback",
                           "Setback exceeds rail thickness; rung will not "
                           "reach the hole."))
        if self.hole_diameter <= self.rung_size:
            issues.append((W, "hole_clearance",
                           "Hole is not larger than the rung."))

        if self.has_flare:
            if self.flare_width < self.inside_width:
                issues.append((W, "flare_width",
                               "Flare width is narrower than the ladder."))
            if self.flare_angle <= 0 or self.flare_angle >= 90:
                issues.append((E, "flare_angle",
                               "Flare angle must be between 0 and 90 degrees."))
            if self.flare_construction in (FlareConstruction.BEND_FLARE,
                                           FlareConstruction.BEND_FULL_RAIL):
                if self.rail_shape != RailShape.FLAT_BAR:
                    issues.append((W, "flare_construction",
                                   "Bent flare/rail is only built for flat "
                                   "bar rails; section rails use the cut & "
                                   "welded miter instead."))
                if self.flare_radius < 0:
                    issues.append((E, "flare_radius",
                                   "Flare bend radius cannot be negative."))

        if self.ic_count > 0 and self.ic_is_bent:
            # The rail leg is the standoff, not ic_leg - a zero standoff
            # leaves nothing for that leg to span.
            if self.standoff <= 0:
                issues.append((E, "standoff",
                               "Standoff must be greater than zero for a "
                               "bent-plate intermediate connection - it is "
                               "the length of the leg running from the rail "
                               "to the support."))
            if self.ic_osl <= 0:
                issues.append((E, "ic_osl",
                               "OSL length (outstanding leg to support) "
                               "must be greater than zero."))
            if self.ic_bend_radius < 0:
                issues.append((E, "ic_bend_radius",
                               "Bend radius cannot be negative."))
            if self.ic_bend_angle <= 0 or self.ic_bend_angle >= 180:
                issues.append((E, "ic_bend_angle",
                               "Bend angle must be between 0 and 180 "
                               "degrees."))

        if self.bottom_conn == BottomConnection.BASE_PLATE:
            if self.bp_thick <= 0:
                issues.append((E, "bp_thick",
                               "Base plate thickness must be positive."))
            if self.bp_length <= 0:
                issues.append((E, "bp_length",
                               "Base plate length must be positive."))
            if self.bp_width_in <= 0 or self.bp_width_out <= 0:
                issues.append((E, "bp_width_in",
                               "Base plate width (inside/outside) must be "
                               "positive."))
            if self.bp_hole_dia <= 0:
                issues.append((E, "bp_hole_dia",
                               "Base plate hole diameter must be positive."))
            if self.bp_edge_in > self.bp_width_in:
                issues.append((W, "bp_edge_in",
                               "Inside edge distance exceeds inside width - "
                               "hole falls outside the plate."))
            if self.bp_edge_out > self.bp_width_out:
                issues.append((W, "bp_edge_out",
                               "Outside edge distance exceeds outside width "
                               "- hole falls outside the plate."))

        if self.has_return:
            if self.return_width <= 0:
                issues.append((E, "return_width",
                               "Return width must be positive."))
            if self.return_setback < 0:
                issues.append((W, "return_setback",
                               "Setback is negative; return leg lands "
                               "above the top level."))
            if self.return_setback >= self.ext_height:
                issues.append((E, "return_setback",
                               "Setback must be less than the extension "
                               "height - the return leg has to travel "
                               "down from the top of the extension."))
            if self.return_conn == ReturnConnection.BASE_PLATE:
                if self.ret_conn_bp_thick <= 0:
                    issues.append((E, "ret_conn_bp_thick",
                                   "Base plate thickness must be "
                                   "positive."))
                if self.ret_conn_bp_length <= 0:
                    issues.append((E, "ret_conn_bp_length",
                                   "Base plate length must be positive."))
                if (self.ret_conn_bp_width_in <= 0
                        or self.ret_conn_bp_width_out <= 0):
                    issues.append((E, "ret_conn_bp_width_in",
                                   "Base plate width (inside/outside) "
                                   "must be positive."))

        if (self.ic_spacing_mode == IntermediateSpacing.AT_ELEVATIONS
                and len(self.ic_elevations) < self.ic_count):
            issues.append((E, "ic_elevations",
                           "Fewer elevations listed than connections."))

        if self.gate_enabled:
            if self.gate_top_elev <= self.gate_bottom_elev:
                issues.append((E, "gate_top_elev",
                               "Gate top must be above gate bottom."))
            # No "narrower than the rails" warning here: gate_width_display
            # is only a rough approximation (no SDS2 Shape access in this
            # module - see rail_outside_reach), so it fired on perfectly
            # good widths. Removed 2026-09-22 at the user's request - the
            # typed width is built as typed. The thickness check below
            # stays: it is not a judgement call, a width at or under the
            # plate thickness has no geometry to build.
            if self.gate_width <= self.gate_thick:
                issues.append((E, "gate_width",
                               "Gate width must be greater than its own "
                               "plate thickness."))
            if self.gate_depth <= 0:
                issues.append((E, "gate_depth",
                               "Gate depth must be positive."))
            if self.gate_radius < 0:
                issues.append((E, "gate_radius",
                               "Gate bend radius cannot be negative."))
            if self.gate_hinge_qty < 1:
                issues.append((E, "gate_hinge_qty",
                               "At least one hinge is required."))
            span = self.gate_top_elev - self.gate_bottom_elev
            if (self.gate_hinge_qty >= 2
                    and 2.0 * self.gate_hinge_offset > span):
                issues.append((W, "gate_hinge_offset",
                               "Hinge offset from each end exceeds the "
                               "gate's own height."))
            if self.gate_hasp:
                if self.gate_hasp_hole_dia <= 0:
                    issues.append((E, "gate_hasp_hole_dia",
                                   "Hasp hole diameter must be positive."))
                if self.gate_hasp_w_gate + self.gate_hasp_w_rail <= 0:
                    issues.append((E, "gate_hasp_w_rail",
                                   "Hasp plate has no width - set its gate-"
                                   "side and/or rail-side reach."))
                elif self.gate_hasp_edge_dist > self.gate_hasp_w_rail:
                    # Past the rail-side reach the hole is off the rail
                    # entirely, so the matching rail hole cannot line up.
                    issues.append((E, "gate_hasp_edge_dist",
                                   "Edge distance is greater than the hasp's "
                                   "rail-side width, so the hole lands off "
                                   "the rail."))
                center = (self.gate_bottom_elev + self.gate_top_elev) / 2.0
                hasp_elev = center + self.gate_hasp_offset
                if not (self.gate_bottom_elev <= hasp_elev
                        <= self.gate_top_elev):
                    issues.append((W, "gate_hasp_offset",
                                   "Hasp plate lands outside the gate's "
                                   "own bottom/top elevations."))

        return issues

    # -----------------------------------------------------------------
    # Serialization
    # -----------------------------------------------------------------
    def to_dict(self):
        d = {k: v for k, v in vars(self).items() if not k.startswith("_")}
        d["__version__"] = self.VERSION
        return d

    def from_dict(self, d):
        for k, v in d.items():
            if k.startswith("__"):
                continue
            if hasattr(self, k):
                setattr(self, k, v)
        # A member saved before 2026-09-22 can still carry one of the
        # retired clip-angle/bent-leg landing connections. They are no
        # longer built or offered, so fold them onto Welded Direct
        # rather than leaving a value the combo cannot display and the
        # build no longer handles.
        if self.return_conn in ReturnConnection.RETIRED:
            self.return_conn = ReturnConnection.WELDED
        return self

    def to_json(self):
        return json.dumps(self.to_dict(), sort_keys=True)

    @classmethod
    def from_json(cls, text):
        obj = cls()
        try:
            obj.from_dict(json.loads(text))
        except Exception:
            pass
        return obj

    def clone(self):
        return copy.deepcopy(self)

    def __eq__(self, other):
        if not isinstance(other, LadderState):
            return NotImplemented
        return self.to_dict() == other.to_dict()


# ---------------------------------------------------------------------------
# Imperial formatting helpers (shared by dialog + preview)
# ---------------------------------------------------------------------------
def fmt_len(value, denom=None):
    """
    Decimal inches -> feet-inch-fraction string.

    denom=None picks the coarsest denominator (16, 32, 64, 128) that
    represents the value exactly, so 1/32 and 3/64 survive a round trip
    instead of collapsing to 0".
    """
    v = abs(float(value))
    if denom is None:
        denom = 16
        for d in (16, 32, 64, 128):
            if abs(v * d - round(v * d)) < 1e-9:
                denom = d
                break
        else:
            denom = 64

    neg = value < 0
    total = int(round(v * denom))
    whole_in = total // denom
    num = total - whole_in * denom
    ft = whole_in // 12
    inch = whole_in - ft * 12

    while num and num % 2 == 0:
        num //= 2
        denom //= 2

    parts = []
    if ft:
        parts.append("%d'" % ft)
    if inch or num or not ft:
        frac = ""
        if num:
            frac = " %d/%d" % (num, denom) if inch else "%d/%d" % (num, denom)
        if inch:
            parts.append('%s%d%s"' % ("-" if ft else "", inch, frac))
        elif num:
            parts.append('%s%s"' % ("-" if ft else "", frac))
        else:
            parts.append('%s0"' % ("-" if ft else ""))
    s = "".join(parts)
    return ("-" + s) if neg else s


# ---------------------------------------------------------------------------
# SDS2-style dimension entry
#
# Accepted forms (all resolve to DECIMAL INCHES):
#     18            bare number  -> inches
#     18.5          decimal      -> inches
#     1322.5625     decimal      -> inches (no magnitude limit)
#     3/4           fraction     -> inches
#     6 1/2         mixed        -> inches
#     1-6           feet-inches  -> 18
#     110-2 9/16    feet-inches  -> 1322.5625
#     5'-6"         explicit     -> 66
#     2'            explicit     -> 24
#     11ga          sheet gauge  -> 0.1196 (Mfrs' Standard Gauge table)
#
# Numpad substitutions applied live by DimEdit (see LadderDialog):
#     +  ->  space          *  ->  x
# ---------------------------------------------------------------------------
_FRAC_RE = re.compile(r"^(\d+)\s*/\s*(\d+)$")

# Sheet-steel gauge shorthand ("11ga", "11 gauge", "11GA") - same
# Manufacturers' Standard Gauge for Sheet Steel table SDS2 itself
# resolves a gauge callout against. Confirmed needed via a live
# 2026-09-12 field test: typing "11ga" into a thickness field just
# reverted to the field's previous 3/16" instead of resolving to
# 11ga's actual 0.1196" - _parse_inch_expr has no notion of gauge at
# all, so every digit-then-letters string like this failed to parse
# and fell back to the field's old value (see LenEdit._commit).
_GAGE_RE = re.compile(r"^(\d+)\s*ga(?:uge)?$", re.IGNORECASE)
_GAGE_THICKNESS = {
    3: 0.2391, 4: 0.2242, 5: 0.2092, 6: 0.1943, 7: 0.1793, 8: 0.1644,
    9: 0.1495, 10: 0.1345, 11: 0.1196, 12: 0.1046, 13: 0.0897,
    14: 0.0747, 15: 0.0673, 16: 0.0598, 17: 0.0538, 18: 0.0478,
    19: 0.0418, 20: 0.0359, 21: 0.0329, 22: 0.0299, 23: 0.0269,
    24: 0.0239, 25: 0.0209, 26: 0.0179, 27: 0.0164, 28: 0.0149,
    29: 0.0135, 30: 0.0120,
}


def parse_len(text, default=0.0):
    """Parse an SDS2-style dimension string into decimal inches."""
    if text is None:
        return default
    s = str(text).strip()
    if not s:
        return default

    m = _GAGE_RE.match(s)
    if m:
        return _GAGE_THICKNESS.get(int(m.group(1)), default)

    # numpad conveniences, in case they survive to here
    s = s.replace("+", " ")
    # strip inch / foot marks but remember an explicit foot mark
    had_foot_mark = "'" in s
    s = s.replace('"', "").replace("''", "")

    neg = s.startswith("-")
    if neg:
        s = s[1:].strip()

    feet = 0.0
    inch_part = s

    if had_foot_mark:
        head, _, tail = s.partition("'")
        try:
            feet = float(head.strip())
        except ValueError:
            feet = 0.0
        inch_part = tail.strip().lstrip("-").strip()
    else:
        # "N-rest" is feet-inches shorthand when N is a plain integer and
        # something follows. Guards against eating a bare fraction (3/4)
        # or a negative number.
        head, sep, tail = s.partition("-")
        head = head.strip()
        tail = tail.strip()
        if sep and tail and head and _is_plain_number(head):
            try:
                feet = float(head)
                inch_part = tail
            except ValueError:
                inch_part = s

    inches = _parse_inch_expr(inch_part)
    if inches is None:
        return default
    val = feet * 12.0 + inches
    return -val if neg else val


def _is_plain_number(tok):
    tok = tok.strip()
    if not tok:
        return False
    try:
        float(tok)
        return True
    except ValueError:
        return False


def _parse_inch_expr(text):
    """
    Parse '2 9/16', '9/16', '2', '2.5' into inches.

    Returns None if any token is not a number or a fraction, so callers
    can tell a typo from a legitimate zero.
    """
    if not text:
        return 0.0
    total = 0.0
    saw = False
    for tok in text.replace("-", " ").split():
        m = _FRAC_RE.match(tok)
        if m:
            try:
                d = float(m.group(2))
                if d == 0:
                    return None
                total += float(m.group(1)) / d
                saw = True
                continue
            except ValueError:
                return None
        try:
            total += float(tok)
            saw = True
        except ValueError:
            return None
    return total if saw else 0.0


# ---------------------------------------------------------------------------
# Angle callout parsing + AISC standard gage lookup
#
#     "L6X4X1/2"           -> legs (6.0, 4.0), thickness token ignored
#     "L4x4x3/8"            -> legs (4.0, 4.0)
#     "ML3-1/2X3-1/2X1/4"   -> legs (3.5, 3.5)
# ---------------------------------------------------------------------------
def _parse_angle_dim(tok):
    """A single leg-size token: '6', '3-1/2', '1/2' -> decimal inches."""
    tok = tok.strip()
    if not tok:
        return 0.0
    if "-" in tok:
        whole, _, frac = tok.partition("-")
        try:
            base = float(whole)
        except ValueError:
            base = 0.0
        return base + _parse_angle_dim(frac)
    if "/" in tok:
        num, _, den = tok.partition("/")
        try:
            return float(num) / float(den)
        except (ValueError, ZeroDivisionError):
            return 0.0
    try:
        return float(tok)
    except ValueError:
        return 0.0


def parse_angle_legs(section_size):
    """
    (long_leg, short_leg) in decimal inches, parsed straight out of the
    callout string (e.g. "L6X4X1/2" -> (6.0, 4.0)) rather than from any
    Shape() attribute - for an angle it is NOT confirmed which of
    Shape().Depth/FlangeWidth measures which physical leg, but the
    callout itself is unambiguous. Returns (0.0, 0.0) if unparseable.
    """
    sec = (section_size or "").strip().upper()
    m = re.match(r"^[A-Z]+(.*)$", sec)
    body = m.group(1) if m else sec
    parts = [p for p in body.split("X") if p.strip()]
    if len(parts) < 2:
        return 0.0, 0.0
    a = _parse_angle_dim(parts[0])
    b = _parse_angle_dim(parts[1])
    return (a, b) if a >= b else (b, a)


# AISC standard (single workable line) gage for an angle leg, keyed by
# leg size in inches, largest first. Replaces a free-entry "Gage" field
# per the user's request - stop asking for gage, use the tabulated AISC
# value for whichever leg size the picked angle actually has.
_ANGLE_GAGE_TABLE = (
    (8.0, 4.5), (7.0, 4.0), (6.0, 3.5), (5.0, 3.0), (4.0, 2.5),
    (3.5, 2.0), (3.0, 1.75), (2.5, 1.375), (2.0, 1.125),
    (1.75, 1.0), (1.5, 0.875), (1.25, 0.75), (1.0, 0.625),
)


def standard_angle_gage(leg_size):
    """AISC standard single-line workable gage for one angle leg."""
    for leg, g in _ANGLE_GAGE_TABLE:
        if leg_size >= leg - 1e-6:
            return g
    return _ANGLE_GAGE_TABLE[-1][1]
