"""
=============================================================================
JBSimpleLadder
Copyright (c) 2026 Jason Bondioli

LICENSE AND TERMS OF USE:
Permission is hereby granted to use, copy, modify, and freely distribute 
this software, subject to the following conditions:

1. ATTRIBUTION: Any distribution of this software, whether in its original 
   or modified form, must clearly credit the original author, Jason Bondioli.

2. NO RESALE: This software and any of its derivatives may not be sold or 
   packaged for commercial gain by anyone other than the original author.

3. DISCLAIMER OF LIABILITY: THE SOFTWARE IS PROVIDED "AS IS", WITHOUT 
   WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. In no event shall the author 
   be held responsible for any mishaps, lost work, data loss, or other 
   damages arising from the use of this software or its derivatives. 
=============================================================================
"""

"""
=============================================================================
 JBSimpleLadder - LadderDefaults
=============================================================================
 Job-level plugin defaults: the settings a new ladder starts out with.

 Set them once per job by running the LadderDefaultsSetup.py macro, and
 every ladder placed afterwards opens pre-filled with them instead of
 the factory values. Ladders already in the job are untouched -
 JBSimpleLadder.Add() applies them, and only Add(), so they reach a
 genuinely new ladder and nothing else.

 Why a macro and not SDS2's Plugin Setup menu: registering this with
 PluginSetupTools (2026-09-22) broke that menu for EVERY member plugin
 in the job with "cannot pickle 'module' object". PluginSetupTools is
 compiled into sds2.exe rather than shipped as source, so what it
 pickles could not be inspected. A macro needs nothing from that
 registry and cannot affect other plugins.

 Storage
 -------
 SDS2's own `Storage` module holds one JSON blob per job under
 STORAGE_KEY, so the defaults travel with the job rather than with the
 workstation. The blob is just LadderState.to_json(), which means adding
 a field to LadderState automatically makes it settable as a default -
 there is no second list of field names to keep in sync.

 Anything missing from a saved blob (an older job, a newly added field)
 falls back to that field's LadderState default, so a partial or
 out-of-date blob still loads cleanly.

 This module is deliberately import-safe without SDS2: `Storage` is
 imported inside the functions, and every entry point degrades to plain
 factory defaults if it is unavailable, so LadderDialog/LadderState can
 still be exercised standalone.
=============================================================================
"""

import json

from LadderState import LadderState


STORAGE_KEY = "JBSimpleLadder_Defaults_v1"

# Fields that describe WHERE a particular ladder is, not how ladders in
# this job should be built. Saving these as job defaults would drag one
# ladder's placement onto every ladder placed afterwards, so they are
# stripped on save and ignored on load.
_NOT_DEFAULTABLE = (
    "pick_mode",
    "rotation",
    "bottom_elev",
    "top_elev",
    "ic_elevations",
    "last_tab",
)


def _strip(d):
    """Drop the per-placement fields from a state dict - see
    _NOT_DEFAULTABLE."""
    return {k: v for k, v in d.items() if k not in _NOT_DEFAULTABLE}


def load_defaults():
    """
    The job's saved defaults as a LadderState.

    Starts from a factory LadderState and overlays whatever the job has
    stored, so any field the blob does not mention keeps its factory
    value. Returns a plain factory state if SDS2's Storage is
    unavailable or the job has never had defaults saved.
    """
    state = LadderState()
    try:
        import Storage
        if not Storage.Exists(STORAGE_KEY):
            return state
        uuids = Storage.GetUUIDs(STORAGE_KEY)
        if not uuids:
            return state
        saved = json.loads(Storage.Read(uuids[0]))
    except Exception:
        return state

    if isinstance(saved, dict):
        state.from_dict(_strip(saved))
    return state


def save_defaults(state):
    """
    Write `state` to the job as the new defaults, overwriting any
    previous blob. Returns True on success.

    Failures are reported through param.Warning rather than raised: this
    runs from a setup dialog the user opened deliberately, and losing
    the dialog to a traceback is worse than telling them the save did
    not take.
    """
    try:
        import Storage
        raw = json.dumps(_strip(state.to_dict()), sort_keys=True)
        if Storage.Exists(STORAGE_KEY):
            uuids = Storage.GetUUIDs(STORAGE_KEY)
            if uuids:
                Storage.Write(uuids[0], raw)
                return True
        Storage.Add(STORAGE_KEY, raw)
        return True
    except Exception as exc:
        try:
            import param
            param.Warning("JBSimpleLadder: could not save defaults:\n%s"
                          % exc)
        except Exception:
            pass
        return False


def apply_defaults(member):
    """
    Push the job's saved defaults onto a freshly created member.

    Called from JBSimpleLadder.__init__. An EXISTING member is not
    affected even though this also runs for it: StateAccessor restores
    that member's own persisted values after __init__ returns, so these
    only ever survive on a member that has none yet - the same ordering
    JBLintel relies on for its own defaults.

    Silent on failure by design: a defaults problem must never stop a
    member from being created.
    """
    try:
        state = load_defaults()
    except Exception:
        return
    for name, _factory in member._arguments[0]:
        if name in _NOT_DEFAULTABLE or not hasattr(state, name):
            continue
        try:
            setattr(member, name, getattr(state, name))
        except Exception:
            pass


def edit_defaults():
    """
    Open the defaults editor and save whatever comes back. This is the
    whole setup screen - run it from the LadderDefaultsSetup.py macro.

    It opens the ladder's OWN editor loaded with the current defaults
    rather than rebuilding every field a second time in a native
    dialog, so a default is always edited with the same controls,
    validation and preview as a real ladder. member_number is None, so
    the editor's member-status panel stays inert - there is no member
    here to mark for detailing.

    Returns True if defaults were saved, False if the user cancelled.

    NOTE: this is deliberately NOT wired into SDS2's Plugin Setup menu
    via PluginSetupTools. Registering there broke that menu for every
    member plugin in the job ("cannot pickle 'module' object"), so the
    setup screen is delivered as a plain macro instead - which needs
    nothing from SDS2's plugin registry.
    """
    try:
        import param
        param.Units("feet")
    except Exception:
        pass
    from LadderDialog import run_dialog
    state = load_defaults()
    result = run_dialog(state, member_number=None,
                        title="JB Simple Ladder - Job Defaults",
                        accept_text="Save Defaults")
    if result is None:
        return False
    save_defaults(result)
    return True
