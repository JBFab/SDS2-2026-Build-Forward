"""
=============================================================================
JBSimpleLadder
Copyright (c) 2026 Jason Bondioli

LICENSE AND TERMS OF USE:
Permission is hereby granted to use, copy, modify, and freely distribute 
this software, subject to the following conditions:

1. ATTRIBUTION: Any distribution of this software, whether in its original 
   or modified form, must clearly credit the original author, Jason Bondioli.

2. NO RESALE: This software and any of its derivatives may not be sold or 
   packaged for commercial gain by anyone other than the original author.

3. DISCLAIMER OF LIABILITY: THE SOFTWARE IS PROVIDED "AS IS", WITHOUT 
   WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. In no event shall the author 
   be held responsible for any mishaps, lost work, data loss, or other 
   damages arising from the use of this software or its derivatives. 
=============================================================================
"""

"""
=============================================================================
 JBSimpleLadder - LadderPreview
=============================================================================
 Live, dimensioned elevation / side / detail views drawn with QPainter.

 Design intent
 -------------
 * Every dimension is TAGGED with the LadderState attribute it represents.
 * When a dialog field takes focus it calls set_focus_key(key); the matching
   dimension lights up in the accent colour and everything else desaturates.
   That removes the need for a colour legend the user has to memorise.
 * Some keys map to a blow-up DETAIL (bend geometry, rung embed, cap plate,
   clip angle). Focusing such a field swaps the pane to that detail
   automatically, then returns to the overview on blur.

 No SDS2 imports: this module can be run standalone for UI iteration.
=============================================================================
"""

import math

from PySide6 import QtCore, QtGui, QtWidgets

from LadderState import (
    LadderState, LadderType, RailShape, RungShape,
    BottomConnection, fmt_len,
)


# ---------------------------------------------------------------------------
# Palette - dark, matches the JB Material Picker family
# ---------------------------------------------------------------------------
C_BG        = QtGui.QColor("#1e2128")
C_STEEL     = QtGui.QColor("#8b95a5")
C_STEEL_LIT = QtGui.QColor("#c8d2e2")
C_RUNG      = QtGui.QColor("#7f8ca0")
C_DIM       = QtGui.QColor("#5d6675")   # idle dimension
C_DIM_TEXT  = QtGui.QColor("#8e99aa")
C_ACCENT    = QtGui.QColor("#ffb648")   # focused dimension
C_ACCENT_2  = QtGui.QColor("#4fc3f7")   # secondary highlight
C_GRID      = QtGui.QColor("#272b34")
C_HOLE      = QtGui.QColor("#2a2e37")
C_WELD      = QtGui.QColor("#ff7043")
C_GATE      = QtGui.QColor("#66bb6a")
C_SUPPORT   = QtGui.QColor("#6d4c41")
C_LABEL     = QtGui.QColor("#aab4c4")

# Which detail page a given field key opens.
DETAIL_FOR_KEY = {
    "flare_to_bend":   "flare",
    "flare_angle":     "flare",
    "flare_width":     "flare",
    "flare_radius":    "flare",
    "ext_height":      "flare",

    "rung_embed":      "embed",
    "hole_clearance":  "embed",
    "hole_dia_override": "embed",
    "rung_size":       "embed",
    "rung_shape":      "embed",

    "pr_width":        "purchased",
    "pr_height":       "purchased",
    "pr_thick":        "purchased",
    "pr_radius":       "purchased",

    "cap_thick":       "cap",
    "cap_overhang":    "cap",
    "cap_ends":        "cap",
    "round_top":       "cap",
    "round_top_radius": "cap",

    "bc_ang_size":     "bottom",
    "bc_ang_length":   "bottom",
    "bc_osl_side":     "bottom",
    "bc_leg_orientation": "bottom",
    "bc_bolt_dia":     "bottom",
    "bc_bolt_qty":     "bottom",
    "bottom_conn":     "bottom",
    "bp_thick":        "bottom",
    "bp_length":       "bottom",
    "bp_center_offset": "bottom",
    "bp_width_in":     "bottom",
    "bp_width_out":    "bottom",
    "bp_hole_dia":     "bottom",
    "bp_edge_in":      "bottom",
    "bp_edge_out":     "bottom",

    "ic_plate_width":  "inter",
    "ic_plate_thick":  "inter",
    "ic_leg":          "inter",
    "ic_osl":          "inter",
    "ic_bend_radius":  "inter",
    "ic_bend_angle":   "inter",
    "ic_bolt_dia":     "inter",
    "ic_gage":         "inter",
    "ic_type":         "inter",
    "standoff":        "inter",

    "return_width":    "return",
    "return_setback":  "return",
    "return_conn":     "return",
}

# Keys that belong to the side (plan-depth) view rather than the elevation.
SIDE_VIEW_KEYS = {
    "standoff", "rail_fb_thick", "rung_embed", "hole_clearance",
    "ic_leg", "return_setback",
}


class _Dim(object):
    """One dimension string queued for painting."""
    __slots__ = ("key", "p1", "p2", "text", "offset", "vertical", "tick")

    def __init__(self, key, p1, p2, text, offset=0.0, vertical=False,
                 tick=True):
        self.key = key
        self.p1 = p1
        self.p2 = p2
        self.text = text
        self.offset = offset
        self.vertical = vertical
        self.tick = tick


class LadderPreview(QtWidgets.QWidget):
    """
    Live preview pane.

    Public API
    ----------
    set_state(state)        -> refresh geometry
    set_focus_key(key|None) -> highlight a dimension / swap to its detail
    set_view(name)          -> 'elevation' | 'side' | detail name
    """

    VIEW_ELEVATION = "elevation"
    VIEW_SIDE = "side"

    def __init__(self, state=None, parent=None):
        super().__init__(parent)
        self.state = state or LadderState()
        self.focus_key = None
        self.view = self.VIEW_ELEVATION
        self._auto_detail = None
        self._dims = []
        self._scale = 1.0
        self._ox = 0.0
        self._oy = 0.0
        self.show_ucs = True
        self.setMinimumSize(360, 480)
        self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding,
                           QtWidgets.QSizePolicy.Policy.Expanding)
        self.setAutoFillBackground(True)

    # -- public ---------------------------------------------------------
    def set_state(self, state):
        self.state = state
        self.update()

    def set_focus_key(self, key):
        self.focus_key = key
        detail = DETAIL_FOR_KEY.get(key) if key else None
        self._auto_detail = detail
        if detail:
            self.view = detail
        elif key in SIDE_VIEW_KEYS:
            self.view = self.VIEW_SIDE
        else:
            self.view = self.VIEW_ELEVATION
        self.update()

    def set_view(self, name):
        self.view = name
        self._auto_detail = None
        self.update()

    def set_ucs_visible(self, on):
        """Show/hide the corner axis gizmo. It is drawn over the model,
        so on a tight pane it can still sit on top of the drawing even
        with its own backdrop - this is the out, rather than another
        round of trying to place it somewhere it never collides."""
        self.show_ucs = bool(on)
        self.update()

    # -- painting -------------------------------------------------------
    def paintEvent(self, event):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing, True)
        p.fillRect(self.rect(), C_BG)
        self._grid(p)
        self._dims = []

        v = self.view
        try:
            if v == self.VIEW_ELEVATION:
                self._draw_elevation(p)
            elif v == self.VIEW_SIDE:
                self._draw_side(p)
            elif v == "flare":
                self._draw_detail_flare(p)
            elif v == "embed":
                self._draw_detail_embed(p)
            elif v == "purchased":
                self._draw_detail_purchased(p)
            elif v == "cap":
                self._draw_detail_cap(p)
            elif v == "bottom":
                self._draw_detail_bottom(p)
            elif v == "inter":
                self._draw_detail_inter(p)
            elif v == "return":
                self._draw_detail_return(p)
            else:
                self._draw_elevation(p)
        except Exception as exc:            # never let the preview kill the dialog
            p.setPen(QtGui.QPen(QtGui.QColor("#ef5350")))
            p.drawText(12, 22, "preview error: %s" % exc)

        self._paint_dims(p)
        self._caption(p)
        try:
            self._draw_ucs_icon(p)
        except Exception:
            pass
        p.end()

    # -- helpers --------------------------------------------------------
    def _grid(self, p):
        p.setPen(QtGui.QPen(C_GRID, 1))
        step = 24
        w, h = self.width(), self.height()
        for x in range(0, w, step):
            p.drawLine(x, 0, x, h)
        for y in range(0, h, step):
            p.drawLine(0, y, w, y)

    def _caption(self, p):
        names = {
            self.VIEW_ELEVATION: "Elevation",
            self.VIEW_SIDE: "Side",
            "flare": "Detail  ~  Flare & Extension",
            "embed": "Detail  ~  Rung Embed / Hole",
            "purchased": "Detail  ~  Purchased Rung Section",
            "cap": "Detail  ~  Rail End / Round Over",
            "bottom": "Detail  ~  Bottom Connection",
            "inter": "Detail  ~  Intermediate Connection",
            "return": "Detail  ~  Return Leg",
        }
        f = QtGui.QFont("Segoe UI", 8)
        f.setCapitalization(QtGui.QFont.Capitalization.AllUppercase)
        f.setLetterSpacing(QtGui.QFont.SpacingType.AbsoluteSpacing, 1.2)
        p.setFont(f)
        p.setPen(QtGui.QPen(C_LABEL))
        p.drawText(10, self.height() - 10, names.get(self.view, self.view))

    # -- UCS icon ---------------------------------------------------------
    _AXIS_COLOR = {
        "x": QtGui.QColor("#ef5350"),
        "y": QtGui.QColor("#81c784"),
        "z": QtGui.QColor("#4fc3f7"),
    }

    def _draw_ucs_icon(self, p):
        """
        Small fixed-size axis gizmo, top-left corner, in SCREEN space -
        does not pan/zoom with the model. Lets a shift direction ("+y",
        "toward the climber") be pointed at directly in conversation
        instead of described in words or read off a screenshot (the
        original problem an embedded 3D/PyVista pane was built to
        solve; that pane crashed SDS2 itself via a second in-process
        OpenGL context - see LadderDialog.py's git history/comments -
        so this 2D-only icon is the safe replacement).

        Shows whichever two axes THIS view's own _pt()/_draw_elevation/
        _draw_side actually plot - X (across, rail-to-rail) and Z (up)
        for Elevation, Y (depth) and Z (up) for Side - using the exact
        same +away-from-climber/-toward-climber convention documented
        on LadderBuild.LadderGeometry.pt()'s own docstring. The third,
        out-of-plane axis for this view is named in the caption but not
        drawn - only Elevation and Side get an icon; the detail blow-up
        sub-views (flare/embed/purchased/...) are local hardware close-
        ups, not whole-model frames, so no icon is drawn for those.
        """
        if not self.show_ucs:
            return
        if self.view == self.VIEW_ELEVATION:
            h_key, h_label = "x", "X"
            h_caption = "+X right rail  /  -X left rail"
            out_caption = "Y (depth, toward/away climber) not shown"
        elif self.view == self.VIEW_SIDE:
            h_key, h_label = "y", "Y"
            h_caption = "+Y away from climber  /  -Y toward climber"
            out_caption = "X (rail-to-rail) not shown"
        else:
            return

        ox, oy = 46.0, 46.0
        length = 26.0

        # Opaque backdrop first: the ladder itself is fitted to the whole
        # widget (_fit) and at narrow pane widths its rails/dimensions run
        # straight under this corner, which left the legend unreadable on
        # top of the drawing. Painting the panel ground behind the whole
        # block (gizmo + captions) keeps it legible at any size, the same
        # thing _paint_dims already does behind each dimension string.
        f_cap = QtGui.QFont("Segoe UI", 7)
        fm_cap = QtGui.QFontMetricsF(f_cap)
        captions = [h_caption, "+Z up  /  -Z down", out_caption]
        ty = oy + length + 18
        text_w = max(fm_cap.horizontalAdvance(t) for t in captions)
        panel_x = ox - 38
        panel_y = oy - length - 16
        panel = QtCore.QRectF(
            panel_x, panel_y,
            max(text_w, length * 2.0 + 30) + 10,
            (ty + 24 + 6) - panel_y)
        p.fillRect(panel, C_BG)

        def _arrow(dx, dy, color, label=None):
            pen = QtGui.QPen(color, 2.2)
            pen.setCosmetic(True)
            p.setPen(pen)
            end = QtCore.QPointF(ox + dx, oy + dy)
            p.drawLine(QtCore.QPointF(ox, oy), end)
            ang = math.atan2(dy, dx)
            for da in (0.5, -0.5):
                a = ang + math.pi + da
                p.drawLine(end, QtCore.QPointF(
                    end.x() + 6.0 * math.cos(a),
                    end.y() + 6.0 * math.sin(a)))
            if label:
                f = QtGui.QFont("Segoe UI", 8, QtGui.QFont.Weight.Bold)
                p.setFont(f)
                p.setPen(QtGui.QPen(color))
                p.drawText(QtCore.QPointF(end.x() + 5, end.y() + 4), label)

        # In-plane horizontal axis (screen +x = model +h_key).
        _arrow(length, 0.0, self._AXIS_COLOR[h_key], h_label)
        _arrow(-length * 0.5, 0.0, self._AXIS_COLOR[h_key])
        # In-plane vertical axis (screen up = model +z).
        _arrow(0.0, -length, self._AXIS_COLOR["z"], "Z")
        _arrow(0.0, length * 0.5, self._AXIS_COLOR["z"])

        p.setFont(f_cap)
        p.setPen(QtGui.QPen(C_LABEL))
        for i, line in enumerate(captions):
            p.drawText(QtCore.QPointF(ox - 34, ty + i * 12), line)

    def _fit(self, xs, ys, pad=54):
        """Compute scale/offset so model extents fit the widget."""
        if not xs or not ys:
            self._scale, self._ox, self._oy = 1.0, 0.0, 0.0
            return
        x0, x1 = min(xs), max(xs)
        y0, y1 = min(ys), max(ys)
        dx = max(x1 - x0, 1e-6)
        dy = max(y1 - y0, 1e-6)
        sx = (self.width() - pad * 2) / dx
        sy = (self.height() - pad * 2) / dy
        self._scale = max(min(sx, sy), 1e-6)
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        self._ox = self.width() / 2.0 - cx * self._scale
        self._oy = self.height() / 2.0 + cy * self._scale

    def _pt(self, x, y):
        """Model (x right, y up) -> device."""
        return QtCore.QPointF(self._ox + x * self._scale,
                              self._oy - y * self._scale)

    def _is_lit(self, key):
        return self.focus_key is not None and key == self.focus_key

    def _steel_pen(self, key=None, w=2.0):
        if key and self._is_lit(key):
            return QtGui.QPen(C_ACCENT, w + 0.8)
        return QtGui.QPen(C_STEEL, w)

    def _dim(self, key, p1, p2, text, offset=0.0, vertical=False):
        self._dims.append(_Dim(key, p1, p2, text, offset, vertical))

    # -- dimension painting ---------------------------------------------
    def _paint_dims(self, p):
        f = QtGui.QFont("Consolas", 8)
        p.setFont(f)
        fm = QtGui.QFontMetricsF(f)
        for d in self._dims:
            lit = self._is_lit(d.key)
            col = C_ACCENT if lit else C_DIM
            txtcol = C_ACCENT if lit else C_DIM_TEXT
            pen = QtGui.QPen(col, 1.6 if lit else 1.0)
            pen.setCosmetic(True)
            p.setPen(pen)

            a = QtCore.QPointF(d.p1)
            b = QtCore.QPointF(d.p2)
            if d.vertical:
                a.setX(a.x() + d.offset)
                b.setX(b.x() + d.offset)
            else:
                a.setY(a.y() + d.offset)
                b.setY(b.y() + d.offset)

            p.drawLine(a, b)
            # witness ticks
            t = 4.0
            if d.vertical:
                p.drawLine(QtCore.QPointF(a.x() - t, a.y()),
                           QtCore.QPointF(a.x() + t, a.y()))
                p.drawLine(QtCore.QPointF(b.x() - t, b.y()),
                           QtCore.QPointF(b.x() + t, b.y()))
                p.drawLine(QtCore.QPointF(d.p1.x(), d.p1.y()), a)
                p.drawLine(QtCore.QPointF(d.p2.x(), d.p2.y()), b)
            else:
                p.drawLine(QtCore.QPointF(a.x(), a.y() - t),
                           QtCore.QPointF(a.x(), a.y() + t))
                p.drawLine(QtCore.QPointF(b.x(), b.y() - t),
                           QtCore.QPointF(b.x(), b.y() + t))
                p.drawLine(QtCore.QPointF(d.p1.x(), d.p1.y()), a)
                p.drawLine(QtCore.QPointF(d.p2.x(), d.p2.y()), b)

            mid = QtCore.QPointF((a.x() + b.x()) / 2.0, (a.y() + b.y()) / 2.0)
            tw = fm.horizontalAdvance(d.text)
            th = fm.height()
            if d.vertical:
                box = QtCore.QRectF(mid.x() - tw / 2 - 3, mid.y() - th / 2,
                                    tw + 6, th)
            else:
                box = QtCore.QRectF(mid.x() - tw / 2 - 3, mid.y() - th / 2,
                                    tw + 6, th)
            p.fillRect(box, C_BG)
            if lit:
                p.setPen(QtGui.QPen(C_ACCENT, 1))
                p.drawRoundedRect(box, 2, 2)
            p.setPen(QtGui.QPen(txtcol))
            p.drawText(box, QtCore.Qt.AlignmentFlag.AlignCenter, d.text)

    # ==================================================================
    #  ELEVATION  (straight-on, looking at the climbing face)
    # ==================================================================
    def _draw_elevation(self, p):
        s = self.state
        w = s.inside_width
        rt = s.rail_fb_width if s.rail_shape == RailShape.FLAT_BAR else 3.0
        rungs = s.rung_elevations()
        bot = s.bottom_elev
        top = s.top_elev

        # True top of the drawing, including the flare rise when present.
        if s.has_flare:
            run = (s.flare_width - s.inside_width) / 2.0
            top_of_draw = (top + s.flare_to_bend + self._flare_rise(run)
                           + s.ext_height)
        elif s.ladder_type == LadderType.STEP_THROUGH:
            top_of_draw = top + s.ext_height
        else:
            top_of_draw = s.effective_top_elev + s.hatch_rail_extension

        half_out = w / 2.0 + rt
        flare_half = (s.flare_width / 2.0 + rt) if s.has_flare else half_out

        self._fit([-flare_half - 8, flare_half + 8],
                  [bot - 10, top_of_draw + 8])

        # ---- support / floor line
        p.setPen(QtGui.QPen(C_SUPPORT, 3))
        p.drawLine(self._pt(-flare_half - 6, bot),
                   self._pt(flare_half + 6, bot))

        # ---- rails
        rails = self._elevation_rail_paths()
        for path, key in rails:
            p.setPen(self._steel_pen(key, 2.2))
            p.drawPath(path)

        # ---- rungs
        for i, e in enumerate(rungs):
            lit = self._is_lit("rung_spacing") or self._is_lit("rung_size")
            p.setPen(QtGui.QPen(C_ACCENT if lit else C_RUNG,
                                3.0 if lit else 2.4))
            p.drawLine(self._pt(-w / 2.0, e), self._pt(w / 2.0, e))

        # ---- gate
        if s.gate_enabled:
            self._draw_gate_elevation(p)

        # ---- intermediate connections
        for e in s.intermediate_elevations():
            lit = self._is_lit("ic_count") or self._is_lit("ic_type")
            p.setPen(QtGui.QPen(C_ACCENT if lit else C_WELD, 2.0))
            for sx in (-1, 1):
                x = sx * (w / 2.0 + rt)
                p.drawLine(self._pt(x, e),
                           self._pt(x + sx * s.ic_leg * 0.5, e))

        # ---- dimensions
        left = self._pt(-flare_half, 0).x()
        right = self._pt(flare_half, 0).x()

        self._dim("top_elev", self._pt(-flare_half, bot),
                  self._pt(-flare_half, top), fmt_len(top - bot),
                  offset=-34, vertical=True)

        if rungs:
            self._dim("first_rung_odd", self._pt(flare_half, bot),
                      self._pt(flare_half, rungs[0]),
                      fmt_len(rungs[0] - bot), offset=30, vertical=True)
            if len(rungs) > 1:
                self._dim("rung_spacing", self._pt(flare_half, rungs[0]),
                          self._pt(flare_half, rungs[1]),
                          fmt_len(rungs[1] - rungs[0]),
                          offset=30, vertical=True)

        self._dim("inside_width", self._pt(-w / 2.0, bot - 4),
                  self._pt(w / 2.0, bot - 4), fmt_len(w), offset=26)

        if s.has_flare:
            run = (s.flare_width - s.inside_width) / 2.0
            fbend = top + s.flare_to_bend
            ftop = fbend + self._flare_rise(run)
            self._dim("flare_width",
                      self._pt(-s.flare_width / 2.0, top_of_draw),
                      self._pt(s.flare_width / 2.0, top_of_draw),
                      fmt_len(s.flare_width), offset=-22)
            self._dim("flare_to_bend", self._pt(flare_half, top),
                      self._pt(flare_half, fbend),
                      fmt_len(s.flare_to_bend), offset=30, vertical=True)
            self._dim("ext_height", self._pt(-flare_half, ftop),
                      self._pt(-flare_half, top_of_draw),
                      fmt_len(s.ext_height), offset=-34, vertical=True)
        elif s.ladder_type == LadderType.STEP_THROUGH:
            self._dim("ext_height", self._pt(-flare_half, top),
                      self._pt(-flare_half, top_of_draw),
                      fmt_len(s.ext_height), offset=-34, vertical=True)

        if s.rungs_above_top and s.ladder_type == LadderType.SIDE_STEP:
            self._label(p, self._pt(0, top + 4),
                        "%d rung(s) above top elev" % s.rungs_above_top,
                        self._is_lit("rungs_above_top"))

    def _flare_rise(self, run):
        """
        Vertical rise of the flared segment for a given horizontal run.

        flare_angle is measured OFF VERTICAL, so rise = run / tan(angle).
        Clamped so a near-zero angle cannot produce an absurd rise that
        swamps the elevation fit.
        """
        s = self.state
        ang = min(max(s.flare_angle, 1.0), 89.0)
        rise = run / math.tan(math.radians(ang))
        return min(rise, max(s.climb_height * 0.5, run * 4.0))

    def _elevation_rail_paths(self):
        """Build left/right rail centre-lines including flare + return."""
        s = self.state
        w = s.inside_width
        rt = s.rail_fb_width if s.rail_shape == RailShape.FLAT_BAR else 3.0
        bot, top = s.bottom_elev + s.rail_setback_bottom, s.top_elev
        out = []

        for sx in (-1.0, 1.0):
            path = QtGui.QPainterPath()
            x_in = sx * (w / 2.0)
            x_out = sx * (w / 2.0 + rt)

            # straight shaft, drawn as a closed rectangle
            shaft_top = top
            if s.has_flare:
                shaft_top = top + s.flare_to_bend

            path.moveTo(self._pt(x_in, bot))
            path.lineTo(self._pt(x_in, shaft_top))
            path.moveTo(self._pt(x_out, bot))
            path.lineTo(self._pt(x_out, shaft_top))
            path.moveTo(self._pt(x_in, bot))
            path.lineTo(self._pt(x_out, bot))

            if s.has_flare:
                fx_in = sx * (s.flare_width / 2.0)
                fx_out = sx * (s.flare_width / 2.0 + rt)
                run = abs(fx_in - x_in)
                rise = self._flare_rise(run)
                ftop = shaft_top + rise
                path.moveTo(self._pt(x_in, shaft_top))
                path.lineTo(self._pt(fx_in, ftop))
                path.moveTo(self._pt(x_out, shaft_top))
                path.lineTo(self._pt(fx_out, ftop))
                ext_top = top + s.ext_height
                path.moveTo(self._pt(fx_in, ftop))
                path.lineTo(self._pt(fx_in, ext_top))
                path.moveTo(self._pt(fx_out, ftop))
                path.lineTo(self._pt(fx_out, ext_top))
                self._cap_extension(path, fx_in, fx_out, ext_top)
            elif s.ladder_type == LadderType.STEP_THROUGH:
                ext_top = top + s.ext_height
                path.moveTo(self._pt(x_in, top))
                path.lineTo(self._pt(x_in, ext_top))
                path.moveTo(self._pt(x_out, top))
                path.lineTo(self._pt(x_out, ext_top))
                self._cap_extension(path, x_in, x_out, ext_top)
            else:
                # Side step: effective_top_elev already accounts for
                # rungs_above_top (extra rungs above top_elev, same
                # spacing) - hatch_rail_extension then extends the rail
                # stub above THAT rung. Reduces to top + stub for roof
                # hatch (and side step with no extra rungs).
                cap_top = s.effective_top_elev + s.hatch_rail_extension
                if cap_top > top:
                    path.moveTo(self._pt(x_in, top))
                    path.lineTo(self._pt(x_in, cap_top))
                    path.moveTo(self._pt(x_out, top))
                    path.lineTo(self._pt(x_out, cap_top))
                path.moveTo(self._pt(x_in, cap_top))
                path.lineTo(self._pt(x_out, cap_top))

            out.append((path, "inside_width"))
        return out

    def _cap_extension(self, path, x_in, x_out, y):
        """Straight cut across the top of the extension - the only style
        LadderBuild actually fabricates (a cosmetic Plain/Rolled/Square
        picker existed here once but never drove any real geometry, so
        it was removed rather than keep promising a choice with no
        effect)."""
        path.moveTo(self._pt(x_in, y))
        path.lineTo(self._pt(x_out, y))

    def _draw_gate_elevation(self, p):
        s = self.state
        lit = (self._is_lit("gate_enabled") or self._is_lit("gate_top_elev")
               or self._is_lit("gate_bottom_elev")
               or self._is_lit("gate_hinge_side"))
        col = C_ACCENT if lit else C_GATE
        p.setPen(QtGui.QPen(col, 2.0, QtCore.Qt.PenStyle.DashLine))
        w = s.gate_width / 2.0
        gb, gt = s.gate_bottom_abs, s.gate_top_abs
        p.drawRect(QtCore.QRectF(self._pt(-w, gt), self._pt(w, gb)))
        # hinge marks - one per gate_hinge_elevations() entry, same
        # bottom-offset/top-offset/evenly-between spacing the real
        # build uses (LadderState.gate_hinge_elevations).
        hs = -1 if s.gate_hinge_side == "Left" else 1
        p.setPen(QtGui.QPen(col, 3.0))
        for y in s.gate_hinge_elevations():
            p.drawLine(self._pt(hs * w, y), self._pt(hs * w * 0.82, y))
        self._dim("gate_top_elev", self._pt(w, gb), self._pt(w, gt),
                  fmt_len(gt - gb), offset=52, vertical=True)

    # ==================================================================
    #  SIDE VIEW  (looking along the rungs; shows standoff + depth)
    # ==================================================================
    def _draw_side(self, p):
        s = self.state
        bot, top = s.bottom_elev, s.top_elev
        rt = s.rail_fb_width if s.rail_shape == RailShape.FLAT_BAR else 3.0
        so = s.standoff
        if s.ladder_type == LadderType.STEP_THROUGH:
            top_draw = top + s.ext_height
        else:
            top_draw = s.effective_top_elev + s.hatch_rail_extension

        self._fit([-so - 10, rt + 12], [bot - 10, top_draw + 8])

        # wall / support face at x = -standoff
        p.setPen(QtGui.QPen(C_SUPPORT, 3))
        p.drawLine(self._pt(-so, bot - 6), self._pt(-so, top_draw + 4))
        p.setPen(QtGui.QPen(C_SUPPORT, 2))
        p.drawLine(self._pt(-so - 6, bot), self._pt(rt + 8, bot))

        # rail seen edge-on
        p.setPen(self._steel_pen("rail_fb_width", 2.2))
        rect = QtCore.QRectF(self._pt(0, top_draw), self._pt(rt, bot))
        p.drawRect(rect)

        # rungs seen end-on
        for e in s.rung_elevations():
            lit = self._is_lit("rung_size")
            p.setPen(QtGui.QPen(C_ACCENT if lit else C_RUNG, 1.6))
            d = s.rung_size
            cx = rt / 2.0
            r = QtCore.QRectF(self._pt(cx - d / 2, e + d / 2),
                              self._pt(cx + d / 2, e - d / 2))
            if s.rung_shape == RungShape.ROUND_BAR:
                p.drawEllipse(r)
            else:
                p.drawRect(r)

        # standoff dimension
        mid = (bot + top) / 2.0
        self._dim("standoff", self._pt(-so, mid), self._pt(rt / 2.0, mid),
                  fmt_len(so), offset=-40)

        # intermediate connection arms
        for e in s.intermediate_elevations():
            lit = self._is_lit("ic_leg") or self._is_lit("ic_count")
            p.setPen(QtGui.QPen(C_ACCENT if lit else C_WELD, 2.2))
            p.drawLine(self._pt(-so, e), self._pt(0, e))
        if s.intermediate_elevations():
            e0 = s.intermediate_elevations()[0]
            self._dim("ic_leg", self._pt(-so, e0), self._pt(0, e0),
                      fmt_len(so), offset=22)

        self._dim("rail_fb_width", self._pt(0, bot - 4),
                  self._pt(rt, bot - 4), fmt_len(rt), offset=26)

    # ==================================================================
    #  DETAILS
    # ==================================================================
    def _label(self, p, pt, text, lit=False):
        p.setFont(QtGui.QFont("Segoe UI", 8))
        p.setPen(QtGui.QPen(C_ACCENT if lit else C_LABEL))
        p.drawText(QtCore.QPointF(pt.x(), pt.y()), text)

    def _draw_detail_flare(self, p):
        """Blow-up of the bend geometry at the top of the ladder."""
        s = self.state
        rt = 2.5
        w = 9.0
        fw = max(s.flare_width * (9.0 / max(s.inside_width, 1e-6)), w + 3)
        bend = 6.0
        rise = 10.0
        ext = 9.0

        self._fit([-fw - 6, fw + 6], [-8, bend + rise + ext + 8])

        for sx in (-1.0, 1.0):
            x_in = sx * w / 2.0
            x_out = sx * (w / 2.0 + rt)
            fx_in = sx * fw / 2.0
            fx_out = sx * (fw / 2.0 + rt)
            p.setPen(self._steel_pen("flare_to_bend", 2.2))
            p.drawLine(self._pt(x_in, 0), self._pt(x_in, bend))
            p.drawLine(self._pt(x_out, 0), self._pt(x_out, bend))
            p.setPen(self._steel_pen("flare_angle", 2.2))
            p.drawLine(self._pt(x_in, bend), self._pt(fx_in, bend + rise))
            p.drawLine(self._pt(x_out, bend), self._pt(fx_out, bend + rise))
            p.setPen(self._steel_pen("ext_height", 2.2))
            p.drawLine(self._pt(fx_in, bend + rise),
                       self._pt(fx_in, bend + rise + ext))
            p.drawLine(self._pt(fx_out, bend + rise),
                       self._pt(fx_out, bend + rise + ext))

            # bend radius arc marker
            if self._is_lit("flare_radius"):
                p.setPen(QtGui.QPen(C_ACCENT, 1.4, QtCore.Qt.PenStyle.DotLine))
                rr = 2.2
                p.drawEllipse(self._pt(x_in, bend), rr * self._scale,
                              rr * self._scale)

        # PI marker on the inside face
        p.setPen(QtGui.QPen(C_ACCENT_2, 1.2, QtCore.Qt.PenStyle.DashLine))
        p.drawLine(self._pt(-w / 2.0 - 4, bend), self._pt(w / 2.0 + 4, bend))
        self._label(p, self._pt(w / 2.0 + 5, bend), "bend PI (inside face)")

        # top rung reference
        p.setPen(QtGui.QPen(C_RUNG, 2.4))
        p.drawLine(self._pt(-w / 2.0, 0), self._pt(w / 2.0, 0))
        self._label(p, self._pt(-w / 2.0 - 30, -3), "top rung")

        self._dim("flare_to_bend", self._pt(-w / 2.0 - rt, 0),
                  self._pt(-w / 2.0 - rt, bend), fmt_len(s.flare_to_bend),
                  offset=-30, vertical=True)
        self._dim("ext_height", self._pt(fw / 2.0 + rt, bend + rise),
                  self._pt(fw / 2.0 + rt, bend + rise + ext),
                  fmt_len(s.ext_height), offset=34, vertical=True)
        self._dim("flare_width", self._pt(-fw / 2.0, bend + rise + ext),
                  self._pt(fw / 2.0, bend + rise + ext),
                  fmt_len(s.flare_width), offset=-24)
        self._dim("flare_radius", self._pt(-w / 2.0, bend),
                  self._pt(-w / 2.0 - 3, bend + 3),
                  "R " + fmt_len(s.flare_radius), offset=0)

        # angle callout
        lit = self._is_lit("flare_angle")
        p.setPen(QtGui.QPen(C_ACCENT if lit else C_DIM_TEXT))
        p.setFont(QtGui.QFont("Consolas", 8))
        p.drawText(self._pt(w / 2.0 + 6, bend + rise * 0.5),
                   "%.1f deg" % s.flare_angle)

    def _draw_detail_embed(self, p):
        """Blow-up of a rung entering the side rail."""
        s = self.state
        t = max(s.rail_thickness, 0.125)
        emb = s.effective_rung_embed
        d = s.rung_size
        hd = s.hole_diameter
        span = t * 6.0

        self._fit([-span, t * 3.0], [-d * 2.4, d * 2.4])

        # rail body (section through)
        p.setPen(self._steel_pen("rail_fb_thick", 2.0))
        p.setBrush(QtGui.QBrush(QtGui.QColor("#333844")))
        p.drawRect(QtCore.QRectF(self._pt(0, d * 2.0),
                                 self._pt(t, -d * 2.0)))
        p.setBrush(QtCore.Qt.BrushStyle.NoBrush)

        # the hole (drawn as a gap in the rail)
        lit_hole = self._is_lit("hole_clearance") or \
            self._is_lit("hole_dia_override")
        p.setPen(QtGui.QPen(C_ACCENT if lit_hole else C_HOLE, 1.4))
        p.setBrush(QtGui.QBrush(C_BG))
        p.drawRect(QtCore.QRectF(self._pt(0, hd / 2.0),
                                 self._pt(emb, -hd / 2.0)))
        p.setBrush(QtCore.Qt.BrushStyle.NoBrush)

        # the rung
        lit_rung = self._is_lit("rung_size") or self._is_lit("rung_shape")
        p.setPen(QtGui.QPen(C_ACCENT if lit_rung else C_RUNG, 2.2))
        p.drawLine(self._pt(-span * 0.9, d / 2.0), self._pt(emb, d / 2.0))
        p.drawLine(self._pt(-span * 0.9, -d / 2.0), self._pt(emb, -d / 2.0))
        p.drawLine(self._pt(emb, d / 2.0), self._pt(emb, -d / 2.0))

        # remaining shelf highlight
        shelf = t - emb
        if shelf > 0:
            p.setPen(QtGui.QPen(C_WELD, 2.0))
            p.drawLine(self._pt(emb, hd / 2.0), self._pt(t, hd / 2.0))
            p.drawLine(self._pt(emb, -hd / 2.0), self._pt(t, -hd / 2.0))
            self._label(p, self._pt(t + 0.4, 0),
                        "plug weld shelf %s" % fmt_len(shelf),
                        self._is_lit("rung_embed"))

        self._dim("rung_embed", self._pt(0, -d * 1.5),
                  self._pt(emb, -d * 1.5), fmt_len(emb), offset=22)
        self._dim("rail_fb_thick", self._pt(0, d * 1.6),
                  self._pt(t, d * 1.6), fmt_len(t), offset=-20)
        self._dim("hole_clearance", self._pt(emb * 0.5, -hd / 2.0),
                  self._pt(emb * 0.5, hd / 2.0),
                  "dia " + fmt_len(hd), offset=-46, vertical=True)

        note = ("punch inside face only"
                if s.is_closed_shape else "punch through")
        self._label(p, self._pt(-span * 0.9, d * 2.0), note)

    def _draw_detail_purchased(self, p):
        """Cross-section of the inverted-U purchased rung."""
        s = self.state
        w = max(s.pr_width, 0.25)
        h = max(s.pr_height, 0.125)
        t = max(s.pr_thick, 0.03125)

        self._fit([-w * 0.9, w * 0.9], [-h * 1.4, h * 1.6])

        path = QtGui.QPainterPath()
        path.moveTo(self._pt(-w / 2.0, -h))
        path.lineTo(self._pt(-w / 2.0, h - t))
        path.lineTo(self._pt(w / 2.0, h - t))
        path.lineTo(self._pt(w / 2.0, -h))
        path.lineTo(self._pt(w / 2.0 - t, -h))
        path.lineTo(self._pt(w / 2.0 - t, h - 2 * t))
        path.lineTo(self._pt(-w / 2.0 + t, h - 2 * t))
        path.lineTo(self._pt(-w / 2.0 + t, -h))
        path.closeSubpath()

        lit = any(self._is_lit(k) for k in
                  ("pr_width", "pr_height", "pr_thick", "pr_radius"))
        p.setPen(QtGui.QPen(C_ACCENT if lit else C_STEEL, 2.0))
        p.setBrush(QtGui.QBrush(QtGui.QColor("#333844")))
        p.drawPath(path)
        p.setBrush(QtCore.Qt.BrushStyle.NoBrush)

        self._dim("pr_width", self._pt(-w / 2.0, -h), self._pt(w / 2.0, -h),
                  fmt_len(w), offset=30)
        self._dim("pr_height", self._pt(w / 2.0, -h), self._pt(w / 2.0, h - t),
                  fmt_len(h), offset=34, vertical=True)
        self._dim("pr_thick", self._pt(-w / 2.0, h - t),
                  self._pt(-w / 2.0 + t, h - t), fmt_len(t), offset=-26)
        self._label(p, self._pt(-w * 0.85, h * 1.35),
                    "bent plate layout  ~  R %s" % fmt_len(s.pr_radius),
                    self._is_lit("pr_radius"))
        if s.pr_description:
            self._label(p, self._pt(-w * 0.85, -h * 1.25),
                        'description: "%s"' % s.pr_description)

    def _draw_detail_cap(self, p):
        """Rail end: cap plate and/or round over."""
        s = self.state
        w = 3.0
        t = 0.375
        L = 6.0
        self._fit([-w, w + 4], [-2, L + 4])

        p.setPen(self._steel_pen("rail_fb_width", 2.2))
        p.drawRect(QtCore.QRectF(self._pt(-w / 2, L), self._pt(w / 2, 0)))

        if s.round_top:
            r = s.round_top_radius or w / 2.0
            lit = self._is_lit("round_top") or self._is_lit("round_top_radius")
            p.setPen(QtGui.QPen(C_ACCENT if lit else C_STEEL_LIT, 2.2))
            rect = QtCore.QRectF(self._pt(-w / 2, L + w / 2),
                                 self._pt(w / 2, L - w / 2))
            p.drawArc(rect, 0, 180 * 16)
            self._label(p, self._pt(w / 2 + 0.5, L + 1),
                        "round top R %s" % fmt_len(r), lit)

        if s.cap_ends:
            lit = (self._is_lit("cap_thick") or self._is_lit("cap_ends")
                   or self._is_lit("cap_overhang"))
            oh = s.cap_overhang
            p.setPen(QtGui.QPen(C_ACCENT if lit else C_ACCENT_2, 2.0))
            p.drawRect(QtCore.QRectF(
                self._pt(-w / 2 - oh, L + s.cap_thick),
                self._pt(w / 2 + oh, L)))
            self._dim("cap_thick", self._pt(w / 2 + oh, L),
                      self._pt(w / 2 + oh, L + s.cap_thick),
                      fmt_len(s.cap_thick), offset=30, vertical=True)
            if oh:
                self._dim("cap_overhang", self._pt(w / 2, L + s.cap_thick),
                          self._pt(w / 2 + oh, L + s.cap_thick),
                          fmt_len(oh), offset=-20)

    def _draw_detail_bottom(self, p):
        """Bottom connection blow-up."""
        s = self.state
        self._fit([-14, 10], [-4, 18])
        bc = s.bottom_conn

        p.setPen(QtGui.QPen(C_SUPPORT, 3))
        p.drawLine(self._pt(-12, 0), self._pt(8, 0))

        if bc == BottomConnection.NONE:
            p.setPen(self._steel_pen("bottom_conn", 2.2))
            p.drawLine(self._pt(0, 0), self._pt(0, 16))
            self._label(p, self._pt(1, 8), "no bottom connection")
            return

        if bc == BottomConnection.BASE_PLATE:
            # Side view (this detail's x = depth/front-back, y = up),
            # so only length/thickness/offset are true to scale here -
            # width in/out and the two holes are across-the-ladder
            # (perpendicular to this view) and called out as text.
            p.setPen(self._steel_pen("bc_ang_size", 2.2))
            p.drawLine(self._pt(0, 0), self._pt(0, 16))
            L, th, off = s.bp_length, s.bp_thick, s.bp_center_offset
            x1, x2 = off - L / 2.0, off + L / 2.0
            p.setPen(self._steel_pen("bp_length", 2.4))
            p.drawLine(self._pt(x1, 0.0), self._pt(x2, 0.0))
            p.drawLine(self._pt(x1, -th), self._pt(x2, -th))
            p.drawLine(self._pt(x1, 0.0), self._pt(x1, -th))
            p.drawLine(self._pt(x2, 0.0), self._pt(x2, -th))
            self._dim("bp_length", self._pt(x1, -th), self._pt(x2, -th),
                      fmt_len(L), offset=-24)
            self._dim("bp_thick", self._pt(x2, 0.0), self._pt(x2, -th),
                      fmt_len(th), offset=20, vertical=True)
            if abs(off) > 1e-6:
                self._label(p, self._pt(off, 1.0),
                            "offset %s" % fmt_len(off),
                            self._is_lit("bp_center_offset"))
            lit_h = (self._is_lit("bp_hole_dia") or self._is_lit("bp_edge_in")
                     or self._is_lit("bp_edge_out"))
            p.setPen(QtGui.QPen(C_ACCENT if lit_h else C_DIM, 1.6))
            r = s.bp_hole_dia / 2.0
            p.drawEllipse(self._pt(off, -th / 2.0), r * self._scale,
                          r * self._scale)
            lit_w = (self._is_lit("bp_width_in") or self._is_lit("bp_width_out"))
            p.setPen(QtGui.QPen(C_ACCENT if lit_w else C_DIM_TEXT))
            p.setFont(QtGui.QFont("Consolas", 8))
            p.drawText(self._pt(x2 + 0.6, -th / 2.0),
                       "width in %s / out %s, holes dia %s @ edge %s/%s"
                       % (fmt_len(s.bp_width_in), fmt_len(s.bp_width_out),
                          fmt_len(s.bp_hole_dia), fmt_len(s.bp_edge_in),
                          fmt_len(s.bp_edge_out)))
            self._label(p, self._pt(-13, 17), bc)
            return

        # clip angle variants
        L = s.bc_ang_length
        p.setPen(self._steel_pen("bc_ang_size", 2.2))
        p.drawLine(self._pt(0, 0), self._pt(0, 16))
        p.setPen(QtGui.QPen(C_ACCENT_2, 2.4))
        p.drawLine(self._pt(-L, 0.4), self._pt(0, 0.4))
        p.drawLine(self._pt(-L, 0.4), self._pt(-L, L * 0.6))

        # bolts
        lit_b = self._is_lit("bc_bolt_qty") or self._is_lit("bc_bolt_dia")
        p.setPen(QtGui.QPen(C_ACCENT if lit_b else C_DIM, 1.6))
        n = max(1, s.bc_bolt_qty)
        gage = s.bc_vertical_gage
        for i in range(n):
            y = 2.0 + i * gage
            r = s.bc_bolt_dia / 2.0
            p.drawEllipse(self._pt(-L, y), r * self._scale, r * self._scale)
        if n > 1:
            self._dim("bc_bolt_qty", self._pt(-L, 2.0),
                      self._pt(-L, 2.0 + gage), "gage %s" % fmt_len(gage),
                      offset=-28, vertical=True)
        self._dim("bc_ang_length", self._pt(-L, 0.4), self._pt(0, 0.4),
                  fmt_len(L), offset=28)

        if bc == BottomConnection.BOLT_WELD_ANGLE:
            p.setPen(QtGui.QPen(C_WELD, 2.6))
            p.drawLine(self._pt(0, 0.4), self._pt(0, 3.5))
            self._label(p, self._pt(0.6, 2.0),
                        "weld %s" % fmt_len(s.bc_weld_size),
                        self._is_lit("bc_weld_size"))
        lit_o = (self._is_lit("bc_osl_side")
                 or self._is_lit("bc_leg_orientation"))
        p.setPen(QtGui.QPen(C_ACCENT if lit_o else C_DIM_TEXT))
        p.setFont(QtGui.QFont("Consolas", 8))
        p.drawText(self._pt(-13, 15.5), "%s, %s" % (s.bc_osl_side,
                                                     s.bc_leg_orientation))
        self._label(p, self._pt(-13, 17), bc)

    def _draw_detail_inter(self, p):
        """
        Intermediate standoff connection blow-up, drawn in PLAN - both
        legs of the bent standoff are horizontal, so an elevation view
        cannot show the outstanding leg at all (it would point straight
        at the viewer). Drawing X is depth (0 at the rung CL, -standoff
        at the support face) and drawing Y is across the ladder, 0 at
        the rail and positive OUTBOARD, away from the ladder centerline
        - the direction the OSL turns.
        """
        s = self.state
        so = s.standoff
        osl = s.ic_osl if s.ic_is_bent else 0.0
        self._fit([-so - 5, 6], [-6, osl + 6])

        # Support face, then the rail it stands off from.
        p.setPen(QtGui.QPen(C_SUPPORT, 3))
        p.drawLine(self._pt(-so, -5), self._pt(-so, osl + 5))

        p.setPen(self._steel_pen("inside_width", 2.4))
        p.drawLine(self._pt(0, -4), self._pt(0, 4))

        # Rail leg spans rail -> support; the OSL turns outboard at the
        # support face. Flat Plate is that first run only, no turn.
        lit = self._is_lit("ic_type") or self._is_lit("standoff")
        p.setPen(QtGui.QPen(C_ACCENT if lit else C_ACCENT_2, 2.4))
        p.drawLine(self._pt(0, 0), self._pt(-so, 0))
        if s.ic_is_bent:
            p.drawLine(self._pt(-so, 0), self._pt(-so, osl))

        lit_b = self._is_lit("ic_gage") or self._is_lit("ic_bolt_dia")
        p.setPen(QtGui.QPen(C_ACCENT if lit_b else C_DIM, 1.6))
        r = s.ic_bolt_dia / 2.0
        if s.ic_osl_bolted:
            p.drawEllipse(self._pt(-so, s.ic_gage), r * self._scale,
                          r * self._scale)

        self._dim("standoff", self._pt(-so, -3.5), self._pt(0, -3.5),
                  fmt_len(so), offset=26)
        if s.ic_is_bent:
            self._dim("ic_osl", self._pt(-so, 0), self._pt(-so, osl),
                      fmt_len(osl), offset=-26, vertical=True)
        if s.ic_osl_bolted:
            self._dim("ic_gage", self._pt(-so, 0), self._pt(-so, s.ic_gage),
                      fmt_len(s.ic_gage), offset=26, vertical=True)
        self._label(p, self._pt(-so, osl + 5.5), s.ic_type,
                    self._is_lit("ic_type"))

    def _draw_detail_return(self, p):
        """Return leg coming back down to the top level."""
        s = self.state
        rw = s.return_width
        setb = s.return_setback
        h = 14.0
        self._fit([-4, rw + 8], [-4, h + 6])

        p.setPen(QtGui.QPen(C_SUPPORT, 3))
        p.drawLine(self._pt(-3, 0), self._pt(rw + 6, 0))

        lit = self._is_lit("return_width")
        p.setPen(QtGui.QPen(C_ACCENT if lit else C_STEEL, 2.4))
        path = QtGui.QPainterPath()
        path.moveTo(self._pt(0, 0))
        path.lineTo(self._pt(0, h - 3))
        path.lineTo(self._pt(0, h))
        path.lineTo(self._pt(rw, h))
        path.lineTo(self._pt(rw, setb))
        p.drawPath(path)

        self._dim("return_width", self._pt(0, h + 2), self._pt(rw, h + 2),
                  fmt_len(rw), offset=-22)
        self._dim("return_setback", self._pt(rw, 0), self._pt(rw, setb),
                  fmt_len(setb), offset=30, vertical=True)
        self._label(p, self._pt(-3, -2.5), s.return_conn,
                    self._is_lit("return_conn"))
