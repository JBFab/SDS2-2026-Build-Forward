"""
=============================================================================
JBSimpleLadder
Copyright (c) 2026 Jason Bondioli

LICENSE AND TERMS OF USE:
Permission is hereby granted to use, copy, modify, and freely distribute 
this software, subject to the following conditions:

1. ATTRIBUTION: Any distribution of this software, whether in its original 
   or modified form, must clearly credit the original author, Jason Bondioli.

2. NO RESALE: This software and any of its derivatives may not be sold or 
   packaged for commercial gain by anyone other than the original author.

3. DISCLAIMER OF LIABILITY: THE SOFTWARE IS PROVIDED "AS IS", WITHOUT 
   WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. In no event shall the author 
   be held responsible for any mishaps, lost work, data loss, or other 
   damages arising from the use of this software or its derivatives. 
=============================================================================
"""

"""
=============================================================================
 JB Simple Ladder - Job Defaults  (SDS2 macro)
=============================================================================
 Run this to choose what a NEW ladder starts out as in this job.

 It opens the normal ladder editor loaded with the job's current
 defaults; pressing "Save Defaults" stores them, and every ladder placed
 afterwards opens pre-filled with them. Ladders already in the job are
 not touched.

 Placement values - elevations, rotation, pick mode, the intermediate
 elevation list - are not saved as defaults, since those describe where
 one particular ladder is rather than how ladders in this job should be
 built.

 To run it: Home > Macros (or the macro toolbar), pick this file. It can
 also be copied into the shared macro folder alongside the other JBTools
 macros if you want it on the menu permanently.

 This is deliberately a macro rather than an entry in SDS2's Plugin
 Setup menu - see LadderDefaults.py for why.
=============================================================================
"""

import os
import sys

# The defaults module lives next to this file, in the plugin folder. Add
# that folder to the path so this macro works no matter where it is run
# from.
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)


def main():
    try:
        from LadderDefaults import edit_defaults
    except Exception as exc:
        _warn("JB Simple Ladder: could not load the defaults module:\n%s"
              % exc)
        return

    try:
        saved = edit_defaults()
    except Exception as exc:
        _warn("JB Simple Ladder: the defaults editor failed:\n%s" % exc)
        return

    if saved:
        _warn("JB Simple Ladder: job defaults saved. New ladders placed in "
              "this job will start from these settings.")


def _warn(msg):
    """Tell the user through SDS2 when it is available, otherwise print -
    so the macro is still runnable outside SDS2 for testing."""
    try:
        import param
        param.Warning(msg)
    except Exception:
        print(msg)


main()
