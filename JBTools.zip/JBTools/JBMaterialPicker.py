"""
=============================================================================
 JB Material Picker  —  PySide6 replacement for SDS2's native ChooseMtrl
=============================================================================
"""

import os
import re
import struct
import sys
import json
import ctypes
import math

# ---------------------------------------------------------------------------
# Shape category definitions
# ---------------------------------------------------------------------------
CATEGORY_PREFIXES = [
    ("RECENT", "⭐ Recent Selections"),
    ("HSS_REC", "HSS Rectangular"),
    ("HSS_RND", "HSS Round"),
    ("PIPE", "Pipe"),
    ("2L",   "Double Angle"),
    ("WT",   "WT (Tee from W)"),
    ("MT",   "MT (Tee from M)"),
    ("ST",   "ST (Tee from S)"),
    ("MC",   "Misc Channel"),
    ("HP",   "H-Pile"),
    ("PL",   "Plate"),
    ("W",    "Wide Flange"),
    ("M",    "Misc Beam"),
    ("S",    "S Beam"),
    ("C",    "Channel"),
    ("L",    "Angle"),
]

SDS2_TYPE_TO_PREFIXES = {
    "W Flange":  ("W",),
    "Wide Flange": ("W",),
    "Channel":   ("C", "MC"),
    "Angle":     ("L",),
    "Tube":      ("HSS_REC", "HSS_RND"),
    "Pipe":      ("PIPE",),
    "Plate":     ("PL",),
    "Tee":       ("WT", "MT", "ST"),
}

def categorize(name):
    upper_name = name.upper()
    if upper_name.startswith("HSS"):
        if upper_name.count("X") >= 2:
            return "HSS_REC"
        return "HSS_RND"

    for pfx, _label in CATEGORY_PREFIXES[1:]: 
        if upper_name.startswith(pfx):
            return pfx
    return "?"

# ---------------------------------------------------------------------------
# Recent Sections Manager
# ---------------------------------------------------------------------------
class RecentManager:
    def __init__(self):
        appdata = os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))
        self.filepath = os.path.join(appdata, "JB_MaterialPicker", "recents.json")
        self.recents = []
        self.load()

    def load(self):
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, "r") as f:
                    self.recents = json.load(f)
            except Exception:
                self.recents = []

    def add(self, name):
        if name in self.recents:
            self.recents.remove(name)
        self.recents.insert(0, name)
        self.recents = self.recents[:15]
        try:
            os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
            with open(self.filepath, "w") as f:
                json.dump(self.recents, f)
        except Exception:
            pass

# ---------------------------------------------------------------------------
# Material file parser
# ---------------------------------------------------------------------------
class Section(object):
    __slots__ = ("name", "category", "depth", "width", "tf", "tw", "weight", "raw_data")
    def __init__(self, name, category, depth=0.0, width=0.0, tf=0.0, tw=0.0, weight=0.0, raw_data=None):
        self.name = name
        self.category = category
        self.depth = depth
        self.width = width
        self.tf = tf
        self.tw = tw
        self.weight = weight
        self.raw_data = raw_data or []

class MaterialFile(object):
    RECORD_MARKER = b"\x17\x00\x00\x00"
    def __init__(self, path=None):
        self.path = path
        self.sections = []
        self.error = None
        if path:
            self.load(path)

    @staticmethod
    def find_job_mtrl(job_name=None, plugin_dir=None):
        # FIX: If no job name is passed, ask SDS2 for the active job.
        if not job_name:
            try:
                from job import Job
                job_name = Job().name()
            except Exception:
                pass
                
        candidates = []
        base_dir = plugin_dir or os.path.dirname(os.path.abspath(__file__))
        parts = base_dir.replace("\\", "/").split("/")
        sds2_root = None
        for i, p in enumerate(parts):
            if p.upper().startswith("SDS2_"):
                sds2_root = "/".join(parts[: i + 1])
                break
                
        if sds2_root and job_name:
            candidates.append(os.path.join(sds2_root, "jobs", job_name, "main", "job_mtrl"))

        if job_name:
            for pd in (r"C:\ProgramData", r"D:\ProgramData"):
                if not os.path.isdir(pd): continue
                try:
                    for entry in os.listdir(pd):
                        if entry.upper().startswith("SDS2_"):
                            candidates.append(os.path.join(pd, entry, "jobs", job_name, "main", "job_mtrl"))
                except Exception:
                    pass
                    
        for c in candidates:
            if os.path.isfile(c): 
                return c
                
        return None

    def load(self, path):
        self.sections = []
        self.error = None
        try:
            with open(path, "rb") as f: data = f.read()
        except Exception as e:
            self.error = str(e); return False
        try:
            self.sections = self._parse(data)
            return bool(self.sections)
        except Exception as e:
            self.error = str(e); return False

    def _parse(self, data):
        out = []
        n = len(data)
        i = 0
        shape_re = re.compile(r"^(W|M|S|HP|C|MC|L|WT|MT|ST|HSS|PIPE|PL|2L)")
        while i < n - 4:
            if data[i:i+4] == self.RECORD_MARKER:
                name_start = i + 4
                name_end = data.find(b"\x00", name_start)
                if name_end > name_start:
                    raw = data[name_start:name_end]
                    if 2 <= len(raw) <= 25 and all(0x20 <= b <= 0x7E for b in raw):
                        try: name = raw.decode("ascii")
                        except: name = None
                        if name and shape_re.match(name):
                            props, raw_vals = self._read_props(data, name_end, n, name)
                            if props:
                                out.append(Section(name, categorize(name),
                                    props.get("depth", 0.0), props.get("width", 0.0),
                                    props.get("tf", 0.0), props.get("tw", 0.0), props.get("weight", 0.0),
                                    raw_data=raw_vals))
            i += 1
        return out

    @staticmethod
    def _read_props(data, name_end, n, name_str):
        scan_limit = min(name_end + 120, n - 192)
        for scan in range(name_end, scan_limit):
            if data[scan:scan+4] == MaterialFile.RECORD_MARKER:
                break
                
            try: 
                first = struct.unpack_from("<d", data, scan)[0]
            except: 
                continue
                
            if 0.4 <= first <= 70.0:
                try: 
                    vals = struct.unpack_from("<24d", data, scan)
                except: 
                    continue
                    
                if vals[1] >= 0.0 and vals[3] > 0.0 and vals[5] > 0.0:
                    nums = re.findall(r'\d*\.\d+|\d+', name_str)
                    if nums:
                        expected_d = float(nums[0])
                        if expected_d > 0 and abs(first - expected_d) / expected_d > 0.6:
                            continue 
                            
                    props = {"depth": vals[0], "width": vals[1], "tf": vals[2], "tw": vals[3], "weight": vals[5]}
                    return props, vals
        return {}, []

    def by_category(self, prefixes=None):
        if not prefixes: return list(self.sections)
        wanted = set(p.upper() for p in prefixes)
        return [s for s in self.sections if s.category.upper() in wanted]

def fuzzy_score(query, name):
    if not query: return 1
    q = query.upper()
    q = re.sub(r'\bBY\b', 'X', q)
    q = re.sub(r'\bAT\b', 'X', q)
    q = q.replace(" ", "")
    nm = name.upper().replace(" ", "")
    
    if q == nm: return 1000
    if nm.startswith(q): return 900 - len(nm)
    if q in nm: return 700 - len(nm)
    
    q2, n2 = q.replace("X", ""), nm.replace("X", "")
    if n2.startswith(q2): return 600 - len(nm)
    if q2 in n2: return 500 - len(nm)
    
    pos = 0
    for ch in q2:
        pos = n2.find(ch, pos)
        if pos < 0: return 0
        pos += 1
    return 300 - len(nm)


# ---------------------------------------------------------------------------
# Theme Colors for Coordination
# ---------------------------------------------------------------------------
C_DEPTH = "#3399ff"   # Blue
C_WIDTH = "#55cc55"   # Green
C_THICK = "#ffaa00"   # Orange
C_ID    = "#cc55ff"   # Purple
C_K     = "#ffff55"   # Yellow
C_T     = "#00ffff"   # Cyan

# ---------------------------------------------------------------------------
# The PySide6 GUI Components
# ---------------------------------------------------------------------------
def _build_dialog_classes():
    from PySide6 import QtCore, QtGui, QtWidgets

    class CrossSectionWidget(QtWidgets.QWidget):
        def __init__(self, parent=None):
            super().__init__(parent)
            self.setMinimumHeight(220)
            self.section = None
            self.k_val = 0.0

        def set_section(self, section, k_val=0.0):
            self.section = section
            self.k_val = k_val
            self.update()

        def paintEvent(self, event):
            if not self.section: return
            s = self.section
            
            painter = QtGui.QPainter(self)
            painter.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
            
            w, h = self.width(), self.height()
            cx, cy = w / 2 + 15, h / 2 + 5 
            
            aspect = max(0.2, min(4.0, s.width / s.depth)) if s.depth > 0 else 0.66
            max_w, max_h = 100, 120
            
            if aspect > (max_w / max_h):
                sw = max_w
                sh = max_w / aspect
            else:
                sh = max_h
                sw = max_h * aspect

            thick_boost = 1.8
            tf = max(6.0, (s.tf / s.depth) * sh * thick_boost) if s.depth else 8.0
            tw = max(6.0, (s.tw / s.width) * sw * thick_boost) if s.width else 8.0
            tf = min(tf, sh / 3)
            tw = min(tw, sw / 3)
            
            k_draw = (self.k_val / s.depth) * sh if (s.depth and self.k_val) else tf * 1.5
            r = max(2.0, k_draw - tf)

            cat = s.category
            path = QtGui.QPainterPath()

            # --- Construct Polygons with Perfect Radii ---
            if cat in ("W", "M", "S", "HP"):
                path.moveTo(cx - sw/2, cy - sh/2)
                path.lineTo(cx + sw/2, cy - sh/2)
                path.lineTo(cx + sw/2, cy - sh/2 + tf)
                path.lineTo(cx + tw/2 + r, cy - sh/2 + tf)
                path.arcTo(cx + tw/2, cy - sh/2 + tf, 2*r, 2*r, 90, 90) 
                path.lineTo(cx + tw/2, cy + sh/2 - tf - r)
                path.arcTo(cx + tw/2, cy + sh/2 - tf - 2*r, 2*r, 2*r, 180, 90) 
                path.lineTo(cx + sw/2, cy + sh/2 - tf)
                path.lineTo(cx + sw/2, cy + sh/2)
                path.lineTo(cx - sw/2, cy + sh/2)
                path.lineTo(cx - sw/2, cy + sh/2 - tf)
                path.lineTo(cx - tw/2 - r, cy + sh/2 - tf)
                path.arcTo(cx - tw/2 - 2*r, cy + sh/2 - tf - 2*r, 2*r, 2*r, 270, 90) 
                path.lineTo(cx - tw/2, cy - sh/2 + tf + r)
                path.arcTo(cx - tw/2 - 2*r, cy - sh/2 + tf, 2*r, 2*r, 0, 90) 
                path.lineTo(cx - sw/2, cy - sh/2 + tf)
                path.closeSubpath()

            elif cat in ("C", "MC"):
                path.moveTo(cx - sw/2, cy - sh/2)
                path.lineTo(cx + sw/2, cy - sh/2)
                path.lineTo(cx + sw/2, cy - sh/2 + tf)
                path.lineTo(cx - sw/2 + tw + r, cy - sh/2 + tf)
                path.arcTo(cx - sw/2 + tw, cy - sh/2 + tf, 2*r, 2*r, 90, 90)
                path.lineTo(cx - sw/2 + tw, cy + sh/2 - tf - r)
                path.arcTo(cx - sw/2 + tw, cy + sh/2 - tf - 2*r, 2*r, 2*r, 180, 90)
                path.lineTo(cx + sw/2, cy + sh/2 - tf)
                path.lineTo(cx + sw/2, cy + sh/2)
                path.lineTo(cx - sw/2, cy + sh/2)
                path.closeSubpath()

            elif cat == "L":
                r_angle = tw 
                path.moveTo(cx - sw/2, cy - sh/2)
                path.lineTo(cx - sw/2 + tw, cy - sh/2)
                path.lineTo(cx - sw/2 + tw, cy + sh/2 - tf - r_angle)
                path.arcTo(cx - sw/2 + tw, cy + sh/2 - tf - 2*r_angle, 2*r_angle, 2*r_angle, 180, 90)
                path.lineTo(cx + sw/2, cy + sh/2 - tf)
                path.lineTo(cx + sw/2, cy + sh/2)
                path.lineTo(cx - sw/2, cy + sh/2) 
                path.closeSubpath()

            elif cat in ("WT", "MT", "ST"):
                path.moveTo(cx - sw/2, cy - sh/2)
                path.lineTo(cx + sw/2, cy - sh/2)
                path.lineTo(cx + sw/2, cy - sh/2 + tf)
                path.lineTo(cx + tw/2 + r, cy - sh/2 + tf)
                path.arcTo(cx + tw/2, cy - sh/2 + tf, 2*r, 2*r, 90, 90)
                path.lineTo(cx + tw/2, cy + sh/2)
                path.lineTo(cx - tw/2, cy + sh/2)
                path.lineTo(cx - tw/2, cy - sh/2 + tf + r)
                path.arcTo(cx - tw/2 - 2*r, cy - sh/2 + tf, 2*r, 2*r, 0, 90)
                path.lineTo(cx - sw/2, cy - sh/2 + tf)
                path.closeSubpath()

            elif cat == "HSS_REC":
                outer = QtGui.QPainterPath()
                outer.addRoundedRect(cx - sw/2, cy - sh/2, sw, sh, 2*tw, 2*tw)
                inner = QtGui.QPainterPath()
                inner.addRoundedRect(cx - sw/2 + tw, cy - sh/2 + tf, sw - 2*tw, sh - 2*tf, tw, tw)
                path = outer.subtracted(inner)
            
            elif cat in ("PIPE", "HSS_RND"):
                outer = QtGui.QPainterPath()
                outer.addEllipse(QtCore.QPointF(cx, cy), sw/2, sh/2)
                inner = QtGui.QPainterPath()
                inner.addEllipse(QtCore.QPointF(cx, cy), sw/2 - tw, sh/2 - tf)
                path = outer.subtracted(inner)

            # Paint Shape
            hatch_brush = QtGui.QBrush(QtGui.QColor("#225588"), QtCore.Qt.BrushStyle.FDiagPattern)
            outline_pen = QtGui.QPen(QtGui.QColor("#4499ff"), 2)
            painter.setBrush(hatch_brush)
            painter.setPen(outline_pen)
            painter.drawPath(path)

            # --- Dimension Helpers ---
            def draw_dim(x1, y1, x2, y2, label, color, text_offset_x=0, text_offset_y=0, rotate=False):
                painter.setPen(QtGui.QPen(QtGui.QColor("#888888"), 1))
                painter.drawLine(int(x1), int(y1), int(x2), int(y2))
                t = 4
                painter.drawLine(int(x1 - t), int(y1 + t), int(x1 + t), int(y1 - t))
                painter.drawLine(int(x2 - t), int(y2 + t), int(x2 + t), int(y2 - t))
                
                painter.setPen(QtGui.QColor(color))
                painter.setFont(QtGui.QFont("Segoe UI", 9, QtGui.QFont.Weight.Bold))
                mx, my = (x1 + x2) / 2, (y1 + y2) / 2
                
                if rotate:
                    painter.translate(mx, my)
                    painter.rotate(-90)
                    painter.drawText(int(text_offset_x - 5), int(text_offset_y + 4), label)
                    painter.rotate(90)
                    painter.translate(-mx, -my)
                else:
                    painter.drawText(int(mx + text_offset_x - 5), int(my + text_offset_y + 4), label)

            def draw_leader(cx, cy, radius, label, color, angle_deg, text_offset):
                rad = math.radians(angle_deg)
                px, py = cx + radius * math.cos(rad), cy + radius * math.sin(rad)
                painter.setPen(QtGui.QPen(QtGui.QColor("#888888"), 1))
                painter.drawLine(int(cx), int(cy), int(px), int(py))
                painter.setPen(QtGui.QColor(color))
                painter.setFont(QtGui.QFont("Segoe UI", 9, QtGui.QFont.Weight.Bold))
                painter.drawText(int(px + text_offset[0]), int(py + text_offset[1]), label)

            ext_pen = QtGui.QPen(QtGui.QColor("#555555"), 1, QtCore.Qt.PenStyle.DashLine)
            
            # --- Draw Annotations ---
            if cat in ("PIPE", "HSS_RND"):
                draw_leader(cx, cy, sw/2, "OD", C_DEPTH, -45, (5, -5))
                draw_leader(cx, cy, sw/2 - tw, "ID", C_ID, 45, (5, 12))
                draw_leader(cx, cy, sw/2 - tw/2, "t", C_THICK, 0, (10, 4))
            else:
                # Vertical d 
                d_x = cx - sw/2 - 35
                painter.setPen(ext_pen)
                painter.drawLine(int(cx - sw/2 - 2), int(cy - sh/2), int(d_x - 5), int(cy - sh/2))
                painter.drawLine(int(cx - sw/2 - 2), int(cy + sh/2), int(d_x - 5), int(cy + sh/2))
                draw_dim(d_x, cy - sh/2, d_x, cy + sh/2, "d", C_DEPTH, text_offset_y=-5, rotate=True)

                # Horizontal bf/b 
                b_y = cy - sh/2 - 25
                painter.setPen(ext_pen)
                painter.drawLine(int(cx - sw/2), int(cy - sh/2 - 2), int(cx - sw/2), int(b_y - 5))
                painter.drawLine(int(cx + sw/2), int(cy - sh/2 - 2), int(cx + sw/2), int(b_y - 5))
                bf_label = "b" if cat in ("L", "HSS_REC") else "bf"
                draw_dim(cx - sw/2, b_y, cx + sw/2, b_y, bf_label, C_WIDTH, text_offset_y=-8)
                
                # I-Shapes & Channels
                if cat in ("W", "M", "S", "HP", "C", "MC"):
                    # tf 
                    tf_x = cx + sw/2 + 20
                    painter.setPen(ext_pen)
                    painter.drawLine(int(cx + sw/2 + 2), int(cy - sh/2), int(tf_x + 5), int(cy - sh/2))
                    painter.drawLine(int(cx + sw/2 + 2), int(cy - sh/2 + tf), int(tf_x + 5), int(cy - sh/2 + tf))
                    draw_dim(tf_x, cy - sh/2, tf_x, cy - sh/2 + tf, "tf", C_THICK, text_offset_y=-5, rotate=True)
                    
                    # tw 
                    tw_y = cy + sh/2 + 25
                    painter.setPen(ext_pen)
                    painter.drawLine(int(cx - tw/2), int(cy + sh/2 + 2), int(cx - tw/2), int(tw_y + 5))
                    painter.drawLine(int(cx + tw/2), int(cy + sh/2 + 2), int(cx + tw/2), int(tw_y + 5))
                    draw_dim(cx - tw/2, tw_y, cx + tw/2, tw_y, "tw", C_THICK, text_offset_y=12)

                    # k & T
                    if self.k_val > 0:
                        k_x = cx - sw/2 - 15
                        draw_dim(k_x, cy - sh/2, k_x, cy - sh/2 + k_draw, "k", C_K, text_offset_y=-5, rotate=True)
                        if cat not in ("C", "MC"): 
                            draw_dim(k_x, cy + sh/2 - k_draw, k_x, cy + sh/2, "k", C_K, text_offset_y=-5, rotate=True)
                        else:
                            draw_dim(k_x, cy + sh/2 - k_draw, k_x, cy + sh/2, "k", C_K, text_offset_y=-5, rotate=True)
                        draw_dim(k_x, cy - sh/2 + k_draw, k_x, cy + sh/2 - k_draw, "T", C_T, text_offset_y=-5, rotate=True)

                # Tees
                elif cat in ("WT", "MT", "ST"):
                    tf_x = cx + sw/2 + 20
                    painter.setPen(ext_pen)
                    painter.drawLine(int(cx + sw/2 + 2), int(cy - sh/2), int(tf_x + 5), int(cy - sh/2))
                    painter.drawLine(int(cx + sw/2 + 2), int(cy - sh/2 + tf), int(tf_x + 5), int(cy - sh/2 + tf))
                    draw_dim(tf_x, cy - sh/2, tf_x, cy - sh/2 + tf, "tf", C_THICK, text_offset_y=-5, rotate=True)
                    
                    tw_y = cy + sh/2 + 25
                    painter.setPen(ext_pen)
                    painter.drawLine(int(cx - tw/2), int(cy + sh/2 + 2), int(cx - tw/2), int(tw_y + 5))
                    painter.drawLine(int(cx + tw/2), int(cy + sh/2 + 2), int(cx + tw/2), int(tw_y + 5))
                    draw_dim(cx - tw/2, tw_y, cx + tw/2, tw_y, "tw", C_THICK, text_offset_y=12)

                    if self.k_val > 0:
                        k_x = cx - sw/2 - 15
                        draw_dim(k_x, cy - sh/2, k_x, cy - sh/2 + k_draw, "k", C_K, text_offset_y=-5, rotate=True)

                # Angles
                elif cat == "L":
                    tw_y = cy + sh/2 + 25
                    painter.setPen(ext_pen)
                    painter.drawLine(int(cx + sw/2 - tw), int(cy + sh/2 - tf + 2), int(cx + sw/2 - tw), int(tw_y + 5))
                    painter.drawLine(int(cx + sw/2), int(cy + sh/2 - tf + 2), int(cx + sw/2), int(tw_y + 5))
                    draw_dim(cx + sw/2 - tw, tw_y, cx + sw/2, tw_y, "t", C_THICK, text_offset_y=12)

                # Rectangular Tubes
                elif cat == "HSS_REC":
                    tw_y = cy + sh/2 + 25
                    painter.setPen(ext_pen)
                    painter.drawLine(int(cx + sw/2 - tw), int(cy + sh/2 - tf + 2), int(cx + sw/2 - tw), int(tw_y + 5))
                    painter.drawLine(int(cx + sw/2), int(cy + sh/2 - tf + 2), int(cx + sw/2), int(tw_y + 5))
                    draw_dim(cx + sw/2 - tw, tw_y, cx + sw/2, tw_y, "t", C_THICK, text_offset_y=12)
            
            painter.end()


    class MaterialPickerDialog(QtWidgets.QDialog):
        def __init__(self, sections, current=None, title=None, parent=None):
            super().__init__(parent)
            self.all_sections = sections
            self.selected_name = None
            self.recent_mgr = RecentManager()

            self.setWindowTitle(title or "JB Material Picker")
            self.setMinimumSize(1000, 720)
            self.setStyleSheet(self._get_style())

            root = QtWidgets.QVBoxLayout(self)
            
            header_layout = QtWidgets.QHBoxLayout()
            header = QtWidgets.QLabel("Select Section Size")
            header.setStyleSheet("font-size: 20px; font-weight: bold; color: #ffffff;")
            header_layout.addWidget(header)
            root.addLayout(header_layout)

            search_layout = QtWidgets.QHBoxLayout()
            self.search = QtWidgets.QLineEdit()
            self.search.setPlaceholderText("Type to filter... (or click microphone to speak)")
            self.search.setClearButtonEnabled(True)
            self.search.textChanged.connect(self._refilter)
            
            self.mic_btn = QtWidgets.QPushButton("🎤")
            self.mic_btn.setToolTip("Start Windows Dictation (Win + H)")
            self.mic_btn.setFixedWidth(45) 
            self.mic_btn.setStyleSheet("font-size: 16px; padding: 6px;")
            self.mic_btn.clicked.connect(self._start_dictation)

            search_layout.addWidget(self.search)
            search_layout.addWidget(self.mic_btn)
            root.addLayout(search_layout)

            body = QtWidgets.QHBoxLayout()

            cat_box = QtWidgets.QGroupBox("Category")
            cat_layout = QtWidgets.QVBoxLayout(cat_box)
            self.cat_list = QtWidgets.QListWidget()
            self.cat_list.setFixedWidth(190)
            self.cat_list.currentItemChanged.connect(lambda *_: self._refilter())
            cat_layout.addWidget(self.cat_list)
            body.addWidget(cat_box)

            res_box = QtWidgets.QGroupBox("Sections")
            res_layout = QtWidgets.QVBoxLayout(res_box)
            self.result_list = QtWidgets.QListWidget()
            self.result_list.currentItemChanged.connect(lambda *_: self._update_props())
            self.result_list.itemDoubleClicked.connect(lambda *_: self._accept())
            res_layout.addWidget(self.result_list)
            self.count_label = QtWidgets.QLabel("")
            self.count_label.setStyleSheet("color:#888888; font-size:11px;")
            res_layout.addWidget(self.count_label)
            body.addWidget(res_box, 1)

            prop_box = QtWidgets.QGroupBox("Properties")
            prop_layout = QtWidgets.QVBoxLayout(prop_box)
            
            self.prop_name = QtWidgets.QLabel("—")
            self.prop_name.setStyleSheet("font-size:18px; font-weight:bold; color:#ff8000;")
            prop_layout.addWidget(self.prop_name)

            self.prop_grid = QtWidgets.QFormLayout()
            prop_layout.addLayout(self.prop_grid)
            
            self.telescope_label = QtWidgets.QLabel("")
            self.telescope_label.setStyleSheet("color:#aaaaaa; font-size:12px; margin-top:8px;")
            self.telescope_label.setWordWrap(True)
            self.telescope_label.hide()
            prop_layout.addWidget(self.telescope_label)
            
            self.graphic = CrossSectionWidget()
            prop_layout.addWidget(self.graphic)

            self.raw_btn = QtWidgets.QPushButton("Inspect Raw Binary Data")
            self.raw_btn.clicked.connect(self._show_raw_data)
            self.raw_btn.hide()
            prop_layout.addWidget(self.raw_btn)

            prop_layout.addStretch()

            prop_box.setFixedWidth(340)
            body.addWidget(prop_box)
            root.addLayout(body, 1)

            btns = QtWidgets.QHBoxLayout()
            btns.addStretch()
            cancel = QtWidgets.QPushButton("Cancel")
            cancel.clicked.connect(self.reject)
            ok = QtWidgets.QPushButton("Select")
            ok.setObjectName("primary")
            ok.setDefault(True)
            ok.clicked.connect(self._accept)
            btns.addWidget(cancel)
            btns.addWidget(ok)
            root.addLayout(btns)

            self._populate_categories()
            self._refilter()
            if current:
                self._select_by_name(current)

            self.search.returnPressed.connect(self._accept_first)
            self.search.setFocus()
            QtGui.QShortcut(QtGui.QKeySequence("Down"), self.search, activated=self._focus_list)

        def _get_style(self):
            return """
            QDialog { background: #1e1e1e; }
            QLabel  { color: #dddddd; }
            QLineEdit { background: #2b2b2b; color: #ffffff; border: 1px solid #3d3d3d; border-radius: 4px; padding: 8px; font-size: 15px; }
            QLineEdit:focus { border: 1px solid #0080c0; }
            QListWidget { background: #232323; color: #dddddd; border: 1px solid #3d3d3d; border-radius: 4px; font-size: 13px; outline: none; }
            QListWidget::item { padding: 6px 8px; }
            QListWidget::item:selected { background: #0080c0; color: #ffffff; }
            QPushButton { background: #333333; color: #dddddd; border: 1px solid #444444; border-radius: 4px; padding: 8px 16px; }
            QPushButton:hover { background: #3d3d3d; }
            QPushButton#primary { background: #0080c0; color: #ffffff; border: none; font-weight: bold; }
            QPushButton#primary:hover { background: #0a90d0; }
            QGroupBox { color: #0080c0; border: 1px solid #333333; border-radius: 4px; margin-top: 10px; font-weight: bold; }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
            """

        def _start_dictation(self):
            self.search.setFocus()
            self.search.setText("")
            VK_LWIN = 0x5B
            VK_H = 0x48
            KEYEVENTF_KEYUP = 0x0002
            ctypes.windll.user32.keybd_event(VK_LWIN, 0, 0, 0)
            ctypes.windll.user32.keybd_event(VK_H, 0, 0, 0)
            ctypes.windll.user32.keybd_event(VK_H, 0, KEYEVENTF_KEYUP, 0)
            ctypes.windll.user32.keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, 0)

        def _populate_categories(self):
            self.cat_list.clear()
            if self.recent_mgr.recents:
                it = QtWidgets.QListWidgetItem(CATEGORY_PREFIXES[0][1])
                it.setData(QtCore.Qt.ItemDataRole.UserRole, "RECENT")
                self.cat_list.addItem(it)

            all_item = QtWidgets.QListWidgetItem(f"All  ({len(self.all_sections)})")
            all_item.setData(QtCore.Qt.ItemDataRole.UserRole, None)
            self.cat_list.addItem(all_item)

            counts = {}
            for s in self.all_sections:
                counts[s.category] = counts.get(s.category, 0) + 1
            for pfx, label in CATEGORY_PREFIXES:
                if pfx == "RECENT": continue
                if pfx in counts:
                    it = QtWidgets.QListWidgetItem(f"{label}  ({counts[pfx]})")
                    it.setData(QtCore.Qt.ItemDataRole.UserRole, pfx)
                    self.cat_list.addItem(it)
            self.cat_list.setCurrentRow(0)

        def _current_category(self):
            it = self.cat_list.currentItem()
            return it.data(QtCore.Qt.ItemDataRole.UserRole) if it else None

        def _refilter(self):
            query = self.search.text().strip()
            cat = self._current_category()

            if cat == "RECENT":
                pool = [s for s in self.all_sections if s.name in self.recent_mgr.recents]
                pool.sort(key=lambda x: self.recent_mgr.recents.index(x.name))
            elif cat:
                pool = [s for s in self.all_sections if s.category == cat]
            else:
                pool = self.all_sections

            if query:
                scored = []
                for s in pool:
                    sc = fuzzy_score(query, s.name)
                    if sc > 0: scored.append((sc, s))
                scored.sort(key=lambda t: (-t[0], t[1].name))
                results = [s for _sc, s in scored]
            else:
                results = pool

            self.result_list.clear()
            for s in results:
                it = QtWidgets.QListWidgetItem(s.name)
                it.setData(QtCore.Qt.ItemDataRole.UserRole, s)
                self.result_list.addItem(it)

            self.count_label.setText(f"{len(results)} section(s)")
            if results: self.result_list.setCurrentRow(0)
            else: self._update_props()

        def _select_by_name(self, name):
            target = name.strip().upper()
            for row in range(self.result_list.count()):
                it = self.result_list.item(row)
                if it.text().upper() == target:
                    self.result_list.setCurrentRow(row)
                    self.result_list.scrollToItem(it)
                    return True
            for s in self.all_sections:
                if s.name.upper() == target:
                    self.search.setText(s.name)
                    return True
            return False

        def _show_raw_data(self):
            it = self.result_list.currentItem()
            if not it: return
            s = it.data(QtCore.Qt.ItemDataRole.UserRole)
            
            text = f"Raw 64-bit float sequence for {s.name}:\n\n"
            for i, val in enumerate(s.raw_data):
                text += f"Index [{i:02d}]: {val}\n"
                
            msg = QtWidgets.QMessageBox(self)
            msg.setWindowTitle("Raw Binary Memory Dump")
            msg.setText(text)
            msg.exec()

        def _update_props(self):
            while self.prop_grid.rowCount() > 0:
                self.prop_grid.removeRow(0)
            self.telescope_label.hide()

            it = self.result_list.currentItem()
            if it is None:
                self.prop_name.setText("—")
                self.graphic.set_section(None)
                self.raw_btn.hide()
                return

            self.raw_btn.show()
            s = it.data(QtCore.Qt.ItemDataRole.UserRole)
            raw = s.raw_data
            self.prop_name.setText(s.name)
            
            def add_row(label, val_str):
                # Ensure passing pre-formatted HTML avoids double-wrapping
                if "<span" not in val_str:
                    val_str = f"<span style='color:#ffffff;'>{val_str}</span>"
                v = QtWidgets.QLabel(val_str)
                v.setStyleSheet("font-size:13px;")
                l = QtWidgets.QLabel(f"<span style='color:#999999; font-size:13px;'>{label}:</span>")
                self.prop_grid.addRow(l, v)

            def clr(val, color):
                return f"<span style='color:{color}'>{val}</span>"

            cat = s.category
            k_val = 0.0
            
            if cat in ("PIPE", "HSS_RND"):
                my_id = s.depth - (2 * s.tw)
                add_row("O.D.", clr(f'{s.depth:.3f}"', C_DEPTH))
                add_row("I.D.", clr(f'{my_id:.3f}"', C_ID))
                add_row("Wall Thk", clr(f'{s.tw:.3f}"', C_THICK))
                add_row("Weight", f"{s.weight:.1f} lb/ft")
                
                fits_in, fits_out = [], []
                for other in self.all_sections:
                    if other.category in ("PIPE", "HSS_RND") and other.name != s.name:
                        other_id = other.depth - (2 * other.tw)
                        c_in = my_id - other.depth
                        if 0.0 < c_in <= 1.5: fits_in.append((other.name, c_in))
                        c_out = other_id - s.depth
                        if 0.0 < c_out <= 1.5: fits_out.append((other.name, c_out))
                
                fits_in.sort(key=lambda x: x[1])
                fits_out.sort(key=lambda x: x[1])
                
                if fits_in or fits_out:
                    t_text = "<span style='color:#ffffff'><b>Telescoping Clearances:</b></span><br>"
                    if fits_in:
                        t_text += "<b>Fits inside this (Inner pipe):</b><br>"
                        for other_name, clear in fits_in[:3]:
                            t_text += f"  • {other_name} <i>({clear:.3f}\" clear)</i><br>"
                    if fits_out:
                        t_text += "<br><b>Fits into (Outer pipe):</b><br>"
                        for other_name, clear in fits_out[:3]:
                            t_text += f"  • {other_name} <i>({clear:.3f}\" clear)</i><br>"
                    self.telescope_label.setText(t_text)
                    self.telescope_label.show()

            elif cat == "HSS_REC":
                add_row("Depth (d)", clr(f'{s.depth:.3f}"', C_DEPTH))
                add_row("Width (b)", clr(f'{s.width:.3f}"', C_WIDTH))
                add_row("Wall Thk", clr(f'{s.tw:.3f}"', C_THICK))
                add_row("Half Depth", f'{s.depth/2:.3f}"')
                add_row("Weight", f"{s.weight:.1f} lb/ft")

            elif cat == "L":
                add_row("Depth (Leg 1)", clr(f'{s.depth:.3f}"', C_DEPTH))
                add_row("Width (Leg 2)", clr(f'{s.width:.3f}"', C_WIDTH))
                add_row("Thickness (t)", clr(f'{s.tw:.3f}"', C_THICK))
                
                g_long = raw[8] if len(raw) > 8 else 0
                g_short = raw[11] if len(raw) > 11 else 0
                add_row("Gages", f"L: {g_long:.3f} | S: {g_short:.3f}")
                
                g1_L, g2_L = (raw[9], raw[10]) if len(raw) > 10 else (0, 0)
                g1_S, g2_S = (raw[12], raw[13]) if len(raw) > 13 else (0, 0)
                if g2_L > 0 or g2_S > 0:
                    add_row("Dbl Gages L", f"{g1_L:.3f} / {g2_L:.3f}")
                    add_row("Dbl Gages S", f"{g1_S:.3f} / {g2_S:.3f}")
                    
                add_row("Weight", f"{s.weight:.1f} lb/ft")

            elif cat in ("WT", "MT", "ST"):
                add_row("Depth (d)", clr(f'{s.depth:.3f}"', C_DEPTH))
                add_row("Width (bf)", clr(f'{s.width:.3f}"', C_WIDTH))
                add_row("Flange t (tf)", clr(f'{s.tf:.3f}"', C_THICK))
                add_row("Web t (tw)", clr(f'{s.tw:.3f}"', C_THICK))
                
                idx_g = 4 if cat == "MT" else 7
                g = raw[idx_g] if len(raw) > idx_g else 0
                ix = raw[14] if len(raw) > 14 else 0
                k_val = raw[17] if len(raw) > 17 else 0
                t_val = max(0, s.depth - k_val)
                
                add_row("k / T", f'{clr(f"{k_val:.3f}", C_K)}" / {clr(f"{t_val:.3f}", C_T)}"')
                add_row("Gage", f'{g:.3f}"')
                add_row("Ix", f"{ix:.1f} in4")
                add_row("Weight", f"{s.weight:.1f} lb/ft")

            else: 
                add_row("Depth (d)", clr(f'{s.depth:.3f}"', C_DEPTH))
                add_row("Width (bf)", clr(f'{s.width:.3f}"', C_WIDTH))
                add_row("Flange t (tf)", clr(f'{s.tf:.3f}"', C_THICK))
                add_row("Web t (tw)", clr(f'{s.tw:.3f}"', C_THICK))
                add_row("Half Depth", f'{s.depth/2:.3f}"')
                
                g = raw[7] if len(raw) > 7 else 0
                ix = raw[14] if len(raw) > 14 else 0
                k_val = raw[17] if len(raw) > 17 else 0
                
                if cat == "C" or cat == "MC":
                    t_val = max(0, s.depth - k_val)
                else:
                    t_val = max(0, s.depth - (2 * k_val) - (2 * s.tf))
                    
                add_row("k / T", f'{clr(f"{k_val:.3f}", C_K)}" / {clr(f"{t_val:.3f}", C_T)}"')
                add_row("Gage", f'{g:.3f}"')
                add_row("Ix", f"{ix:.1f} in4")
                add_row("Weight", f"{s.weight:.1f} lb/ft")

            self.graphic.set_section(s, k_val=k_val)

        def _focus_list(self):
            self.result_list.setFocus()
            if self.result_list.currentRow() < 0 and self.result_list.count():
                self.result_list.setCurrentRow(0)

        def _accept_first(self):
            if self.result_list.count():
                self.result_list.setCurrentRow(0)
                self._accept()

        def _accept(self):
            it = self.result_list.currentItem()
            if it is None: return
            s = it.data(QtCore.Qt.ItemDataRole.UserRole)
            self.selected_name = s.name
            self.recent_mgr.add(s.name)
            self.accept()

    return MaterialPickerDialog

# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def pick_material(categories=None, current=None, job_name=None,
                  mtrl_path=None, title=None, parent=None):
    from PySide6 import QtWidgets

    path = mtrl_path or MaterialFile.find_job_mtrl(job_name=job_name)
    if not path:
        print("Material file not found.")
        return None

    mf = MaterialFile(path)
    if mf.error: return None

    prefixes = None
    if categories:
        prefixes = []
        for c in categories:
            if c in SDS2_TYPE_TO_PREFIXES: prefixes.extend(SDS2_TYPE_TO_PREFIXES[c])
            else: prefixes.append(c)

    sections = mf.by_category(prefixes)
    if not sections: return None

    app = QtWidgets.QApplication.instance()
    created = False
    if app is None:
        app = QtWidgets.QApplication(sys.argv if sys.argv else [""])
        created = True

    DialogCls = _build_dialog_classes()
    dlg = DialogCls(sections, current=current, title=title, parent=parent)
    dlg.exec()
    result = dlg.selected_name

    if created: app.quit()
    return result

if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else None
    if not path: path = MaterialFile.find_job_mtrl(job_name="SampleJob")
    if path:
        print(f"Picked: {pick_material(mtrl_path=path)}")
