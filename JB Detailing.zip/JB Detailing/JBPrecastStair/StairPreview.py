"""
=============================================================================
JBPrecastStair
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

"""
=============================================================================
 JBPrecastStair - StairPreview
=============================================================================
 Live preview: side elevation on top, plan strip (zone widths about the
 picked nosing line) underneath. Both share one horizontal scale.
=============================================================================
"""

import math

from PySide6 import QtCore, QtGui, QtWidgets

from StairState import StairGeometry, z_range, fmt_len


BG = QtGui.QColor("#1e2128")
CONCRETE = QtGui.QColor("#9aa0a8")
CONCRETE_EDGE = QtGui.QColor("#d4dae4")
SLAB = QtGui.QColor("#3a4150")
ACCENT = QtGui.QColor("#ffb648")
DIM = QtGui.QColor("#8fb8e8")
TEXT = QtGui.QColor("#aab4c4")
ERR = QtGui.QColor("#ef9a9a")


class StairPreview(QtWidgets.QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.state = None
        self.focus_key = None
        self.setMinimumSize(520, 460)

    def set_state(self, state, focus_key=None):
        self.state = state
        if focus_key is not None:
            self.focus_key = focus_key
        self.update()

    # -----------------------------------------------------------------
    def paintEvent(self, _e):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), BG)
        if self.state is None:
            p.end()
            return
        g = StairGeometry(self.state)
        if g.errors:
            p.setPen(ERR)
            p.drawText(self.rect().adjusted(20, 20, -20, -20),
                       QtCore.Qt.AlignmentFlag.AlignCenter,
                       "\n".join(g.errors))
            p.end()
            return
        try:
            self._paint(p, g)
        finally:
            p.end()

    def _paint(self, p, g):
        st = self.state
        W = self.width()
        Hh = self.height()
        margin = 70
        plan_h = 150

        # --- elevation extents (slabs drawn a bit past the piece) ---
        ext = max(12.0, 0.08 * g.L)
        umin = min(0.0, g.u0) - ext
        umax = g.u1 + ext
        vlo, vhi = g.v_extents()
        vmin = min(vlo, -max(g.Tb, 6.0)) - 6.0
        vmax = vhi + 12.0

        elev_rect = QtCore.QRectF(margin, 30, W - 2 * margin,
                                  Hh - plan_h - 90)
        sx = elev_rect.width() / (umax - umin)
        sy = elev_rect.height() / (vmax - vmin)
        s = min(sx, sy)
        # centre horizontally
        ox = elev_rect.left() + (elev_rect.width() - s * (umax - umin)) / 2.0
        oy = elev_rect.top() + (elev_rect.height() - s * (vmax - vmin)) / 2.0

        def E(u, v):
            return QtCore.QPointF(ox + (u - umin) * s, oy + (vmax - v) * s)

        # --- slabs (context only) ---
        p.setPen(QtCore.Qt.PenStyle.NoPen)
        p.setBrush(SLAB)
        slab_t = max(g.Tb, 6.0)
        bot_end = g.u0 if g.Db > 1e-6 else g.t
        p.drawPolygon(QtGui.QPolygonF([
            E(umin, 0.0), E(bot_end, 0.0),
            E(bot_end, -slab_t), E(umin, -slab_t)]))
        top_t = max(g.Tt, 6.0)
        top_start = g.u1
        p.drawPolygon(QtGui.QPolygonF([
            E(top_start, g.H), E(umax, g.H),
            E(umax, g.H - top_t), E(top_start, g.H - top_t)]))

        # --- stair profile ---
        poly = QtGui.QPolygonF([E(u, v) for (u, v) in g.profile])
        p.setBrush(CONCRETE)
        p.setPen(QtGui.QPen(CONCRETE_EDGE, 1.4))
        p.drawPolygon(poly)

        # --- nosing line + picks ---
        pen = QtGui.QPen(ACCENT, 1.2, QtCore.Qt.PenStyle.DashLine)
        p.setPen(pen)
        p.drawLine(E(0.0, 0.0), E(g.L, g.H))
        p.setBrush(ACCENT)
        p.setPen(QtCore.Qt.PenStyle.NoPen)
        for (u, v) in ((0.0, 0.0), (g.L, g.H)):
            p.drawEllipse(E(u, v), 4.5, 4.5)
        p.setPen(ACCENT)
        f = p.font()
        f.setPointSize(8)
        p.setFont(f)
        p.drawText(E(0.0, 0.0) + QtCore.QPointF(-40, 16), "Bottom pick")
        p.drawText(E(g.L, g.H) + QtCore.QPointF(-30, -10), "Top pick")

        # --- dimensions ---
        hi = self.focus_key
        # overall rise (right side) and run (bottom)
        x_r = E(umax, 0).x() + 14
        self._vdim(p, x_r, E(0, 0).y(), E(0, g.H).y(),
                   "Rise %s" % fmt_len(g.H), False)
        y_b = E(0, vmin).y() + 4
        self._hdim(p, E(0, 0).x(), E(g.L, 0).x(), y_b,
                   "Run %s" % fmt_len(g.L), False)

        # riser / tread at the first step
        if g.n >= 2:
            x1 = E(g.t, 0).x() - 10
            self._vdim(p, x1, E(0, 0).y(), E(0, g.r).y(),
                       fmt_len(g.r), hi in ("max_riser", "riser_count"))
            y1 = E(0, 2 * g.r).y() - 10
            self._hdim(p, E(g.t, 0).x(), E(2 * g.t, 0).x(), y1,
                       fmt_len(g.t), hi in ("max_riser", "riser_count"))

        # waist callout, square to the pitch at mid-flight
        k = max(1, g.n // 2)
        tu, tv = k * g.t, (k - 1) * g.r              # a throat corner
        ang = math.atan2(g.r, g.t)
        nu, nv = math.sin(ang), -math.cos(ang)       # down-slope normal
        a = E(tu, tv)
        b = E(tu + nu * g.w, tv + nv * g.w)
        p.setPen(QtGui.QPen(ACCENT if hi == "waist" else DIM, 1.2))
        p.drawLine(a, b)
        p.drawText(b + QtCore.QPointF(6, 12), "Waist %s" % fmt_len(g.w))

        # landing depths / thicknesses
        if g.Db > 1e-6:
            self._hdim(p, E(g.u0, 0).x(), E(g.t, 0).x(),
                       E(0, -g.Tb).y() + 16, fmt_len(g.Db),
                       hi == "bot_land_depth")
            self._vdim(p, E(g.u0, 0).x() - 12, E(0, 0).y(), E(0, -g.Tb).y(),
                       fmt_len(g.Tb), hi == "bot_land_thick")
        if g.Dt > 1e-6:
            self._hdim(p, E(g.L, 0).x(), E(g.u1, 0).x(),
                       E(0, g.H).y() - 12, fmt_len(g.Dt),
                       hi == "top_land_depth")
            self._vdim(p, E(g.u1, 0).x() + 12, E(0, g.H).y(),
                       E(0, g.H - g.Tt).y(), fmt_len(g.Tt),
                       hi == "top_land_thick")

        # --- plan strip ---
        self._paint_plan(p, g, s, ox, umin, Hh - plan_h - 20, plan_h)

        # --- summary ---
        p.setPen(TEXT)
        f.setPointSize(9)
        p.setFont(f)
        p.drawText(QtCore.QPointF(12, 18),
                   "%d risers @ %s   %d treads @ %s   %.1f deg"
                   % (g.n, fmt_len(g.r), g.n - 1, fmt_len(g.t), g.angle))

    def _paint_plan(self, p, g, s, ox, umin, top, height):
        st = self.state
        zmin, zmax = g.plate_z_range()
        span = max(zmax - zmin, 1.0)
        sz = min(s, (height - 30) / span)
        mid_y = top + height / 2.0
        zc = (zmin + zmax) / 2.0

        def P(u, z):
            # +z (NS) drawn toward the bottom of the strip (toward viewer)
            return QtCore.QPointF(ox + (u - umin) * s, mid_y + (z - zc) * sz)

        hi = self.focus_key
        width_keys = {"bottom landing": "bot_land_width",
                      "flight": "stair_width",
                      "top landing": "top_land_width"}
        for name, ua, ub, width in g.zones():
            z0, z1 = z_range(width, st.ref_face)
            r = QtCore.QRectF(P(ua, z0), P(ub, z1))
            focused = hi == width_keys[name] or hi == "ref_face"
            p.setBrush(CONCRETE)
            p.setPen(QtGui.QPen(ACCENT if focused else CONCRETE_EDGE,
                                2.0 if focused else 1.0))
            p.drawRect(r)
            p.setPen(QtGui.QColor("#1e2128"))
            p.drawText(r, QtCore.Qt.AlignmentFlag.AlignCenter,
                       fmt_len(width))

        # picked nosing line
        p.setPen(QtGui.QPen(ACCENT, 1.2, QtCore.Qt.PenStyle.DashLine))
        p.drawLine(P(umin, 0.0), P(g.u1 + 6.0, 0.0))
        p.setPen(ACCENT)
        p.drawText(P(g.u1 + 8.0, 0.0) + QtCore.QPointF(0, 4),
                   "nosing line (%s)" % st.ref_face)
        p.setPen(TEXT)
        p.drawText(QtCore.QPointF(10, P(0, zmax).y() + 4), "NS")
        p.drawText(QtCore.QPointF(10, P(0, zmin).y() + 4), "FS")
        p.drawText(QtCore.QPointF(10, top + 2), "PLAN")

    # -----------------------------------------------------------------
    def _hdim(self, p, x1, x2, y, text, hot):
        p.setPen(QtGui.QPen(ACCENT if hot else DIM, 1.0))
        p.drawLine(QtCore.QPointF(x1, y), QtCore.QPointF(x2, y))
        for x in (x1, x2):
            p.drawLine(QtCore.QPointF(x, y - 4), QtCore.QPointF(x, y + 4))
        fm = p.fontMetrics()
        tw = fm.horizontalAdvance(text)
        p.drawText(QtCore.QPointF((x1 + x2) / 2.0 - tw / 2.0, y - 4), text)

    def _vdim(self, p, x, y1, y2, text, hot):
        p.setPen(QtGui.QPen(ACCENT if hot else DIM, 1.0))
        p.drawLine(QtCore.QPointF(x, y1), QtCore.QPointF(x, y2))
        for y in (y1, y2):
            p.drawLine(QtCore.QPointF(x - 4, y), QtCore.QPointF(x + 4, y))
        p.save()
        p.translate(x - 5, (y1 + y2) / 2.0)
        p.rotate(-90)
        fm = p.fontMetrics()
        tw = fm.horizontalAdvance(text)
        p.drawText(QtCore.QPointF(-tw / 2.0, 0), text)
        p.restore()
