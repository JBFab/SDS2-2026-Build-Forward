"""
=============================================================================
JBPrecastStair
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

"""
=============================================================================
 JBPrecastStair - StairDialog
=============================================================================
 PySide6 dialog. Left = inputs + live step readout, right = docked
 preview. Focusing a field highlights its dimension in the preview.
=============================================================================
"""

import sys

from PySide6 import QtCore, QtGui, QtWidgets

from StairState import (StairState, StairGeometry, RefFace, auto_risers,
                        fmt_len, parse_len)
from StairPreview import StairPreview


STYLE = """
QDialog, QWidget#Page { background: #1e2128; color: #d4dae4; font-size: 12px; }
QLabel { color: #aab4c4; }
QLabel#Val { color: #e8eef7; font-weight: 600; }
QLabel#Issue { color: #ef9a9a; }
QLabel#Note { color: #ffcc80; }
QGroupBox {
    border: 1px solid #2f3540; border-radius: 6px;
    margin-top: 12px; padding-top: 8px; font-weight: 600; color: #c3ccd9;
}
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
QLineEdit, QComboBox, QSpinBox {
    background: #262a33; border: 1px solid #363c48; border-radius: 4px;
    padding: 3px 6px; color: #e3e9f2; selection-background-color: #ffb648;
    selection-color: #1e2128;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus {
    border: 1px solid #ffb648; background: #2b303a;
}
QLineEdit:disabled, QSpinBox:disabled { color: #6f7a8a; }
QComboBox QAbstractItemView {
    background: #262a33; border: 1px solid #3a4150;
    selection-background-color: #ffb648; selection-color: #1e2128;
}
QCheckBox { color: #c3ccd9; spacing: 7px; }
QCheckBox::indicator { width: 15px; height: 15px; }
QCheckBox::indicator:unchecked {
    border: 1px solid #4a5261; background: #262a33; border-radius: 3px;
}
QCheckBox::indicator:checked {
    border: 1px solid #ffb648; background: #ffb648; border-radius: 3px;
}
QPushButton {
    background: #2d323d; border: 1px solid #3c4351; border-radius: 5px;
    padding: 5px 13px; color: #dbe2ec;
}
QPushButton:hover { background: #363d4a; border-color: #4d5666; }
QPushButton#Primary {
    background: #ffb648; color: #1e2128; border: none; font-weight: 600;
}
QPushButton#Primary:hover { background: #ffc46a; }
QPushButton#Small { padding: 2px 8px; }
QScrollArea { border: none; background: transparent; }
"""


class _Bound(object):
    """Mixin: tell the dialog which field has focus."""

    def focusInEvent(self, e):
        super().focusInEvent(e)
        self.dlg.focus_field(self.key)


class LenEdit(_Bound, QtWidgets.QLineEdit):
    """SDS2-style dimension entry. Numpad + types a space."""

    def __init__(self, key, dlg):
        super().__init__()
        self.key = key
        self.dlg = dlg
        self.setMinimumWidth(90)
        self.editingFinished.connect(self._commit)

    def keyPressEvent(self, e):
        if e.text() == "+":
            self.insert(" ")
            return
        super().keyPressEvent(e)

    def load(self, value):
        self.blockSignals(True)
        self.setText(fmt_len(value))
        self.blockSignals(False)

    def _commit(self):
        val = parse_len(self.text(), None)
        if val is None or val < 0:
            val = getattr(self.dlg.state, self.key)
        setattr(self.dlg.state, self.key, val)
        self.load(val)
        self.dlg.refresh()


class Choice(_Bound, QtWidgets.QComboBox):
    def __init__(self, key, dlg, items):
        super().__init__()
        self.key = key
        self.dlg = dlg
        self.addItems(list(items))
        self.currentTextChanged.connect(self._commit)

    def load(self, value):
        self.blockSignals(True)
        i = self.findText(str(value))
        if i >= 0:
            self.setCurrentIndex(i)
        self.blockSignals(False)

    def _commit(self, text):
        setattr(self.dlg.state, self.key, text)
        self.dlg.refresh()


class TextEdit(_Bound, QtWidgets.QLineEdit):
    def __init__(self, key, dlg):
        super().__init__()
        self.key = key
        self.dlg = dlg
        self.editingFinished.connect(self._commit)

    def load(self, value):
        self.blockSignals(True)
        self.setText(str(value or ""))
        self.blockSignals(False)

    def _commit(self):
        setattr(self.dlg.state, self.key, self.text().strip())
        self.dlg.refresh()


class RiserSpin(_Bound, QtWidgets.QSpinBox):
    def __init__(self, key, dlg):
        super().__init__()
        self.key = key
        self.dlg = dlg
        self.setRange(1, 99)
        self.valueChanged.connect(self._commit)

    def load(self, value):
        self.blockSignals(True)
        self.setValue(int(value))
        self.blockSignals(False)

    def _commit(self, v):
        setattr(self.dlg.state, self.key, int(v))
        self.dlg.refresh()


class JBPrecastStairDialog(QtWidgets.QDialog):

    def __init__(self, state=None, parent=None, title="JB Precast Stair"):
        super().__init__(parent)
        self.state = state or StairState()
        self.widgets = {}
        self.setWindowTitle(title)
        self.setStyleSheet(STYLE)
        # Keep above SDS2's main window on an accidental outside click.
        self.setWindowFlags(self.windowFlags()
                            | QtCore.Qt.WindowType.WindowStaysOnTopHint)
        self.resize(1100, 720)
        self._build()
        self.load_all()
        self.refresh()

    # -----------------------------------------------------------------
    def _build(self):
        root = QtWidgets.QHBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(10)

        left = QtWidgets.QWidget()
        left.setObjectName("Page")
        form_col = QtWidgets.QVBoxLayout(left)
        form_col.setContentsMargins(0, 0, 6, 0)

        # ---- stair
        g = self._group(form_col, "Stair")
        self._len(g, "stair_width", "Stair width:")
        self._add(g, "ref_face", "Reference face:",
                  Choice("ref_face", self, RefFace.ALL))
        self._len(g, "waist", "Waist thickness:")

        # ---- risers
        g = self._group(form_col, "Risers")
        self._len(g, "max_riser", "Max riser height:")
        self.auto_chk = QtWidgets.QCheckBox("Auto (rise / max riser, rounded up)")
        self.auto_chk.toggled.connect(self._auto_toggled)
        g.addRow("", self.auto_chk)
        self._add(g, "riser_count", "Number of risers:",
                  RiserSpin("riser_count", self))

        # ---- readout
        g = self._group(form_col, "Stair Geometry")
        self.lbl = {}
        for key, text in (("rise_run", "Rise / Run:"),
                          ("riser", "Riser height:"),
                          ("tread", "Tread width:"),
                          ("angle", "Angle:"),
                          ("weight", "Approx. weight:")):
            lab = QtWidgets.QLabel("")
            lab.setObjectName("Val")
            lab.setTextInteractionFlags(
                QtCore.Qt.TextInteractionFlag.TextSelectableByMouse)
            g.addRow(text, lab)
            self.lbl[key] = lab

        # ---- landings
        for prefix, title in (("top", "Top Landing Extension"),
                              ("bot", "Bottom Landing Extension")):
            g = self._group(form_col, title)
            row = QtWidgets.QHBoxLayout()
            ed = LenEdit("%s_land_width" % prefix, self)
            self.widgets[ed.key] = ed
            btn = QtWidgets.QPushButton("= stair")
            btn.setObjectName("Small")
            btn.setToolTip("Match the stair width")
            btn.clicked.connect(lambda _c=False, k=ed.key: self._match(k))
            row.addWidget(ed, 1)
            row.addWidget(btn)
            g.addRow("Width:", row)
            self._len(g, "%s_land_depth" % prefix, "Depth (from riser):")
            self._len(g, "%s_land_thick" % prefix, "Thickness:")

        # ---- general
        g = self._group(form_col, "General")
        self._add(g, "description", "Description:",
                  TextEdit("description", self))
        self._add(g, "mark_prefix", "Piecemark prefix:",
                  TextEdit("mark_prefix", self))

        self.issue_lbl = QtWidgets.QLabel("")
        self.issue_lbl.setWordWrap(True)
        form_col.addWidget(self.issue_lbl)
        form_col.addStretch(1)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(left)
        scroll.setHorizontalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setMinimumWidth(440)
        scroll.setMaximumWidth(480)

        # ---- right: preview + buttons
        right = QtWidgets.QVBoxLayout()
        self.preview = StairPreview()
        right.addWidget(self.preview, 1)
        btns = QtWidgets.QHBoxLayout()
        btns.addStretch(1)
        cancel = QtWidgets.QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        ok = QtWidgets.QPushButton("Build Stair")
        ok.setObjectName("Primary")
        ok.setDefault(True)
        ok.clicked.connect(self._accept)
        btns.addWidget(cancel)
        btns.addWidget(ok)
        right.addLayout(btns)

        root.addWidget(scroll)
        root.addLayout(right, 1)

    def _group(self, col, title):
        box = QtWidgets.QGroupBox(title)
        form = QtWidgets.QFormLayout(box)
        form.setLabelAlignment(QtCore.Qt.AlignmentFlag.AlignRight)
        form.setHorizontalSpacing(10)
        col.addWidget(box)
        return form

    def _add(self, form, key, label, widget):
        self.widgets[key] = widget
        form.addRow(label, widget)

    def _len(self, form, key, label):
        self._add(form, key, label, LenEdit(key, self))

    # -----------------------------------------------------------------
    def load_all(self):
        for key, w in self.widgets.items():
            w.load(getattr(self.state, key))
        self.auto_chk.blockSignals(True)
        self.auto_chk.setChecked(bool(self.state.riser_auto))
        self.auto_chk.blockSignals(False)

    def _auto_toggled(self, on):
        st = self.state
        if not on:
            # Start the override from what auto currently gives.
            st.riser_count = auto_risers(st.total_rise, st.max_riser)
        st.riser_auto = bool(on)
        self.refresh()

    def _match(self, key):
        setattr(self.state, key, self.state.stair_width)
        self.widgets[key].load(self.state.stair_width)
        self.refresh()

    def focus_field(self, key):
        self.preview.set_state(self.state, key)

    def refresh(self):
        st = self.state
        spin = self.widgets["riser_count"]
        spin.setEnabled(not st.riser_auto)
        spin.load(st.risers())

        g = StairGeometry(st)
        if g.errors:
            for lab in self.lbl.values():
                lab.setText("-")
            self.issue_lbl.setObjectName("Issue")
            self.issue_lbl.setText("\n".join(g.errors))
        else:
            self.lbl["rise_run"].setText("%s / %s" % (fmt_len(g.H),
                                                      fmt_len(g.L)))
            self.lbl["riser"].setText("%s  (%d risers)" % (fmt_len(g.r), g.n))
            self.lbl["tread"].setText("%s  (%d treads)" % (fmt_len(g.t),
                                                           g.n - 1))
            self.lbl["angle"].setText("%.2f deg" % g.angle)
            self.lbl["weight"].setText("%.0f lb  (%.1f cf @ 150 pcf)"
                                       % (g.weight_lb(), g.volume_cf()))
            self.issue_lbl.setObjectName("Note")
            self.issue_lbl.setText("\n".join(g.notes))
        self.issue_lbl.style().unpolish(self.issue_lbl)
        self.issue_lbl.style().polish(self.issue_lbl)
        self.preview.set_state(st)

    def _accept(self):
        # Commit whatever field is still being typed in.
        w = QtWidgets.QApplication.focusWidget()
        if isinstance(w, (LenEdit, TextEdit)):
            w._commit()
        g = StairGeometry(self.state)
        if g.errors:
            QtWidgets.QMessageBox.warning(self, "Cannot build",
                                          "\n".join(g.errors))
            return
        self.accept()


# ---------------------------------------------------------------------------
# Dialog driver - same approach as JBSimpleLadder: keep one QApplication
# alive for the session and spin a local event loop, since SDS2 may
# already own a Qt loop and a re-entrant exec() can return immediately.
# ---------------------------------------------------------------------------
_QAPP = None


def _ensure_app():
    global _QAPP
    app = QtWidgets.QApplication.instance()
    if app is None:
        app = QtWidgets.QApplication(sys.argv if sys.argv else [""])
        _QAPP = app
    return app


def _terms_accepted(plugin):
    """Ask once for acceptance of the JB Detailing Terms of Use
    (_shared/JBTerms.py). If that file isn't installed, carry on."""
    import os
    import sys
    try:
        import JBTerms
    except ImportError:
        shared = os.path.join(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))), "_shared")
        if shared not in sys.path:
            sys.path.append(shared)
        try:
            import JBTerms
        except ImportError:
            return True
    return JBTerms.ensure_accepted(plugin)


def run_dialog(state=None, parent=None, title="JB Precast Stair"):
    """Show the dialog modally; return the edited StairState or None."""
    app = _ensure_app()
    if not _terms_accepted("JB Precast Stair"):
        return None

    dlg = JBPrecastStairDialog(state, parent, title=title)
    dlg.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
    dlg.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, False)

    loop = QtCore.QEventLoop()
    outcome = {"code": None}

    def _finished(code):
        outcome["code"] = code
        loop.quit()

    dlg.finished.connect(_finished)
    dlg.show()
    dlg.raise_()
    dlg.activateWindow()
    app.processEvents()
    # The dialog can already have finished during processEvents() above.
    # Then it must not be re-shown (it is hidden because it closed), and
    # its loop.quit() ran before the loop started, so exec() would wait
    # forever.
    if outcome["code"] is None and not dlg.isVisible():
        dlg.show()
        app.processEvents()

    if outcome["code"] is None:
        loop.exec()

    code = outcome["code"]
    if code is None:
        code = dlg.result()
    result = dlg.state if code == QtWidgets.QDialog.DialogCode.Accepted \
        else None
    dlg.deleteLater()
    app.processEvents()
    return result


if __name__ == "__main__":
    st = run_dialog()
    print("accepted:", bool(st))
    if st:
        print(st.to_json())
