"""
=============================================================================
 JBPrecastStair  -  one-piece precast concrete stair custom member
=============================================================================
 Same structure as JBSimpleLadder:

     class JBPrecastStair(StateAccessor, MemberBase.MemberBase)

 SDS2 lifecycle:
     Add()             locate top nosing, then bottom nosing
     Edit()            PySide6 dialog (SDS2 calls it after Add as well)
     CreateMaterial()  build the stair - called on every reprocess

 The member line IS the nosing line: left end = bottom pick, right end =
 top pick. The stair is rebuilt from the member ends every process, so
 moving an end moves/re-steps the stair (in auto mode the riser count is
 recalculated too).

 Picks
 -----
   Top    - corner of the top slab where it drops (top nosing).
   Bottom - the nosing line projected down to the top of the bottom slab.

 Files
 -----
   JBPrecastStair.py   <- this file
   StairState.py       state + profile geometry (no SDS2 / Qt)
   StairBuild.py       material creation
   StairDialog.py      PySide6 dialog
   StairPreview.py     dialog preview
   PLUGIN, __init__.py
=============================================================================
"""

"""
=============================================================================
JBPrecastStair
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

import datetime
import math
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)


def _ensure_pyside6():
    """Make PySide6 importable without the user installing it.

    SDS2 does not ship PySide6. If the user has installed it into SDS2's
    Python themselves, use that copy, since loading a second set of Qt DLLs
    into the same process crashes. Otherwise
    fall back to the copy bundled in _vendor, either beside this plugin or
    one folder up when the JB Detailing plugins are shipped together."""
    import importlib.util
    if importlib.util.find_spec("PySide6") is not None:
        return
    for vendor in (os.path.join(_HERE, "_vendor"),
                   os.path.join(os.path.dirname(_HERE), "_vendor")):
        if os.path.isdir(os.path.join(vendor, "PySide6")):
            if vendor not in sys.path:
                sys.path.append(vendor)
            return


_ensure_pyside6()

import MemberBase
from StateAccessor import StateAccessor
from Point3D import Point3D
from point import PointLocate
import param

from StairState import StairState, FIELDS
import StairBuild


def _trace(msg):
    """Append a call-sequence line so we can see how SDS2 drives us."""
    try:
        path = os.path.join(_HERE, "JBPrecastStair_calls.log")
        with open(path, "a") as fh:
            fh.write("%s  %s\n" % (datetime.datetime.now().isoformat(), msg))
    except Exception:
        pass


MEMBERTYPEID = "JBPrecastStair"

# StairState field -> persisted member attribute. A few are renamed so
# they cannot collide with MemberBase's own attributes.
_RENAMED = {"description": "stair_desc"}


def _attr(name):
    return _RENAMED.get(name, name)


class JBPrecastStair(StateAccessor, MemberBase.MemberBase):
    """One-piece precast stair with optional top/bottom landing extensions."""

    _version = 0
    _arguments = {}
    _arguments[0] = [(_attr(name), default) for name, default in FIELDS]

    # -----------------------------------------------------------------
    def __init__(self, *args, **kw):
        StateAccessor.__init__(self, *args, **kw)
        MemberBase.MemberBase.__init__(self)
        self.SetMemberType(MEMBERTYPEID)
        param.Units("feet")
        try:
            self.SetPiecemarkPrefix(self.mark_prefix)
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Member attributes <-> StairState
    # -----------------------------------------------------------------
    def to_state(self):
        st = StairState()
        for name, _default in FIELDS:
            try:
                setattr(st, name, getattr(self, _attr(name)))
            except Exception:
                pass
        try:
            a = self.GetLeftLocation()
            b = self.GetRightLocation()
            st.total_rise = abs(b.z - a.z)
            st.total_run = math.hypot(b.x - a.x, b.y - a.y)
        except Exception:
            pass
        return st

    def from_state(self, st):
        for name, _default in FIELDS:
            try:
                setattr(self, _attr(name), getattr(st, name))
            except Exception:
                pass

    def _apply_member_info(self):
        try:
            self.SetDescription(self.stair_desc)
        except Exception:
            pass
        try:
            self.SetPiecemarkPrefix(self.mark_prefix)
        except Exception:
            pass

    # -----------------------------------------------------------------
    # SDS2 lifecycle
    # -----------------------------------------------------------------
    def Add(self):
        _trace("Add() enter")
        param.Units("feet")

        top = PointLocate("Locate TOP nosing  (top slab corner where it drops)")
        if top is None:
            return False
        bot = PointLocate("Locate BOTTOM nosing  (nosing line at top of "
                          "bottom slab)", top)
        if bot is None:
            return False

        # Tolerate the picks being made in the other order.
        if bot.z > top.z:
            top, bot = bot, top
        if abs(top.z - bot.z) < 1e-6 or \
                math.hypot(top.x - bot.x, top.y - bot.y) < 1e-6:
            param.Warning("JBPrecastStair: the two picks must differ in "
                          "both elevation and plan.")
            return False

        # Member line = nosing line, bottom -> top.
        self.SetLeftLocation(Point3D(bot.x, bot.y, bot.z))
        self.SetRightLocation(Point3D(top.x, top.y, top.z))
        self._apply_member_info()
        _trace("Add() return True")
        return True

    def Edit(self):
        _trace("Edit() enter")
        try:
            return self._Edit([self])
        except Exception as exc:
            param.Warning("JBPrecastStair.Edit: %s" % exc)
        return False

    def _Edit(self, modelList):
        param.Units("feet")
        for m in modelList:
            if not m._run_dialog():
                return False
            m._apply_member_info()
        return True

    def _run_dialog(self):
        try:
            from StairDialog import run_dialog
        except Exception as exc:
            param.Warning("JBPrecastStair: dialog unavailable: %s" % exc)
            return False
        try:
            num = self.GetMemberNumber()
        except Exception:
            num = 0
        title = "JB Precast Stair" + (" [%d]" % num if num else "")
        result = run_dialog(self.to_state(), title=title)
        if result is None:
            return False
        self.from_state(result)
        return True

    def CreateMaterial(self):
        _trace("CreateMaterial() enter")
        try:
            return self._CreateMaterial()
        except Exception as exc:
            param.Warning("JBPrecastStair.CreateMaterial: %s" % exc)
        return False

    def _CreateMaterial(self):
        param.Units("feet")
        self._apply_member_info()
        try:
            self.SetRotation(0.0)
        except Exception:
            pass

        builder = StairBuild.StairBuilder(self, self.to_state())
        ok = builder.generate()
        path = builder.log.write_file()
        if builder.log.warnings:
            msg = ["JBPrecastStair: %d warning(s):"
                   % len(builder.log.warnings)]
            msg.extend("  " + w for w in builder.log.warnings[:8])
            msg.append("Full log: %s" % (path or "(could not write log)"))
            param.Warning("\n".join(msg))
        return ok


# ---------------------------------------------------------------------------
# Register with SDS2
# ---------------------------------------------------------------------------
try:
    MemberBase.RegisterMemberType(JBPrecastStair, "JB Precast Stair")
except Exception as exc:                              # pragma: no cover
    try:
        param.Warning("JBPrecastStair registration failed: %s" % exc)
    except Exception:
        pass
