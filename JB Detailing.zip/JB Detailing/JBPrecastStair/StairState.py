"""
=============================================================================
JBPrecastStair
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

"""
=============================================================================
 JBPrecastStair - StairState
=============================================================================
 Plain-Python state + geometry shared by the dialog, the preview and the
 build. Nothing in here imports SDS2 or Qt, so the profile math can be
 tested outside SDS2.

 Stair coordinates (all decimal inches)
 --------------------------------------
     u = horizontal, along the walking direction (uphill positive)
     v = vertical (up positive)
     z = across the stair, +z = member near side (NS)

 Origin (u=0, v=0) is the BOTTOM pick: the nosing line projected down to
 the top of the bottom slab. The TOP pick is (L, H): the corner of the
 top slab where it drops, i.e. the top nosing.

 With n risers every nosing sits on the nosing line:
     nosing i = (i*t, i*r)      r = H/n, t = L/n,  i = 1..n
 so the first riser face is at u = t and the last (top) riser face is at
 u = L. There are n-1 treads between them.

 Waist is measured perpendicular to the pitch, from the soffit to the
 inside corners (throat) of the steps.

 Landing depth is measured horizontally from the riser face:
     bottom landing  u = t - Db .. t      top at v = 0
     top landing     u = L .. L + Dt      top at v = H
=============================================================================
"""

import copy
import json
import math
import re


EPS = 1e-6


class RefFace(object):
    """Which face of the stair lies on the picked nosing line."""
    NS = "NS"
    FS = "FS"
    CENTER = "Center"
    ALL = (NS, FS, CENTER)


# (name, default) - every persisted field, in dialog order.
FIELDS = [
    ("description", "PRECAST STAIR"),
    ("mark_prefix", "PS"),
    ("ref_face", RefFace.CENTER),
    ("stair_width", 48.0),
    ("waist", 6.0),
    ("max_riser", 7.0),
    ("riser_auto", True),
    ("riser_count", 0),
    ("top_land_width", 48.0),
    ("top_land_depth", 12.0),
    ("top_land_thick", 6.0),
    ("bot_land_width", 48.0),
    ("bot_land_depth", 12.0),
    ("bot_land_thick", 6.0),
]


class StairState(object):
    """Every user-editable value, plus the rise/run read off the picks."""

    def __init__(self):
        for name, default in FIELDS:
            setattr(self, name, default)
        # Not persisted as parameters - derived from the member ends.
        self.total_rise = 120.0
        self.total_run = 180.0

    # -----------------------------------------------------------------
    def risers(self):
        """Riser count actually used: auto from max riser, or the override."""
        if self.riser_auto or int(self.riser_count) < 1:
            return auto_risers(self.total_rise, self.max_riser)
        return int(self.riser_count)

    def to_dict(self):
        return {name: getattr(self, name) for name, _d in FIELDS}

    def from_dict(self, d):
        for name, _default in FIELDS:
            if name in d:
                setattr(self, name, d[name])
        return self

    def to_json(self):
        return json.dumps(self.to_dict(), sort_keys=True)

    def clone(self):
        return copy.deepcopy(self)


def auto_risers(rise, max_riser):
    """Rise / max riser, rounded up. Never less than 1."""
    if max_riser <= EPS:
        max_riser = 7.0
    return max(1, int(math.ceil(float(rise) / float(max_riser) - 1e-9)))


# ---------------------------------------------------------------------------
# Geometry
# ---------------------------------------------------------------------------
def z_range(width, ref_face):
    """Span across the stair (z min, z max) for a given width."""
    w = float(width)
    if ref_face == RefFace.NS:
        return (-w, 0.0)          # NS face on the line, body toward FS
    if ref_face == RefFace.FS:
        return (0.0, w)           # FS face on the line, body toward NS
    return (-w / 2.0, w / 2.0)


def _dedupe(pts):
    out = []
    for p in pts:
        if out and abs(out[-1][0] - p[0]) < EPS and abs(out[-1][1] - p[1]) < EPS:
            continue
        out.append(p)
    while len(out) > 1 and abs(out[0][0] - out[-1][0]) < EPS \
            and abs(out[0][1] - out[-1][1]) < EPS:
        out.pop()
    return out


def _drop_collinear(pts):
    changed = True
    while changed and len(pts) > 3:
        changed = False
        for i in range(len(pts)):
            a = pts[i - 1]
            b = pts[i]
            c = pts[(i + 1) % len(pts)]
            cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
            if abs(cross) < 1e-7:
                del pts[i]
                changed = True
                break
    return pts


def polygon_area(pts):
    a = 0.0
    for i in range(len(pts)):
        x1, y1 = pts[i - 1]
        x2, y2 = pts[i]
        a += x1 * y2 - x2 * y1
    return abs(a) / 2.0


def clip_u(pts, u_lo, u_hi):
    """Clip a polygon to u_lo <= u <= u_hi (Sutherland-Hodgman)."""
    def clip(poly, inside, cross):
        out = []
        for i in range(len(poly)):
            cur = poly[i]
            prev = poly[i - 1]
            if inside(cur):
                if not inside(prev):
                    out.append(cross(prev, cur))
                out.append(cur)
            elif inside(prev):
                out.append(cross(prev, cur))
        return out

    def at_u(u):
        def cross(p, q):
            k = (u - p[0]) / (q[0] - p[0])
            return (u, p[1] + k * (q[1] - p[1]))
        return cross

    poly = clip(list(pts), lambda p: p[0] >= u_lo - EPS, at_u(u_lo))
    if poly:
        poly = clip(poly, lambda p: p[0] <= u_hi + EPS, at_u(u_hi))
    return poly


class StairGeometry(object):
    """
    Everything derived from a StairState: step sizes, the side profile,
    the three width zones and any validation problems.
    """

    CONCRETE_PCF = 150.0

    def __init__(self, st):
        self.st = st
        self.errors = []
        self.notes = []

        self.H = float(st.total_rise)
        self.L = float(st.total_run)
        self.n = st.risers()
        self.r = self.H / self.n if self.n else 0.0
        self.t = self.L / self.n if self.n else 0.0
        self.Db = max(0.0, float(st.bot_land_depth))
        self.Dt = max(0.0, float(st.top_land_depth))
        self.Tb = float(st.bot_land_thick)
        self.Tt = float(st.top_land_thick)
        self.w = float(st.waist)

        self._validate()
        self.profile = [] if self.errors else self._build_profile()
        if not self.errors and len(self.profile) < 3:
            self.errors.append("Could not build a valid stair profile.")

    # -----------------------------------------------------------------
    @property
    def angle(self):
        return math.degrees(math.atan2(self.H, self.L)) if self.L > EPS else 90.0

    @property
    def u0(self):
        return self.t - self.Db

    @property
    def u1(self):
        return self.L + self.Dt

    def _validate(self):
        st = self.st
        if self.H <= EPS:
            self.errors.append("Top pick must be higher than the bottom pick.")
        if self.L <= EPS:
            self.errors.append("The two picks must be apart in plan.")
        if self.w <= EPS:
            self.errors.append("Waist thickness must be greater than zero.")
        if float(st.stair_width) <= EPS:
            self.errors.append("Stair width must be greater than zero.")
        if self.Db > EPS:
            if self.Tb <= EPS:
                self.errors.append("Bottom landing thickness must be > 0.")
            if float(st.bot_land_width) <= EPS:
                self.errors.append("Bottom landing width must be > 0.")
        if self.Dt > EPS:
            if self.Tt <= EPS:
                self.errors.append("Top landing thickness must be > 0.")
            if float(st.top_land_width) <= EPS:
                self.errors.append("Top landing width must be > 0.")
        if self.errors:
            return
        if self.r > float(st.max_riser) + 1e-4:
            self.notes.append("Riser height exceeds the %s max riser."
                              % fmt_len(st.max_riser))
        if self.t < 11.0 - 1e-4:
            self.notes.append("Tread is less than 11\".")

    # -----------------------------------------------------------------
    def soffit(self, u):
        """Soffit line: waist below the throat, measured square to pitch."""
        return u * self.tan - self.K

    def _build_profile(self):
        n, r, t, L, H = self.n, self.r, self.t, self.L, self.H
        hyp = math.hypot(r, t)
        self.tan = r / t
        cos = t / hyp
        # vertical distance from the nosing line down to the soffit
        self.K = r + self.w / cos
        tan, K = self.tan, self.K
        Db, Dt, Tb, Tt = self.Db, self.Dt, self.Tb, self.Tt
        u0, u1 = self.u0, self.u1

        # Walking surface, downhill -> uphill
        up = []
        if Db > EPS:
            up.append((u0, 0.0))
        for i in range(1, n + 1):
            up.append((i * t, (i - 1) * r))
            up.append((i * t, i * r))
        if Dt > EPS:
            up.append((u1, H))

        # Underside, downhill -> uphill
        cut = -Tb if Db > EPS else 0.0     # bearing plane at the bottom
        low = []
        if Db > EPS:
            low.append((u0, -Tb))
            low.append((t, -Tb))
        low.append((t, max(self.soffit(t), cut)))
        u_c = (cut + K) / tan
        if t + EPS < u_c < L - EPS:
            low.append((u_c, cut))
        low.append((L, max(self.soffit(L), cut)))
        if Dt > EPS:
            top_bot = H - Tt
            low.append((L, min(max(self.soffit(L), cut), top_bot)))
            u_t = (top_bot + K) / tan
            if L + EPS < u_t < u1 - EPS:
                low.append((u_t, top_bot))
            low.append((u1, min(self.soffit(u1), top_bot)))

        pts = _dedupe(up + list(reversed(low)))
        return _drop_collinear(pts)

    # -----------------------------------------------------------------
    def zones(self):
        """[(name, u_lo, u_hi, width)] for each piece of the stair."""
        st = self.st
        out = []
        if self.Db > EPS:
            out.append(("bottom landing", self.u0, self.t,
                        float(st.bot_land_width)))
        out.append(("flight", self.t, self.L, float(st.stair_width)))
        if self.Dt > EPS:
            out.append(("top landing", self.L, self.u1,
                        float(st.top_land_width)))
        return out

    def max_width(self):
        return max(z[3] for z in self.zones())

    def plate_z_range(self):
        return z_range(self.max_width(), self.st.ref_face)

    def excess_cuts(self):
        """
        Pieces to trim off the full-width extrusion: [(zone, u_lo, u_hi,
        z_lo, z_hi)]. Empty when every zone is the same width.
        """
        pz0, pz1 = self.plate_z_range()
        out = []
        for name, ua, ub, width in self.zones():
            z0, z1 = z_range(width, self.st.ref_face)
            if z0 > pz0 + EPS:
                out.append((name, ua, ub, pz0, z0))
            if z1 < pz1 - EPS:
                out.append((name, ua, ub, z1, pz1))
        return out

    def volume_cf(self):
        vol = 0.0
        for _name, ua, ub, width in self.zones():
            part = clip_u(self.profile, ua, ub)
            if len(part) >= 3:
                vol += polygon_area(part) * width
        return vol / 1728.0

    def weight_lb(self):
        return self.volume_cf() * self.CONCRETE_PCF

    def v_extents(self):
        vs = [p[1] for p in self.profile] or [0.0]
        return min(vs), max(vs)


# ---------------------------------------------------------------------------
# Imperial formatting / parsing (same conventions as JBSimpleLadder)
# ---------------------------------------------------------------------------
def fmt_len(value, denom=None):
    """Decimal inches -> feet-inch-fraction string."""
    v = abs(float(value))
    if denom is None:
        denom = 16
        for d in (16, 32, 64, 128):
            if abs(v * d - round(v * d)) < 1e-9:
                denom = d
                break
        else:
            denom = 16

    neg = value < 0
    total = int(round(v * denom))
    whole_in = total // denom
    num = total - whole_in * denom
    ft = whole_in // 12
    inch = whole_in - ft * 12

    while num and num % 2 == 0:
        num //= 2
        denom //= 2

    parts = []
    if ft:
        parts.append("%d'" % ft)
    if inch or num or not ft:
        frac = ""
        if num:
            frac = " %d/%d" % (num, denom) if inch else "%d/%d" % (num, denom)
        if inch:
            parts.append('%s%d%s"' % ("-" if ft else "", inch, frac))
        elif num:
            parts.append('%s%s"' % ("-" if ft else "", frac))
        else:
            parts.append('%s0"' % ("-" if ft else ""))
    s = "".join(parts)
    return ("-" + s) if neg and s != '0"' else s


_FRAC_RE = re.compile(r"^(\d+)\s*/\s*(\d+)$")


def parse_len(text, default=0.0):
    """
    SDS2-style dimension string -> decimal inches.
    18 | 18.5 | 3/4 | 6 1/2 | 1-6 | 5'-6" | 2'
    """
    if text is None:
        return default
    s = str(text).strip()
    if not s:
        return default
    s = s.replace("+", " ")
    had_foot_mark = "'" in s
    s = s.replace('"', "").replace("''", "")

    neg = s.startswith("-")
    if neg:
        s = s[1:].strip()

    feet = 0.0
    inch_part = s
    if had_foot_mark:
        head, _, tail = s.partition("'")
        try:
            feet = float(head.strip())
        except ValueError:
            return default
        inch_part = tail.strip().lstrip("-").strip()
    else:
        head, sep, tail = s.partition("-")
        head, tail = head.strip(), tail.strip()
        if sep and tail and head and _is_number(head):
            feet = float(head)
            inch_part = tail

    inches = _parse_inch_expr(inch_part)
    if inches is None:
        return default
    val = feet * 12.0 + inches
    return -val if neg else val


def _is_number(tok):
    try:
        float(tok)
        return True
    except ValueError:
        return False


def _parse_inch_expr(text):
    if not text:
        return 0.0
    total = 0.0
    saw = False
    for tok in text.replace("-", " ").split():
        m = _FRAC_RE.match(tok)
        if m:
            d = float(m.group(2))
            if d == 0:
                return None
            total += float(m.group(1)) / d
            saw = True
            continue
        try:
            total += float(tok)
            saw = True
        except ValueError:
            return None
    return total if saw else 0.0
