"""
=============================================================================
JBPrecastStair
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

"""
=============================================================================
 JBPrecastStair - StairBuild
=============================================================================
 Builds the stair as ONE flat plate layout:

   * the side profile (StairGeometry.profile) is laid out in the vertical
     plane of the nosing line, shifted across the stair so the plate's
     centre plane sits in the middle of the widest zone
   * the plate thickness is that widest width, origin "Center" - so the
     result never depends on which way SDS2 decides the plate normal is
   * any zone (bottom landing / flight / top landing) narrower than the
     widest is trimmed with a symmetric MtrlCut, so the piece stays one
     material

 SDS2 Python has no Reference Material class (it only exists in the .NET
 API as ReferenceObjectAreaLayout), hence the plate layout.

 Member axes: x runs bottom pick -> top pick along the nosing line,
 z = horizontal(x) cross global up. +z is the member near side (NS).
=============================================================================
"""

import datetime
import math
import os

from StairState import StairGeometry, fmt_len

try:
    import param
    from Point3D import Point3D
    from point import Point
    from member import Member
    from job import Job
    HAVE_SDS2 = True
except ImportError:                                   # pragma: no cover
    HAVE_SDS2 = False

try:
    import plate_layout as _plate_layout_mod
except ImportError:                                   # pragma: no cover
    _plate_layout_mod = None
try:
    import Designable.Proxies as DP
except ImportError:                                   # pragma: no cover
    DP = None
try:
    from mtrl_cut import MtrlCut
except ImportError:                                   # pragma: no cover
    MtrlCut = None


USAGE = "Precast Stair"
CONCRETE_COLOR = (175, 175, 170)


class BuildLog(object):
    def __init__(self):
        self.lines = []
        self.warnings = []

    def info(self, msg):
        self.lines.append(msg)

    def warn(self, msg):
        self.lines.append("WARNING: " + msg)
        self.warnings.append(msg)

    def write_file(self):
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "JBPrecastStair_last_build.log")
        try:
            with open(path, "w") as fh:
                fh.write("JBPrecastStair build  %s\n\n"
                         % datetime.datetime.now().isoformat())
                fh.write("\n".join(self.lines))
                fh.write("\n")
            return path
        except Exception:
            return None


def _set(obj, name, value, log=None):
    """setattr that never takes the build down over one attribute."""
    try:
        setattr(obj, name, value)
        return True
    except Exception as exc:
        if log is not None:
            log.info("  (could not set %s=%r: %s)" % (name, value, exc))
        return False


class StairBuilder(object):

    def __init__(self, model, state):
        self.model = model
        self.state = state
        self.log = BuildLog()
        self.plate = None

    # -----------------------------------------------------------------
    def read_ends(self):
        """Bottom/top picks from the member ends; fills rise and run."""
        a = self.model.GetLeftLocation()
        b = self.model.GetRightLocation()
        if a.z > b.z:
            a, b = b, a
        self.B = (a.x, a.y, a.z)
        dx, dy = b.x - a.x, b.y - a.y
        run = math.hypot(dx, dy)
        self.state.total_rise = b.z - a.z
        self.state.total_run = run
        if run > 1e-6:
            self.d = (dx / run, dy / run)
        else:
            self.d = (1.0, 0.0)
        # member +z (near side) = horizontal x cross global up
        self.zax = (self.d[1], -self.d[0])

    def glob(self, u, v, z):
        """Stair (u, v, z) -> global (x, y, z) tuple."""
        return (self.B[0] + u * self.d[0] + z * self.zax[0],
                self.B[1] + u * self.d[1] + z * self.zax[1],
                self.B[2] + v)

    # -----------------------------------------------------------------
    def generate(self):
        if not HAVE_SDS2:
            self.log.warn("SDS2 unavailable - dry run")
            return False

        self.read_ends()
        g = StairGeometry(self.state)
        self.geom = g
        self._describe(g)
        if g.errors:
            for e in g.errors:
                self.log.warn(e)
            return False

        self.mem = Member(self.model.GetMemberNumber())
        z0, z1 = g.plate_z_range()
        zc = (z0 + z1) / 2.0
        pts = [self.glob(u, v, zc) for (u, v) in g.profile]
        self.plate = self._plate_layout(pts, z1 - z0)
        if self.plate is None:
            return False

        for zone, ua, ub, za, zb in g.excess_cuts():
            self._trim(g, zone, ua, ub, za, zb)
        return True

    def _describe(self, g):
        st = self.state
        self.log.info("Rise %s   Run %s   Angle %.2f deg"
                      % (fmt_len(g.H), fmt_len(g.L), g.angle))
        if g.errors:
            return
        self.log.info("Risers %d @ %s   Treads %d @ %s"
                      % (g.n, fmt_len(g.r), g.n - 1, fmt_len(g.t)))
        self.log.info("Waist %s   Stair width %s   Ref face %s"
                      % (fmt_len(st.waist), fmt_len(st.stair_width),
                         st.ref_face))
        for name, ua, ub, width in g.zones():
            self.log.info("  zone %-15s u %8.3f .. %8.3f  width %s"
                          % (name, ua, ub, fmt_len(width)))
        self.log.info("Profile points (u, v):")
        for p in g.profile:
            self.log.info("  (%.4f, %.4f)" % p)
        self.log.info("Approx. concrete %.2f cf / %.0f lb"
                      % (g.volume_cf(), g.weight_lb()))
        for n in g.notes:
            self.log.info("NOTE: " + n)

    # -----------------------------------------------------------------
    def _grade(self):
        try:
            grades = list(Job().steel_grades("Plate").keys())
            return grades[0] if grades else ""
        except Exception:
            return ""

    def _plate_layout(self, pts, thick):
        """
        The legacy plate_layout.PlateLayout is tried first (snake_case,
        same pattern as SDS2's Tapered_Member macro) because MtrlCut can
        only target a legacy material object. Designable.Proxies is the
        fallback - it builds the same piece but cannot be trimmed.
        """
        if _plate_layout_mod is not None:
            try:
                p = _plate_layout_mod.PlateLayout()
                p.member = self.mem
                for xyz in pts:
                    p.pts.append((Point(Point3D(*xyz)), 0.0))
                p.pts.append((Point(Point3D(*pts[0])), 0.0))
                _set(p, "grade", self._grade(), self.log)
                p.origin = "Center"
                for op in ("top_oper_left", "top_oper_right",
                           "bottom_oper_left", "bottom_oper_right"):
                    _set(p, op, "None", self.log)
                p.thick = thick
                _set(p, "mtrl_type", "Flat pl layout", self.log)
                _set(p, "mtrl_usage", USAGE, self.log)
                _set(p, "mtrl_is_main", "Yes", self.log)
                _set(p, "finish", "None", self.log)
                _set(p, "color", CONCRETE_COLOR, self.log)
                _set(p, "ref_pt_offset", (0.0, 0.0, 0.0), self.log)
                p.add()
                try:
                    p.rotate(p.member, (0.0, 0.0, 0.0))
                except Exception as exc:
                    self.log.info("  (rotate skipped: %s)" % exc)
                self.log.info("Plate created via plate_layout.PlateLayout "
                              "(thick %s)" % fmt_len(thick))
                return p
            except Exception as exc:
                self.log.warn("plate_layout.PlateLayout failed: %s" % exc)

        if DP is not None and hasattr(DP, "PlateLayout"):
            closed = list(pts) + [pts[0]]
            kwargs = {
                "Member": self.mem,
                "MaterialOriginPoint": "Center",
                "Thickness": thick,
                "MaterialUsageDescription": USAGE,
                "mtrl_is_main": "Yes",
                "MaterialGrade": self._grade(),
                "pts": [(xyz, 0.0) for xyz in closed],
            }
            for extra in ({"MaterialColor3d": CONCRETE_COLOR}, {}):
                try:
                    p = DP.PlateLayout(**dict(kwargs, **extra))
                    p.Execute()
                    self.log.info("Plate created via "
                                  "Designable.Proxies.PlateLayout")
                    return p
                except Exception as exc:
                    last = exc
            self.log.warn("Designable.Proxies.PlateLayout failed: %s" % last)

        self.log.warn("No working plate layout API - stair not built.")
        return None

    # -----------------------------------------------------------------
    def _trim(self, g, zone, ua, ub, za, zb):
        """
        Remove z = za..zb over u = ua..ub. The cut outline is a rectangle
        in the profile plane, placed midway across the strip and cut
        equally both ways, so the in/out direction of the cut does not
        matter.
        """
        if MtrlCut is None:
            self.log.warn("MtrlCut unavailable - %s left full width" % zone)
            return
        # Run the strip past the free ends of the piece, but stop exactly
        # at the riser faces between zones.
        if abs(ua - g.u0) < 1e-6 or (zone == "flight" and g.Db < 1e-6):
            ua -= 1.0
        if abs(ub - g.u1) < 1e-6 or (zone == "flight" and g.Dt < 1e-6):
            ub += 1.0
        # Past the outside of the plate as well.
        pz0, pz1 = g.plate_z_range()
        if za <= pz0 + 1e-6:
            za -= 1.0
        if zb >= pz1 - 1e-6:
            zb += 1.0
        vlo, vhi = g.v_extents()
        vlo -= 12.0
        vhi += 12.0
        zm = (za + zb) / 2.0
        half = (zb - za) / 2.0
        rect = [(ua, vlo), (ub, vlo), (ub, vhi), (ua, vhi)]
        try:
            mc = MtrlCut()
            mc.mtrl = [self.plate]
            mc.rotate = (0.0, 0.0, 0.0)
            for (u, v) in rect:
                mc.pts.append((Point(Point3D(*self.glob(u, v, zm))), 0.0))
            mc.DepthIn = half
            mc.DepthOut = half
            mc.cut("Layout")
            self.log.info("Trimmed %s: z %.3f .. %.3f" % (zone, za, zb))
        except Exception as exc:
            self.log.warn("Trim of %s failed (%s) - left full width"
                          % (zone, exc))
