Bundled third-party software: PySide6 6.8.3 (Qt for Python)
============================================================

This folder contains an unmodified, trimmed copy of the following packages,
taken from the official PyPI wheels:

  PySide6_Essentials 6.8.3  (PySide6_Essentials-6.8.3-cp39-abi3-win_amd64.whl)
  shiboken6 6.8.3           (shiboken6-6.8.3-cp39-abi3-win_amd64.whl)

Copyright (C) The Qt Company Ltd. and other contributors.
Licensed under the GNU Lesser General Public License v3.0
(see LICENSE.LGPL-3.0.txt and LICENSE.GPL-3.0.txt in this folder).
Source code: https://code.qt.io/cgit/pyside/pyside-setup.git/ (tag v6.8.3)
             https://download.qt.io/official_releases/QtForPython/

Only the QtCore, QtGui and QtWidgets modules and the Qt plugins they need
were kept. No files were modified.

Qt itself includes third-party components (for example zlib, libpng and
FreeType), each under its own license. The Qt Company lists them, with
their license texts, at:
  https://doc.qt.io/qt-6/licenses-used-in-qt.html

These files are not covered by the JB Detailing plugins' terms of use.

Replacing this copy
-------------------
SDS2 does not ship PySide6. The JB Detailing plugins load it from here
unless the user has already installed PySide6 into SDS2's Python, in
which case that installed copy is used instead. You may replace this folder's PySide6 and
shiboken6 directories with any compatible PySide6 6.x build (for example,
by extracting newer wheels here), or delete this folder and install
PySide6 into SDS2's Python yourself.
