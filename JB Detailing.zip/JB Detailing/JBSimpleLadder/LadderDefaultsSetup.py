"""
=============================================================================
JBSimpleLadder
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

"""
=============================================================================
 JB Simple Ladder - Job Defaults  (SDS2 macro)
=============================================================================
 Run this to choose what a NEW ladder starts out as in this job.

 It opens the normal ladder editor loaded with the job's current
 defaults; pressing "Save Defaults" stores them, and every ladder placed
 afterwards opens pre-filled with them. Ladders already in the job are
 not touched.

 Placement values - elevations, rotation, pick mode, the intermediate
 elevation list - are not saved as defaults, since those describe where
 one particular ladder is rather than how ladders in this job should be
 built.

 To run it: Home > Macros (or the macro toolbar), pick this file. It can
 also be copied into the shared macro folder alongside the other JBTools
 macros if you want it on the menu permanently.

 This is deliberately a macro rather than an entry in SDS2's Plugin
 Setup menu - see LadderDefaults.py for why.
=============================================================================
"""

import os
import sys

# The defaults module lives next to this file, in the plugin folder. Add
# that folder to the path so this macro works no matter where it is run
# from.
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)


def _add_picker_path():
    """Put the folder holding JBMaterialPicker.py on sys.path so the
    section pickers work on any machine: beside this plugin, then the
    shared copy in JB Detailing\\_shared, then an SDS2 macro\\JBTools or
    macro\\Jason folder (where it lived before it shipped with the
    plugins)."""
    shared = os.path.join(os.path.dirname(_HERE), "_shared")
    if os.path.isfile(os.path.join(shared, "JBShared.py")):
        # The shipped copy always wins - first on sys.path, and any copy
        # already loaded from elsewhere is dropped (see JBShared.py).
        if shared in sys.path:
            sys.path.remove(shared)
        sys.path.insert(0, shared)
        try:
            import JBShared
            JBShared.prefer_shared()
            return
        except Exception:
            pass
    folders = [_HERE, shared]
    for pd in (r"C:\ProgramData", r"D:\ProgramData"):
        try:
            installs = sorted(os.listdir(pd), reverse=True)
        except OSError:
            continue
        for name in installs:
            if name.upper().startswith("SDS2_"):
                folders.append(os.path.join(pd, name, "macro", "JBTools"))
                folders.append(os.path.join(pd, name, "macro", "Jason"))
    for folder in folders:
        if os.path.isfile(os.path.join(folder, "JBMaterialPicker.py")):
            if folder not in sys.path:
                sys.path.append(folder)
            return


_add_picker_path()


def _ensure_pyside6():
    """Make PySide6 importable without the user installing it.

    SDS2 does not ship PySide6. If the user has installed it into SDS2's
    Python themselves, use that copy, since loading a second set of Qt DLLs
    into the same process crashes. Otherwise
    fall back to the copy bundled in _vendor, either beside this plugin or
    one folder up when the JB Detailing plugins are shipped together."""
    import importlib.util
    if importlib.util.find_spec("PySide6") is not None:
        return
    for vendor in (os.path.join(_HERE, "_vendor"),
                   os.path.join(os.path.dirname(_HERE), "_vendor")):
        if os.path.isdir(os.path.join(vendor, "PySide6")):
            if vendor not in sys.path:
                sys.path.append(vendor)
            return


_ensure_pyside6()


def main():
    try:
        from LadderDefaults import edit_defaults
    except Exception as exc:
        _warn("JB Simple Ladder: could not load the defaults module:\n%s"
              % exc)
        return

    try:
        saved = edit_defaults()
    except Exception as exc:
        _warn("JB Simple Ladder: the defaults editor failed:\n%s" % exc)
        return

    if saved:
        _warn("JB Simple Ladder: job defaults saved. New ladders placed in "
              "this job will start from these settings.")


def _warn(msg):
    """Tell the user through SDS2 when it is available, otherwise print -
    so the macro is still runnable outside SDS2 for testing."""
    try:
        import param
        param.Warning(msg)
    except Exception:
        print(msg)


main()
