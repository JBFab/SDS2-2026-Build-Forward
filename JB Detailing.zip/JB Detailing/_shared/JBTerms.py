"""
=============================================================================
JBTerms
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

"""
=============================================================================
 JB Terms  -  one-time acceptance of the JB Detailing Terms of Use
=============================================================================
 Every JB Detailing plugin calls ensure_accepted() before it opens its
 dialog. The first time a Windows user does that, they are shown the key
 points and the full LICENSE.txt and must tick "I accept". Acceptance is
 recorded in %APPDATA%\\JB Detailing\\terms_accepted.json against a
 fingerprint of LICENSE.txt, so they are asked again only when the terms
 change.

 Only interactive entry points call this. Model regeneration
 (CreateMaterial) never does, so a job always processes on a machine
 where nobody has accepted the terms.
=============================================================================
"""

import datetime
import getpass
import hashlib
import json
import os
import platform

_HERE = os.path.dirname(os.path.abspath(__file__))
LICENSE_PATH = os.path.join(os.path.dirname(_HERE), "LICENSE.txt")

SUMMARY = [
    "These tools are drafting and modeling aids. They do not perform "
    "engineering or verify code compliance. Code warnings are advisory "
    "only.",
    "You are responsible for checking all output before it is used for "
    "approval, fabrication or erection, and for review by the engineer of "
    "record where required.",
    "The software is provided AS IS, with no warranty of any kind. The "
    "author accepts no liability for any damages arising from its use.",
    "Back up your jobs before use, and test new versions before using "
    "them on production work.",
]

# Accepted in this SDS2 session even if the record could not be saved.
_session_ok = set()


def _store_path():
    """Where acceptance is recorded (JB_TERMS_STORE overrides, for tests)."""
    override = os.environ.get("JB_TERMS_STORE")
    if override:
        return override
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "JB Detailing", "terms_accepted.json")


def terms_text():
    """The full terms, or None if LICENSE.txt is missing."""
    try:
        with open(LICENSE_PATH, encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


def fingerprint(text):
    """Identify a version of the terms; line endings don't count."""
    norm = (text or "\n".join(SUMMARY)).replace("\r\n", "\n").strip()
    return hashlib.sha256(norm.encode("utf-8")).hexdigest()[:16]


def _load():
    try:
        with open(_store_path(), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def is_accepted(fp=None):
    if fp is None:
        fp = fingerprint(terms_text())
    if fp in _session_ok:
        return True
    return any(r.get("terms") == fp for r in _load().get("accepted", []))


def _record(fp, plugin):
    _session_ok.add(fp)
    data = _load()
    data.setdefault("accepted", []).append({
        "terms": fp,
        "user": getpass.getuser(),
        "computer": platform.node(),
        "plugin": plugin,
        "date": datetime.datetime.now().isoformat(timespec="seconds"),
    })
    path = _store_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass    # still accepted for this session


def ensure_accepted(plugin="JB Detailing", parent=None):
    """True if the current user has accepted the current terms, asking
    them first if needed. False if they decline."""
    text = terms_text()
    fp = fingerprint(text)
    if is_accepted(fp):
        return True
    if not _ask(plugin, text, parent):
        return False
    _record(fp, plugin)
    return True


def _ask(plugin, text, parent):
    from PySide6 import QtCore, QtGui, QtWidgets

    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

    dlg = QtWidgets.QDialog(parent)
    dlg.setWindowTitle("JB Detailing - Terms of Use")
    dlg.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
    dlg.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose, False)
    dlg.resize(680, 620)
    lay = QtWidgets.QVBoxLayout(dlg)

    head = QtWidgets.QLabel(
        "Before using %s, please read and accept the JB Detailing "
        "Terms of Use." % plugin)
    head.setWordWrap(True)
    f = head.font()
    f.setBold(True)
    head.setFont(f)
    lay.addWidget(head)

    points = QtWidgets.QLabel(
        "<ul style='margin-left:-20px'>%s</ul>"
        % "".join("<li style='margin-bottom:4px'>%s</li>" % p
                  for p in SUMMARY))
    points.setWordWrap(True)
    points.setTextFormat(QtCore.Qt.TextFormat.RichText)
    lay.addWidget(points)

    lay.addWidget(QtWidgets.QLabel("Full terms:"))
    full = QtWidgets.QPlainTextEdit()
    full.setReadOnly(True)
    full.setPlainText(text or "LICENSE.txt was not found in the JB Detailing "
                      "folder. The key points above still apply.")
    full.setFont(QtGui.QFontDatabase.systemFont(
        QtGui.QFontDatabase.SystemFont.FixedFont))
    lay.addWidget(full, 1)

    check = QtWidgets.QCheckBox("I have read and accept these terms")
    lay.addWidget(check)

    note = QtWidgets.QLabel("You will only be asked again if the terms "
                            "change.")
    note.setEnabled(False)
    lay.addWidget(note)

    buttons = QtWidgets.QDialogButtonBox()
    accept = buttons.addButton(
        "Accept", QtWidgets.QDialogButtonBox.ButtonRole.AcceptRole)
    buttons.addButton(
        "Decline", QtWidgets.QDialogButtonBox.ButtonRole.RejectRole)
    accept.setEnabled(False)
    check.toggled.connect(accept.setEnabled)
    buttons.accepted.connect(dlg.accept)
    buttons.rejected.connect(dlg.reject)
    lay.addWidget(buttons)

    # Same modal pattern as the plugin dialogs: drive our own loop rather
    # than exec(), which misbehaves when SDS2 already has a loop running.
    loop = QtCore.QEventLoop()
    outcome = {"code": None}

    def _finished(code):
        outcome["code"] = code
        loop.quit()

    dlg.finished.connect(_finished)
    dlg.show()
    dlg.raise_()
    dlg.activateWindow()
    app.processEvents()
    if outcome["code"] is None and not dlg.isVisible():
        dlg.show()
        app.processEvents()
    if outcome["code"] is None:
        loop.exec()

    code = outcome["code"]
    if code is None:
        code = dlg.result()
    dlg.deleteLater()
    app.processEvents()
    return code == QtWidgets.QDialog.DialogCode.Accepted
