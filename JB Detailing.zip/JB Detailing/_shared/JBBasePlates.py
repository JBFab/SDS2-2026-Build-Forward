"""
=============================================================================
JBBasePlates
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

"""
=============================================================================
 JB Base Plates  -  a table of standard base / mounting plates
=============================================================================
 Kept per PC in %APPDATA%\\JB Detailing\\base_plates.json, so the same
 table is there in every job; import / export share it between PCs.
 Any JB member can use it (the railing does now).

 A plate:
   name, shape ("Rectangular" | "Round"),
   length, width (rectangular) or diameter (round), thick, corner_radius,
   holes: pattern ("4 corners" | "2 along length" | "2 across" |
          "Bolt circle" | "None"), edge (in from the edges), bolt_circle
          (diameter, round plates), count (bolt circle), dia (hole),
   anchor  BOM text for the anchors (information only - not modeled)

 hole_points() gives the hole centres in the plate's own (length, width)
 frame, centred on the plate.

 edit_library(parent) opens the editor (PySide6, imported lazily).
=============================================================================
"""

import copy
import json
import math
import os

STORE_VERSION = 1


class Shape:
    RECT = "Rectangular"
    ROUND = "Round"
    ALL = (RECT, ROUND)


class Pattern:
    CORNERS = "4 corners"
    ALONG = "2 along length"
    ACROSS = "2 across"
    CIRCLE = "Bolt circle"
    NONE = "None"
    ALL = (CORNERS, ALONG, ACROSS, CIRCLE, NONE)


def plate(name, shape=Shape.RECT, length=6.0, width=6.0, diameter=6.0,
          thick=0.5, corner_radius=0.0, pattern=Pattern.CORNERS, edge=1.25,
          bolt_circle=4.5, count=4, dia=0.8125, anchor='3/4" ANCHOR'):
    return {"name": name, "shape": shape, "length": length, "width": width,
            "diameter": diameter, "thick": thick,
            "corner_radius": corner_radius,
            "holes": {"pattern": pattern, "edge": edge,
                      "bolt_circle": bolt_circle, "count": count,
                      "dia": dia},
            "anchor": anchor}


DEFAULTS = [
    plate('PL 6x6x1/2 - 4 holes', length=6.0, width=6.0, thick=0.5),
    plate('PL 5x5x3/8 - 4 holes', length=5.0, width=5.0, thick=0.375,
          edge=1.0, dia=0.6875, anchor='5/8" ANCHOR'),
    plate('PL 8x4x1/2 - 2 holes', length=8.0, width=4.0, thick=0.5,
          pattern=Pattern.ALONG),
    plate('PL 6 dia x 1/2 - 4 holes', shape=Shape.ROUND, diameter=6.0,
          thick=0.5, pattern=Pattern.CIRCLE, bolt_circle=4.5, count=4),
    plate('PL 4-1/2 dia x 3/8 - 3 holes', shape=Shape.ROUND, diameter=4.5,
          thick=0.375, pattern=Pattern.CIRCLE, bolt_circle=3.25, count=3,
          dia=0.5625, anchor='1/2" ANCHOR'),
]


def normalize(p):
    out = plate(str((p or {}).get("name") or "Unnamed"))
    if not isinstance(p, dict):
        return out
    if p.get("shape") in Shape.ALL:
        out["shape"] = p["shape"]
    for k in ("length", "width", "diameter", "thick", "corner_radius"):
        try:
            out[k] = float(p.get(k, out[k]))
        except (TypeError, ValueError):
            pass
    if p.get("anchor") is not None:
        out["anchor"] = str(p["anchor"])
    h = p.get("holes") if isinstance(p.get("holes"), dict) else {}
    if h.get("pattern") in Pattern.ALL:
        out["holes"]["pattern"] = h["pattern"]
    for k in ("edge", "bolt_circle", "dia"):
        try:
            out["holes"][k] = float(h.get(k, out["holes"][k]))
        except (TypeError, ValueError):
            pass
    try:
        out["holes"]["count"] = max(1, int(h.get("count", 4)))
    except (TypeError, ValueError):
        pass
    return out


def size(p):
    """(length, width) - a round plate's diameter both ways."""
    if p["shape"] == Shape.ROUND:
        return p["diameter"], p["diameter"]
    return p["length"], p["width"]


def hole_points(p):
    """Hole centres (along length, along width), plate-centred."""
    h = p["holes"]
    L, W = size(p)
    e = h["edge"]
    pat = h["pattern"]
    if pat == Pattern.NONE:
        return []
    if pat == Pattern.CIRCLE or p["shape"] == Shape.ROUND:
        n = max(1, int(h["count"]))
        r = h["bolt_circle"] / 2.0
        return [(r * math.cos(2 * math.pi * k / n + math.pi / n),
                 r * math.sin(2 * math.pi * k / n + math.pi / n))
                for k in range(n)]
    a, b = L / 2.0 - e, W / 2.0 - e
    if pat == Pattern.ALONG:
        return [(-a, 0.0), (a, 0.0)]
    if pat == Pattern.ACROSS:
        return [(0.0, -b), (0.0, b)]
    return [(-a, -b), (a, -b), (a, b), (-a, b)]


def problem(p):
    """A message if the plate can't be built, else None."""
    L, W = size(p)
    if min(L, W, p["thick"]) <= 0:
        return "%s: size and thickness must be positive" % p["name"]
    for x, y in hole_points(p):
        r = p["holes"]["dia"] / 2.0
        if p["shape"] == Shape.ROUND:
            if math.hypot(x, y) + r > p["diameter"] / 2.0 + 1e-6:
                return "%s: a hole runs off the plate" % p["name"]
        elif abs(x) + r > L / 2.0 + 1e-6 or abs(y) + r > W / 2.0 + 1e-6:
            return "%s: a hole runs off the plate" % p["name"]
    return None


def label(p):
    if not p:
        return "(none)"
    L, W = size(p)
    from_units = _fmt
    dims = ("%s dia" % from_units(L)) if p["shape"] == Shape.ROUND else \
        "%s x %s" % (from_units(L), from_units(W))
    n = len(hole_points(p))
    return "%s x %s, %d hole(s)" % (dims, from_units(p["thick"]), n)


def _fmt(v):
    try:
        from RailingUnits import fmt_len
        return fmt_len(v)
    except Exception:
        return '%.4g"' % v


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------
def store_path():
    override = os.environ.get("JB_BASE_PLATES")
    if override:
        return override
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "JB Detailing", "base_plates.json")


def load():
    """The library, seeded with DEFAULTS the first time."""
    try:
        with open(store_path(), encoding="utf-8") as f:
            d = json.load(f)
        plates = [normalize(p) for p in d.get("plates", [])]
        if plates:
            return plates
    except (OSError, ValueError, AttributeError):
        pass
    return copy.deepcopy(DEFAULTS)


def save(plates):
    path = store_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"version": STORE_VERSION,
                       "plates": [normalize(p) for p in plates]}, f,
                      indent=1, sort_keys=True)
        return True
    except OSError:
        return False


def find(name, plates=None):
    for p in plates if plates is not None else load():
        if p["name"] == name:
            return p
    return None


def names():
    return [p["name"] for p in load()]


def export_to(path, plates=None):
    plates = plates if plates is not None else load()
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"jb_base_plates": STORE_VERSION, "plates": plates}, f,
                  indent=1, sort_keys=True)
    return len(plates)


def import_from(path):
    """Add (or replace by name) the plates in an exported file."""
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    incoming = [normalize(p) for p in d.get("plates", [])]
    plates = [p for p in load()
              if p["name"] not in {q["name"] for q in incoming}]
    plates.extend(incoming)
    save(plates)
    return len(incoming)


# ---------------------------------------------------------------------------
# Editor
# ---------------------------------------------------------------------------
COLUMNS = [("name", "Name", "text"), ("shape", "Shape", Shape.ALL),
           ("length", "Length", "len"), ("width", "Width", "len"),
           ("diameter", "Diameter", "len"), ("thick", "Thick", "len"),
           ("corner_radius", "Corner R", "len"),
           ("holes.pattern", "Holes", Pattern.ALL),
           ("holes.edge", "Edge dist", "len"),
           ("holes.bolt_circle", "Bolt circle", "len"),
           ("holes.count", "Count", "int"), ("holes.dia", "Hole dia", "len"),
           ("anchor", "Anchor (BOM)", "text")]


def _get(p, key):
    a, _, b = key.partition(".")
    return p[a][b] if b else p[a]


def _set(p, key, v):
    a, _, b = key.partition(".")
    if b:
        p[a][b] = v
    else:
        p[a] = v


def edit_library(parent=None, style=""):
    """Open the editor; True if saved."""
    from PySide6 import QtCore, QtWidgets
    try:
        from RailingUnits import fmt_len, parse_len
    except Exception:
        fmt_len = _fmt

        def parse_len(t, d=None):
            try:
                return float(t)
            except ValueError:
                return d

    plates = load()
    dlg = QtWidgets.QDialog(parent)
    dlg.setWindowTitle("JB Base Plate Library")
    if style:
        dlg.setStyleSheet(style)
    dlg.resize(1180, 460)
    v = QtWidgets.QVBoxLayout(dlg)
    note = QtWidgets.QLabel(
        "Standard base and mounting plates - saved on this PC and available "
        "in every job. Round plates use the diameter and a bolt circle; "
        "rectangular plates use the length (along the post's depth), width "
        "and the edge distance. Anchors are BOM text only.")
    note.setWordWrap(True)
    note.setObjectName("Sub")
    v.addWidget(note)
    table = QtWidgets.QTableWidget(0, len(COLUMNS))
    table.setHorizontalHeaderLabels([c[1] for c in COLUMNS])
    table.horizontalHeader().setSectionResizeMode(
        QtWidgets.QHeaderView.ResizeMode.Interactive)
    table.setColumnWidth(0, 200)
    v.addWidget(table, 1)
    msg = QtWidgets.QLabel("")
    msg.setObjectName("Issue")
    v.addWidget(msg)

    def fill():
        table.blockSignals(True)
        table.setRowCount(len(plates))
        for r, p in enumerate(plates):
            for c, (key, _lab, kind) in enumerate(COLUMNS):
                val = _get(p, key)
                if isinstance(kind, tuple):
                    box = QtWidgets.QComboBox()
                    box.addItems(kind)
                    box.setCurrentText(val)
                    box.currentTextChanged.connect(
                        lambda t, row=r, k=key: (_set(plates[row], k, t),
                                                 check()))
                    table.setCellWidget(r, c, box)
                    continue
                txt = fmt_len(val) if kind == "len" else str(val)
                table.setItem(r, c, QtWidgets.QTableWidgetItem(txt))
        table.blockSignals(False)
        check()

    def check():
        probs = [problem(normalize(p)) for p in plates]
        probs = [x for x in probs if x]
        names_ = [p["name"] for p in plates]
        if len(set(names_)) != len(names_):
            probs.append("two plates have the same name")
        msg.setText("  |  ".join(probs))
        return not probs

    def changed(item):
        r, c = item.row(), item.column()
        key, _lab, kind = COLUMNS[c]
        txt = item.text().strip()
        if kind == "len":
            val = parse_len(txt, None)
            if val is None:
                val = _get(plates[r], key)
        elif kind == "int":
            try:
                val = max(1, int(float(txt)))
            except ValueError:
                val = _get(plates[r], key)
        else:
            val = txt
        _set(plates[r], key, val)
        fill()

    table.itemChanged.connect(changed)
    row = QtWidgets.QHBoxLayout()

    def add():
        plates.append(plate("New plate %d" % (len(plates) + 1)))
        fill()
        table.selectRow(len(plates) - 1)

    def copy_row():
        r = table.currentRow()
        if 0 <= r < len(plates):
            q = copy.deepcopy(plates[r])
            q["name"] += " copy"
            plates.insert(r + 1, q)
            fill()

    def delete():
        r = table.currentRow()
        if 0 <= r < len(plates) and len(plates) > 1:
            del plates[r]
            fill()

    def do_import():
        path, _f = QtWidgets.QFileDialog.getOpenFileName(
            dlg, "Import Base Plates", "", "Base plates (*.json)")
        if path:
            try:
                import_from(path)
            except Exception as exc:
                QtWidgets.QMessageBox.warning(dlg, "Import", str(exc))
                return
            plates[:] = load()
            fill()

    def do_export():
        path, _f = QtWidgets.QFileDialog.getSaveFileName(
            dlg, "Export Base Plates", "base_plates.json",
            "Base plates (*.json)")
        if path:
            export_to(path, [normalize(p) for p in plates])

    for text, fn in (("Add", add), ("Copy", copy_row), ("Delete", delete),
                     ("Import...", do_import), ("Export...", do_export)):
        b = QtWidgets.QPushButton(text)
        b.clicked.connect(fn)
        row.addWidget(b)
    row.addStretch(1)
    cancel = QtWidgets.QPushButton("Cancel")
    cancel.clicked.connect(dlg.reject)
    ok = QtWidgets.QPushButton("Save")
    ok.setObjectName("Primary")

    def accept():
        if check():
            save(plates)
            dlg.accept()

    ok.clicked.connect(accept)
    row.addWidget(cancel)
    row.addWidget(ok)
    v.addLayout(row)
    fill()
    return dlg.exec() == QtWidgets.QDialog.DialogCode.Accepted
