"""
=============================================================================
JBShared
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

"""
=============================================================================
 JB Shared  -  load the shared modules from THIS folder, never a stray copy
=============================================================================
 SDS2 runs every plugin in one Python, which keeps one module per name for
 the whole session. If an older JBMaterialPicker.py anywhere on sys.path
 (an SDS2 macro folder, say) is imported first, every JB member would use
 it. material_picker() always returns the JBMaterialPicker.py that sits
 beside this file, replacing any other copy already loaded.

 Each member finds this folder (JB Detailing\\_shared) itself, so this file
 has a name no other copy uses.
=============================================================================
"""

import importlib.util
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def _same(a, b):
    return os.path.normcase(os.path.abspath(a or "")) == \
        os.path.normcase(os.path.abspath(b or ""))


def load(name, reload=False):
    """Module `name` from this folder. reload=True re-reads the file
    (picks up edits without restarting SDS2)."""
    path = os.path.join(HERE, name + ".py")
    mod = sys.modules.get(name)
    if mod is not None and _same(getattr(mod, "__file__", ""), path) \
            and not reload:
        return mod
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def material_picker(reload=False):
    return load("JBMaterialPicker", reload)


def prefer_shared():
    """Put this folder first on sys.path and drop any JBMaterialPicker
    already loaded from somewhere else."""
    if HERE in sys.path:
        sys.path.remove(HERE)
    sys.path.insert(0, HERE)
    mod = sys.modules.get("JBMaterialPicker")
    if mod is not None and not _same(getattr(mod, "__file__", ""),
                                     os.path.join(HERE,
                                                  "JBMaterialPicker.py")):
        del sys.modules["JBMaterialPicker"]
