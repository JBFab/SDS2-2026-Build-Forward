"""
=============================================================================
JBBentPlate
Copyright (c) 2026 Jason Bondioli

Licensed under the JB Detailing Terms of Use - see LICENSE.txt in the
JB Detailing folder. Provided AS IS, without warranty of any kind. These
tools do not perform engineering; all output must be verified before use.
The bundled PySide6 in _vendor is licensed separately (GNU LGPL v3).
=============================================================================
"""

"""
=============================================================================
 JB Bent Plate  -  formed plate pieces shared by the JB members
=============================================================================
 Moved here from JBSimpleLadder's LadderBuild (the buyout / purchased rung
 and the bent standoff), so the railing's purchased U-channel uses exactly
 the code - and the field-tested corrections - the ladder does.

   bent_plate_layout_piece()   one formed piece through a bend path
   u_profile()                 the inverted-U cross-section of a buyout
                               rung / purchased channel, as layout points
   pull_back()                 shorten one end of a straight leg
   set_any()                   first attribute name that accepts a value

 Field-test history (from LadderBuild):
   2026-08-28  Designable.Proxies objects must get EVERY field as a
               constructor kwarg; setattr after construction is ignored.
   2026-09-12  the extrusion is CENTERED on the profile's plane, not run
               forward from it.
   2026-09-12  each leg must be pulled back from its open tip by half the
               thickness: a 1-1/4" leg in 1/4" plate measured 1-3/8"
               (height + thickness/2) without it.
=============================================================================
"""

import math

try:
    import plate_layout as _plate_layout_mod
except ImportError:                                   # pragma: no cover
    _plate_layout_mod = None
try:
    import Designable.Proxies as DP
except ImportError:                                   # pragma: no cover
    DP = None

DESC_KEYS = ("ImperialDescription", "MetricDescription",
             "MaterialUserDescription", "UserDescription",
             "user_description", "description")


def set_any(obj, names, value):
    """Try each attribute name in order; keep the first that accepts the
    value. Returns the name that worked, or None."""
    for name in names:
        if not hasattr(obj, name):
            continue
        try:
            setattr(obj, name, value)
            return name
        except Exception:
            continue
    return None


def pull_back(p_end, p_other, dist):
    """Move point p_end toward p_other by dist (shorten a piece from
    p_end's end). Tuple in, tuple out."""
    if dist <= 0.0:
        return p_end
    ex, ey, ez = p_end
    ox, oy, oz = p_other
    dx, dy, dz = ox - ex, oy - ey, oz - ez
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 1e-9:
        return p_end
    t = dist / length
    return (ex + dx * t, ey + dy * t, ez + dz * t)


def u_profile(center, across, legs, width, height, thick, radius=0.0):
    """
    Layout points [(point, bend radius)] of a U cross-section - the
    ladder's buyout rung formula - in the plane through `center` spanned
    by `across` (unit, the overall width direction) and `legs` (unit, the
    way the legs point from the web, i.e. toward the opening).

    width   overall, outside to outside of the legs - the path runs on
            the centerline, so the legs are inset half the thickness
    height  leg height, exactly as LadderBuild._purchased_rung uses
            pr_height: web centerline h/2 from `center` away from the
            legs, leg tips h/2 toward them, each tip pulled back half the
            thickness (2026-09-12 field test)
    `center` is the middle of the width and height, as the rung profile
    is centred on its elevation.
    """
    half_w = max(width - thick, 0.0625) / 2.0
    h = max(height, 0.0625)

    def at(a, b):
        return tuple(center[i] + across[i] * a + legs[i] * b
                     for i in range(3))

    web = -h / 2.0                        # away from the legs
    tip = h / 2.0
    p_web_l, p_web_r = at(-half_w, web), at(half_w, web)
    p_tip_l, p_tip_r = at(-half_w, tip), at(half_w, tip)
    p_tip_l = pull_back(p_tip_l, p_web_l, thick / 2.0)
    p_tip_r = pull_back(p_tip_r, p_web_r, thick / 2.0)
    r = max(radius, 0.0)
    return [(p_tip_l, 0.0), (p_web_l, r), (p_web_r, r), (p_tip_r, 0.0)]


def bent_plate_layout_piece(member, pts, width, thick, usage, grade="",
                            finish=0, color=None, description=None,
                            log=None, is_main=False):
    """
    One formed plate piece through a bend path. `pts` is [(point_tuple,
    bend_radius), ...]; `width` is extruded perpendicular to the plane of
    the points, CENTERED on it. Every candidate class (Designable.Proxies
    / legacy plate_layout, BntPlateLayout / PlateLayout) is tried in turn
    with all fields as constructor kwargs; the first that commits wins
    and is logged. Returns the material or None.
    """
    def info(msg):
        if log is not None:
            log.info(msg)

    def warn(msg):
        if log is not None:
            log.warn(msg)

    kwargs = {
        "Member": member,
        "MaterialOriginPoint": "Center",
        "Thickness": thick,
        "Width": width,
        "MaterialUsageDescription": usage,
        "mtrl_is_main": "Yes" if is_main else "No",
        "MaterialGrade": grade,
        "SurfaceFinish": finish,
        "pts": list(pts),
    }
    if color:
        kwargs["MaterialColor3d"] = color

    candidates = []
    if DP is not None:
        for cls_name in ("BntPlateLayout", "PlateLayout"):
            cls = getattr(DP, cls_name, None)
            if cls is not None:
                candidates.append(("Designable.Proxies.%s" % cls_name, cls))
    if _plate_layout_mod is not None:
        for cls_name in ("BntPlateLayout", "PlateLayout"):
            cls = getattr(_plate_layout_mod, cls_name, None)
            if cls is not None:
                candidates.append(("plate_layout.%s" % cls_name, cls))

    last_exc = None
    for label, factory in candidates:
        obj = None
        desc_applied = None
        if description:
            for desc_key in DESC_KEYS:
                try:
                    obj = factory(**dict(kwargs, **{desc_key: description}))
                    desc_applied = desc_key
                    break
                except Exception:
                    obj = None
                    continue
        if obj is None:
            try:
                obj = factory(**kwargs)
            except TypeError as exc:
                # Not a Proxies-style class: legacy construct-then-setattr
                last_exc = exc
                try:
                    obj = factory()
                    for name, value in kwargs.items():
                        set_any(obj, (name,), value)
                    if description:
                        desc_applied = set_any(obj, DESC_KEYS, description)
                    if hasattr(obj, "pts") and not obj.pts:
                        for p in pts:
                            obj.pts.append(p)
                except Exception as exc2:
                    last_exc = exc2
                    continue
            except Exception as exc:
                last_exc = exc
                continue
        committed = False
        for commit in ("Execute", "Add", "add"):
            if hasattr(obj, commit):
                try:
                    getattr(obj, commit)()
                    committed = True
                    break
                except Exception as exc:
                    last_exc = exc
                    continue
        if committed:
            info("  formed piece created via %s" % label)
            if description and not desc_applied:
                warn("  formed piece description not applied (no working "
                     "attribute name found)")
            return obj
    warn("formed plate piece: no working bent-plate layout API found (last "
         "error: %s)" % last_exc)
    return None
